# Local delivery pipeline acceptance — 2026-10-07

R03019 / #363 is **locally accepted for the reproducible delivery mechanism and midpoint stabilization** at signed22ef5f23e115c3ad070ea1c8cd060a1b4fcafee8. Root reviewed the source, failed/successful receipts, independent read-only acceptance inventory and amended metadata controls. Full final-candidate execution remains an explicit uncompleted R03020/#364 requirement.

## Acceptance mapping

| Requirement | Delivered evidence |
|---|---|
| Frozen compiler/Scheme/source/lock identities and separate worker targets | Existing stable_copy compiler handoff, shared fixture registry and source identity checks; explicit target leases. ADR0339 adds startup/end lock/config identities and drift refusal. |
| Focused selection with justified broader gates | Existing Cargo-metadata selection keeps actual integration tests, falls back for unknown generated syntax and preserves five mandatory proof-child routes. ADR0339 changes receipts only. Full proof/adoption execution stays separately scoped. |
| Toolchain/profile/feature/cache provenance and real execution | Bounded CI keys bind source, toolchain, lane/features/profile, locks and config. Local receipts now record observed tool versions, selected safe override/config identities and exact command argv;19focused tests plus3actual counter behavior tests pass. Selected metadata is not claimed to resolve every effective rustc flag. |
| Dependency/license/advisory and external-consumer accounting | ADR0301 preserves dependency changes/license data/advisory residuals; ADR0324 qualifies locked isolated tutorial consumers. Full gate checks fee/ZK/DID prerequisites. Residual advisory acceptance belongs to#357/#364; no clean-security or legal conclusion. |
| Signed delivery, decision/issue/history links and final-gate policy | Conventional GPG+DCO commits, focused issues/milestone links and vault archives retained. Broad release-candidate execution remains scheduled under#364; it has not been run or accepted by this note. |
| Local-first and midpoint CI after10original accepted parents | ADR0321 was tenth; ADR0325 began bounded stabilization. Exact31a02ebe Linux701core tests, strictClippy/fmt and actual1.88 checks pass; prior OS26 launch failure resolved byADR0337. Later22ef5f23run is separately pending verification. |

The first ADR0339candidate omitted end-of-run lock/config checks. Root requested and reviewed the amendment: successful gates refuse drift; failed gates preserve original errors/logs plus independent drift evidence. Original candidate and improved candidate remain archived. Unrelated secret-like environment values and free-text overrides are not disclosed; hashes identify selected inputs. No new scheduler/factory or unnecessary full test rerun was introduced.

## Final candidate obligations remain open

- Freeze final source/toolchain/dependency/contracts; run full applicable local and required remote gates.
- Qualify package/archive/host/MSRV/generated-consumer and migration graphs at that candidate.
- Refresh source refs/advisories and reconcile security/audit findings.
- Preserve pending consumer-safety and semantic obligations; this pipeline acceptance does not accept them.

[[Independent value assertions and local gate receipts — 2026-10-07]] and archive SHA2564dbcc810683ade8bcc6c27a4a80bda21910177b585bec1d94749434b36201bf0 bind the delivered source/tests/receipts. [[Linux launch repair and current coverage — 2026-10-07]] binds the successful bounded Linux lane.

**Progress:12/20original outcomes locally accepted,1ACCremoved,7open;12/19required locally accepted.** This increments one parent for its reviewed mechanism, not for three child issues. Remaining parents: typed consumer safety, meaningful coverage completeness, documentation publication, complete audit, adversarial assurance, final release qualification and closure report. ADR0285remainsstopped/unaccepted.


## Bounded Linux verification at22ef5f23 — 2026-10-07

Run[37616670733](https://github.com/MediaNoxLabs/compact/actions/runs/37616670733) passes at exact22ef5f23e115c3ad070ea1c8cd060a1b4fcafee8:701core tests,0failed/ignored/filtered, strictClippy/formatting and actual Rust1.88workspace/Jubjub/standalone checks. Source/event/tree, both committed lock hashes, workflow,12artifact files and both downloaded ZIP digests verified. This does not run the new Python provenance tests remotely; their19local tests and3actual generated behavior tests are separately bound.

Archive [[Bounded Linux validation at22ef5f23.zip]], SHA256`328e7c2f8fc4b42b5737f72c53bc428266f9c3d712797e9c3e3e66891466f7c6`. Verification receipt SHA256`1506d337ad72ada9a57c39c2c132785d8680bf281e2dfc90ce9ccc1a7b1711bc`. Full releasecandidate remains#364. Pipelinelocalacceptance remains12/19; no additional parent is counted for this run.
