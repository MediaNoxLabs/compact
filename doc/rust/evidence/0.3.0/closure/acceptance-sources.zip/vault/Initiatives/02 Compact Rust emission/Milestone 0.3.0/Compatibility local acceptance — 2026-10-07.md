# Local compatibility acceptance


## 2026-10-07 — R03016 local compatibility acceptance (ADR0321/#446)

Current checkpoint `5efa91c280c059e375dcde0998c64dd88f615fb6` retains backend/runtime/macros0.2.0, testkit0.1.0, ABI50, IR20, capability3 and native ledger8.0.3. The machine-readable [[Compatibility feature-source policy.json]] joins source/feature/migration/support limits; milestone0.3.0 is not a package/ABI version.

Independent review verified78migration artifacts,35selected bridge artifacts and2vault archives. Runtime/macros/testkit/public compatibility source and registry package records remain unchanged; existing old/new ABI and migration receipts are reused within their original scope. Actual Rust1.88 on macOS ARM64 passes current backend plus new Jubjub fixture all-feature compilation and isolated standalone backend compilation at signed49898aeda (4.74s/3.77s, warm cached checks);805workspace and75standalone files bound, locks unchanged. Subsequent c924/5efa changes are two test files only. This is not Linux/WASM1.88/fullNix or whole-corpus qualification.

Read-only GitHub drift check `2026-10-07T08:20:54.167066+00:00` confirms DIDv0.7.0 and passport develop still match selected commits, all3pinned commits exist and19adopted source hashes match remote bytes. Passport still pins credential-compact0.2.0. Core main advanced39commits to0.3.0, an unselected newer dependency; retain the owner-approved passport closure without promotion. Eight initial path404 lookups were corrected and retained as lookup attempts. FinalRC must repeat source/ref drift and frozen-candidate checks.

R03016/#360 is locally accepted for present compatibility/migration/MSRV/source-policy criteria. Its future final-candidate obligations remain explicitly owned by R03020; none are called executed. ADR0285/#409 consumer safety remains stopped/unaccepted, and independent security audit remains open. No remote registry or network acceptance claim.

Archive [[ADR0321 — Compatibility policy and current MSRV.zip]], SHA256 `e87b8acab734cf37a11059a71cf74f33261b8cf04332d950534b9cf6d7c8284a`; policy SHA256 `c9491c30fab726cd03fe22389e6a2c12ea678230e079123481392f861d2646f9`. #446 bounded reconciliation closes. This is the **tenth accepted original parent**: original20=10accepted,1removedACC,9open; required19=10accepted/9open. Begin CI stabilization inventory under R03019; full frozen-revision remote qualification is later. Build-heavy local follow-ups wait for disk capacity (below2GiB); no caches/evidence removed.
