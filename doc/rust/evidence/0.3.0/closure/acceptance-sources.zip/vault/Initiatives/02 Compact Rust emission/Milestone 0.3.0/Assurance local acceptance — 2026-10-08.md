# Assurance local acceptance — 2026-10-08

**R03017 / #361 locally accepted at signed9ffd7880405ed5cfd62909ed4aac64a638c7fc02 under the explicit owner-approved decoder exception.** Progress advances to16/19 required outcomes accepted. Documentation publication, final candidate qualification and closure report remain open.

## Criterion reconciliation

| Approved criterion | Evidence and limits |
|---|---|
| Enumerated malformed/type/scope/slot/call, canonical/FAB, alias, offer and observation categories | Retained74-row compiler/121assertion crosswalk, source-first runtime domains and25obligations/79tests plus52codec/native supplements. PATH/WIRE/qualified-Set amendments join concrete discovered gaps to delivered controls. Not a universal malformed-input inventory. |
| Independent upstream/TS evidence | Pinned ledger/zk and frozen TS anchors, adopted DID/passport evidence, scalar/provider disagreement preserved. CoPS-001 independently pins TS/mainstreamledger8decoder ownership; absence of a budget is not claimed as an exploit. |
| Deterministic boundary corpus and approved resource scope | Compiler structural budgets/worker regressions, runtime seeded/literal cases and actual35xxpath/decoder regressions. ADR0359adds generous64MiB opt-in byte policy; seven decoder tests/Clippy pass. Owner explicitly deferred aggregate decoded heap/object/CPUcontainment for raw state/verifier decoding. Transport acquisition, callbacks/compiled traits/DB and aggregate orchestration retain named owners. No input silently reclassified trusted. |
| Reproducible seeds/budgets/guard mutants | ADR0341bounded seeded campaigns and two actual implementation mutants; retained ADR0271/0275/0286negative controls; explicit structural versus strict-proof tiers. No cryptographic validation disabled to pass acceptance. No exhaustive fuzz guarantee. |
| Transition/privacy cases and no confirmed open critical/high | Retained RO/LB/#347positive/refusal checks, privacy-output tests, accepted#357findings ledger and completed external remediation/D1retests. Dependency residuals remain explicit; no human security certification. |

A separate sibling reviewed these five criteria after the owner decision and found only CoPS comparison publication in the vault outstanding. Root completed and reviewed CoPS-001 with pinned sources and archived identity snapshots before acceptance. Root separately inspected the runtime diff, committed-source hashes and actual seven-test/Clippy logs. No new broad conformance, proof or fuzz campaign was needed.

## Exact remaining limits

The decoder-specific exception is explicit in backlog.md, backlog-data and#361:0.3.0 accepts encoded-byte admission, not aggregate resource containment. CoPS-001/#495tracks the deferred problem outside the milestone. The64MiB preset is application policy, not protocol maximum; existing decode APIs remain compatible and custom budgets can exceed it. This does not establish total safety for arbitrary Rust callbacks, all network payloads or every possible source program.

Previous current-runtime97.83%coverage belongs toef352bcd; the subsequent small preset has focused tests but no fresh whole-component percentage is claimed. Accepted coverage/audit receipts retain their source identities and require affected final qualification. Final#364owns frozen full applicable local/remote, proof, host/MSRV, package/migration and dependency checks. The milestone is not closed.

[[Decoder resource scope decision — 2026-10-08]] · [[CoPS-001 — Ledger decoding resource limits]] · [[ADR0359 — Practical byte policy receipt]] · [[R03017 — Runtime boundary domain and corpus crosswalk]] · [[Source audit local acceptance — 2026-10-08]]
