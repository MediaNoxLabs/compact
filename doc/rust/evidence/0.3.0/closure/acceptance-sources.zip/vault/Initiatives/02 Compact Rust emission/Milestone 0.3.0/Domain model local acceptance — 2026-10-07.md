# Domain model local acceptance — 2026-10-07

R030-01/#345 is locally accepted at `1705fc1ae1b1ad28fedf08da32c676b8860b05db` after root reviewed the four approved criteria, actual source changes, immutable receipt hashes and the ownership-guide amendment. **Accepted parent outcomes:6/20 (30%).** Remote CI stabilization still begins at10/20.

| Approved criterion | Acceptance evidence |
|---|---|
| Ownership and extensions | `Developer guides/Runtime and compiler ownership map.md` assigns source typing, slots, witness execution, VM, recording, offer binding, proving and observation trust; dated amendments cover current compiler/runtime components and public/internal boundaries. |
| Checked outcomes and provenance | ADR0266 shielded-send and ADR0286 Unit composition use NotApplicable/Rejected/Admitted. Native malformed-IR errors retain precedence. Whole-plan rejection and source/callee locations have focused controls, including an intentionally broken partial-plan mutant that fails. |
| Representative migration | Unit composition covers pure values/guards, read-only helpers, witnessed flat/chunked/crypto branches; shielded-send is the funded representative.353 backend,7 Unit and41 DID tests, five positive sources and183 byte-identical Rust/capability pairs characterize this slice. Existing funded proof evidence is historical, not a new proof run. |
| Measured lexical identity decision | ADR0284 tested actual simpler Rc-map and BindingId emitters:43 successful outputs,22 identical errors and23 focused tests per variant. Neither showed a useful stable performance/memory advantage or needed ID consumer. Retain typed lexical maps and checked declaration references; ADR0281 preserves semantic raw-name binding hygiene. |

This accepts representative owners, not universal conversion of every optional recording profile. Pure Unit guards/values are within composition; pure exports have their separate renderer. A domain-specific refusal does not make IR globally invalid: another profile may independently audit the original input and construct a complete plan. No rejected prefix is reused. Resource bounds, consumer trust audit and final whole-milestone qualification remain separate open work.

ADR0286 receipt `2eb83b9912d390447363c7a348097df9daa468ff2669617c485229ee38b3ff79`; durable244-file archive `e10da0b3ae3c109f10a1666e27f9d5a49eb766008067ca3696e64200ec8985fb`. ADR0284 receipt `474e294356175946d103090ff0c40e8c3819f30ffe7475bde4e2020f192d6f87`. See [[R030-01 representative checked-admission acceptance mapping]], [[ADR0286 — Checked Unit composition delivery]], [[ADR0284 — Lexical scope and binding identity decision]]. No new code/test execution is claimed by this acceptance reconciliation.
