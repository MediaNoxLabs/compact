# DID and minimal-reproducer local acceptance — 2026-10-07

R030-09/#353 and R030-11/#355 meet their bounded **local adoption** acceptance at `329bf1bc80441125d2800fc9f1dae8b570da5dac`. The two signed joined deliveries and existing accepted receipts cover every required original export and the previously missing reduced-source evidence. This raises accepted parent outcomes from **6/20 to 8/20 (40%)**. CI stabilization remains scheduled for 10/20. This does not close audit, current coverage, final qualification or the milestone.

## Original source and behavior

The user-selected `midnight-did` v0.7.0 remains commit `4e7f6b0f69bf4e2c8506a9693f8d0c3dfe68e550`. Original `did.compact` and its Schnorr import match the unchanged source manifest; no later release, generated-source patch or disabled authorization substitutes for them. The provenance suite covers source/tool/runtime versions, exported signatures and recaptured oracle identities. ADR0287 independently recaptured the official release compiler/runtime profile; its scenario rows remain distinct from matched-branch TS captures.

The generated constructor and all twelve stateful exports compile and execute. Forty-three current DID test methods cover constructor witnesses/failures, native and recorded calls, private witness order, complete programs, per-query/total gas, state/effects, lifecycle and rollback. Tables cover wrong authority, duplicates, missing targets and finite curve/signature boundaries. The final relation table contains 42 calls: 23 successes and 19 expected refusals. Seven refreshed TS capture files preserve complete semantic data; only the generated-Rust provenance hash changed.

## Real proof coverage by export

| Original export | Default-strict receipt |
|---|---|
| `deactivate` | ADR0288 historical / points |
| `recoverControllerKey` | ADR0288 historical / points |
| `removeSchnorrJubjubVerificationMethod` | ADR0288 historical / schnorr-methods |
| `removeService` | ADR0288 historical / services |
| `removeVerificationMethod` | ADR0288 historical / jwk-methods |
| `rotateControllerKey` | ADR0288 historical / points |
| `setAlsoKnownAs` | ADR0288 historical / aliases |
| `setSchnorrJubjubVerificationMethod` | ADR0288 historical / digest; ADR0288 historical / schnorr-methods; ADR0295 final join / relation-schnorr |
| `setService` | ADR0288 historical / services |
| `setVerificationMethod` | ADR0288 historical / jwk-methods; ADR0295 final join / relations |
| `setVerificationMethodRelation` | ADR0295 final join / relation-schnorr; ADR0295 final join / relations |
| `verifySchnorrJubjubDigestSignature` | ADR0288 historical / digest; ADR0295 final join / relation-schnorr |

The historical ADR0288 gate passed sixteen original calls; the final joined ADR0295 gate passed nineteen original calls plus six relation-reducer calls. The table is a **union of verified receipts**, not a claim that every historical proof was rerun on the final HEAD. The recorded 193-source differential preserves all native bodies and unrelated recorded output/capabilities; current 196-source freshness and full DID behavior pass. Root reverified the historical receipt/results and all 512 final gate source identities. The final release-candidate gate remains R030-20's obligation.

Constructor-derived data is actually deployed, while constructor execution itself remains unproved. Positive proofs verify and apply under default strictness with separate Dust fee funding; changed bindings and same-time replay are refused. Network submission/acceptance was not performed. Native ledger8.0.3 is unchanged. ADR0290's fourteen, ADR0300's two and ADR0303's eleven independent ledger8.1 snapshots collectively cover all twelve exports; these are historical/fresh separate runs, not one continuous8.1 chain. All transported ledger parameters are preserved.

## Minimal reproducer closure

| Source slice | Sources | Behavior cases | Strict snippet proof calls |
|---|---:|---:|---:|
| ADR0294 Point, alias, Service, Point products, nested JWK/Enum families | 9 | 55 | 21 |
| ADR0288 digest read/checked verifier | 1 | 4 | 1 |
| ADR0295 selected two-/four-Set and nested-JWK read | 3 | 22 | 6 |
| Total across their accepted receipts | **13** | **81** | **28** |

Each slice retains original export/source/root cause, a real minimal Compact source, typed admission refusals, fresh generated Rust, independent TS behavior and exact-source proof where applicable. Original DID scenarios remain separately tested/proved. Pure/diagnostic controls retain their legitimate classification; the alias `remove_control` is not promoted or counted as a recorded proof operation. The original constructor-initialized Point Map test does not invent a true nested-Map path. The final relation profile uses declaration/key identity and finite checked composition, with renamed two-/four-Set controls; it has no fixture-name dispatch.

The maintained owners are `did_proof_gate.py`, `did_digest_reducer_gate.py`, `did_primitive_reducer_gate.py`, `did_relation_gate.py`, the shared fixture registry and their regression tests. Registry classification is 196 sources and 1,156 declarations at this checkpoint. The older read-only R03011 inventory is preserved as historical gap discovery; ADR0294 and ADR0295 close its missing executable/proved-reducer columns.

## Acceptance and remaining limits

- #353 criteria: pinned complete source/version identity; unchanged generated constructor/exports; positive/refusal lifecycle and crypto cases; default-strict per-export proof coverage; all discovered required primitive gaps reduced and fixed. All satisfied for the recorded local profile.
- #355 criteria: original-to-minimal attribution, decision-before-implementation issues/ADRs, independent reduced behavior and strict proofs, typed refusal ownership and preserved original regressions. All satisfied for the adopted DID/passport compatibility scope. The passport remains its separately accepted pure API profile, with proof non-applicability preserved.
- Full semantic input-space proof, a human security audit, network deployment, continuous8.1 history and final-RC rerun are not claimed. The stopped ADR0285/cross-instance security lanes remain stopped; this adoption acceptance neither restarts nor resolves them. Existing lru/maintenance advisory dispositions remain with audit/final qualification.
- No push or remote CI. GPG/DCO verification passes, and the user's ledger document remains untouched. ACC now needs the separately recorded activate/defer decision; its placeholder is not accepted completion.

## Durable evidence

[[Joined relation and release delivery — 2026-10-07]]; [[ADR0288 — Signed integration receipt]]; [[ADR0294 — Signed integration receipt]]; [[ADR0287 — Original DID release oracle recapture]]; [[ADR0290 — Signed integration receipt]]. The joined archive SHA256 is `9062cfe7afcf8c15f77cb8674ea75cfcb0865a37898cdc31f45e0fb8c6b7c748`.

Machine-readable reconciliation follows. It binds twelve export names to real proof rows and retains receipt/source identities without representing historical evidence as a fresh full-suite run.

```json
{
  "format": "compact-rust030-adoption-acceptance/v1",
  "status": "locally-accepted",
  "revision": "329bf1bc80441125d2800fc9f1dae8b570da5dac",
  "source": {
    "format": "compact-did-adoption-sources/v1",
    "repository": "https://github.com/midnightntwrk/midnight-did",
    "tag": "v0.7.0",
    "commit": "4e7f6b0f69bf4e2c8506a9693f8d0c3dfe68e550",
    "files": [
      {
        "path": "packages/contract/src/did.compact",
        "sha256": "632f34af543924edb185fe9c8eda54aa4ca0503b0b9e8ee3ff06ec470f6d7456",
        "modification": "none"
      },
      {
        "path": "packages/jubjub-schnorr/src/schnorr.compact",
        "sha256": "f072731d730d72f8b76b183df2c5187b233a0838d9462894cfb0a6d2f0f66bff",
        "modification": "none"
      }
    ]
  },
  "proof_export_coverage": {
    "rotateControllerKey": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "points",
        "case": "rotate"
      }
    ],
    "recoverControllerKey": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "points",
        "case": "recover"
      }
    ],
    "deactivate": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "points",
        "case": "deactivate"
      }
    ],
    "setAlsoKnownAs": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "aliases",
        "case": "insert-unicode"
      },
      {
        "receipt": "ADR0288 historical",
        "scenario": "aliases",
        "case": "remove-unicode"
      }
    ],
    "setService": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "services",
        "case": "insert-unicode"
      },
      {
        "receipt": "ADR0288 historical",
        "scenario": "services",
        "case": "update-empty-fields"
      }
    ],
    "removeService": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "services",
        "case": "remove-unicode"
      }
    ],
    "setSchnorrJubjubVerificationMethod": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "schnorr-methods",
        "case": "insert-unicode"
      },
      {
        "receipt": "ADR0288 historical",
        "scenario": "schnorr-methods",
        "case": "update-point"
      },
      {
        "receipt": "ADR0288 historical",
        "scenario": "digest",
        "case": "insert"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relation-schnorr",
        "case": "insert"
      }
    ],
    "removeSchnorrJubjubVerificationMethod": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "schnorr-methods",
        "case": "remove-unicode"
      }
    ],
    "setVerificationMethod": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "jwk-methods",
        "case": "insert-unicode"
      },
      {
        "receipt": "ADR0288 historical",
        "scenario": "jwk-methods",
        "case": "update-jwk"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "accept-ed"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "accept-x"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "accept-bls1"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "accept-bls2"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "accept-p256"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "accept-secp"
      }
    ],
    "removeVerificationMethod": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "jwk-methods",
        "case": "remove-unicode"
      }
    ],
    "verifySchnorrJubjubDigestSignature": [
      {
        "receipt": "ADR0288 historical",
        "scenario": "digest",
        "case": "read-valid"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relation-schnorr",
        "case": "read-valid"
      }
    ],
    "setVerificationMethodRelation": [
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "relation-1-insert"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "relation-1-remove"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "relation-2-insert"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "relation-2-remove"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "relation-3-insert"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "relation-3-remove"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "relation-4-insert"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "relation-4-remove"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "relation-5-insert"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relations",
        "case": "relation-5-remove"
      },
      {
        "receipt": "ADR0295 final join",
        "scenario": "relation-schnorr",
        "case": "relation-insert"
      }
    ]
  },
  "proof_receipts": {
    "historical": {
      "path": "/tmp/rust030-adr288/strict-original-gate-final/receipt.json",
      "sha256": "6f3378c1dfc9767f62ec6945a22e3a80dc808e7821250da8ced9e91d28fc5a10"
    },
    "final_join": {
      "path": "/tmp/rust030-joined-relation-gate/receipt.json",
      "sha256": "9c375c7dc2fb9d3acf1f3a9effea07e1d60e79982cb88bfb1ccf80751205d367"
    }
  },
  "reducer_sources": 13,
  "reducer_behavior_cases": 81,
  "reducer_proof_calls": 28,
  "historical_and_final_gates_combined": true,
  "all_proofs_rerun_on_current_head": false,
  "constructor_execution_proved": false,
  "network_accepted": false,
  "external_audit_complete": false
}
```
