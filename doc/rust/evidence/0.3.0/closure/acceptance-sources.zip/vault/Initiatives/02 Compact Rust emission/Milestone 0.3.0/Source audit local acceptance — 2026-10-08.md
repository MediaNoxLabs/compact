# Source audit local acceptance — 2026-10-08

**R03013 / #357 locally accepted at `231559f12aa67a37065b4663778d69ab278678d2`.**

All five source-audit criteria are locally accepted. Root reviewed the completed internal/external checklist, concrete findings, source-based withdrawals, fixes and independent follow-ups. This is completion of the audit work and its findings disposition, not an all-clear or acceptance of every separate assurance claim.

| Criterion | Accepted evidence |
|---|---|
| Internal architecture/security/functional/nonfunctional coverage |Unified subject checklist and source-first compiler/runtime boundary crosswalk cover ownership, IR/admission, output, codecs, witnesses/privacy, offer/proof/observation and failure behavior; retained performance/operational reviews stay scoped. |
| Independent external review |Separately configured coding-agent reviews at frozen4c8aebc3, remediation e6807884, qualified-Set ef352bcd and exact gate231559f1. Attribution/model/source/read limits retained; no claim one reviewer inspected every line. |
| Finding remediation and no open confirmed critical/high |F2/S1 andF3 fixed under0351/0352;qualified Set andD1fixed under0358;independent retests complete. F1withdrawn from actual pinned upstream encoding. Historical high findings retain prior independent closure. |
| Medium/low/residual disposition |F4/S2/S3/S4 and dependency notices retain explicit bounded dispositions. Decoder aggregate resource guarantee is **unresolved assurance scope owned by#361**, awaiting owner decision; this grants no risk waiver. |
| Relevant retests/checklists retained |Three-fix retest, qualified-Set review and final D1closure plus architecture/functional/nonfunctional evidence are retained in the vault for closeout. |

The external review found no demonstrated malformed-input decoder defect; that does not prove bounded heap/CPU. The encoded-byte admission/corpus/docs repair is complete, while the broader#361requirement is unaccepted. Dependency notices#471–474remain with their exact caller/pin dispositions; no clean scanner or human security certification claim. Final candidate proof/host/MSRV/package qualification remains#364. Further source changes require relevant review.

## Review and provenance

[[Coverage and source-audit acceptance review at231559f1]] contains the criterion-level independent reconciliation; [[Coverage and source-audit acceptance identities at231559f1]] records actual checks. The diagnostic implementer explicitly relies on separately retained external retests for that implementation. Root inspected the report, approved backlog/issue wording, current amendments and source continuity before accepting. No new build, proof or test execution was needed for this decision.

[[Current coverage at e6807884]] · [[Current runtime coverage at ef352bcd]] · [[Audit and assurance readiness after remediation]] · [[ADR0358 — External D1 closure at231559f1]]
