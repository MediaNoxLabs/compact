from pathlib import Path
import os,json,hashlib,datetime
ROOT=Path('/Users/ysh/.codex/worktrees/07ae/compact')
resource=Path('/tmp/rust030-resource-baseline/resources.json')
j=json.loads(resource.read_text()); roots={}; candidates={}
for row in j['rows']:
    if row['cohort'] in ('k1','p256-modmul'): continue
    a=row.get('artifacts',{}).get('verifier',{})
    if a.get('path'):
        p=Path(a['path']).resolve(); roots[str(p.parents[2])]=row['cohort']
rows=[];seen=set();scanned=[];skipped=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def add_blob(blob,source,selector,kind,cohort):
    rows.append({'kind':kind,'cohort':cohort,'source':str(source),'selector':selector,'bytes':len(blob),'sha256':sha(blob),'source_sha256':sha(source.read_bytes())})
for name,cohort in roots.items():
    for folder,dirs,files in os.walk(name):
        dirs[:]=[d for d in dirs if d not in {'target','node_modules','.git','.pnpm','objects','profiles','srs'}]
        for fn in files:
            p=Path(folder)/fn
            if fn.endswith('.verifier') or ('state' in fn.lower() and fn.endswith('.bin')):
                candidates[str(p.resolve())]=(p,cohort)
            elif fn.endswith('.json') and p.stat().st_size<=4*1024*1024 and ('state' in fn.lower() or 'oracle' in fn.lower() or 'receipt' in fn.lower()):
                candidates[str(p.resolve())]=(p,cohort)
for p in (ROOT/'runtime-rs/tests/fixtures').glob('*.json'): candidates[str(p.resolve())]=(p,'runtime-oracle-fixtures')
for p in (ROOT/'tools/compact-rust-proof-smoke/tests/fixtures').glob('*state*.bin'): candidates[str(p.resolve())]=(p,'proof-smoke-retained-fixtures')
# Include retained original DID captures/pure passport fixtures where identifiable within repository.
for root in [ROOT/'examples/rust_backend/did_adoption', ROOT/'examples/rust_backend/vc_passport_adoption']:
    if root.exists():
        for p in root.rglob('*.json'):
            if not any(x in p.parts for x in ('node_modules','target','.git')) and p.stat().st_size<=4*1024*1024: candidates[str(p.resolve())]=(p,'adoption-source-fixtures')
hexprefix=b'midnight:contract-state'.hex()
def strings(value,pointer=''):
    if isinstance(value,str):yield(pointer,value)
    elif isinstance(value,dict):
        for k,v in value.items():yield from strings(v,pointer+'/'+str(k).replace('~','~0').replace('/','~1'))
    elif isinstance(value,list):
        for k,v in enumerate(value):yield from strings(v,pointer+'/'+str(k))
for p,cohort in candidates.values():
    if str(p.resolve()) in seen: continue
    seen.add(str(p.resolve()))
    size=p.stat().st_size
    if size>4*1024*1024:skipped.append({'path':str(p),'reason':'4 MiB per-source read cap'});continue
    b=p.read_bytes();scanned.append({'path':str(p),'bytes':size,'sha256':sha(b),'cohort':cohort})
    if p.suffix=='.verifier':add_blob(b,p,None,'verifier-key',cohort)
    elif p.suffix=='.bin':
        if b.startswith(b'midnight:contract-state'):add_blob(b,p,None,'contract-state',cohort)
        else:skipped.append({'path':str(p),'reason':'state-named binary is not tagged ContractState','bytes':size,'recognized_tag':b.split(b':',2)[1].decode('ascii',errors='replace') if b.startswith(b'midnight:') else 'unrecognized'})
    else:
        try: obj=json.loads(b)
        except (ValueError,UnicodeError):continue
        for pointer,v in strings(obj):
            if v.lower().startswith(hexprefix) and len(v)%2==0:
                try:blob=bytes.fromhex(v)
                except ValueError:continue
                add_blob(blob,p,pointer,'contract-state',cohort)
summary={}
for kind in ['verifier-key','contract-state']:
    sel=[r for r in rows if r['kind']==kind]
    summary[kind]={'samples':len(sel),'unique_payloads':len({r['sha256'] for r in sel}),'min_bytes':min((r['bytes'] for r in sel),default=None),'max_bytes':max((r['bytes'] for r in sel),default=None),'largest_samples':sorted(sel,key=lambda r:r['bytes'],reverse=True)[:5]}
out={'measured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'read-only selected retained cohorts and tagged JSON payloads; no decoding, generation or proof execution','roots':roots,'summary':summary,'samples':rows,'scanned_sources':scanned,'skipped':skipped,'resource_inventory_sha256':sha(resource.read_bytes()),'limits':['partial historical/current-artifact census, not a network maximum or growth forecast','4 MiB per-source read cap; target/node_modules/.git/objects/profiles/srs pruned','Only contract-state tag recognized; StateValue-only bytes not counted as ContractState','passport selected adoption is pure and contributes no verifier/proof keys by design','P-256/secp256k1 out-of-scope historical resources excluded']}
Path('/tmp/rust030-decoder-sizing/sizes.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(summary,indent=2));print('sources',len(scanned),'skipped',len(skipped))
