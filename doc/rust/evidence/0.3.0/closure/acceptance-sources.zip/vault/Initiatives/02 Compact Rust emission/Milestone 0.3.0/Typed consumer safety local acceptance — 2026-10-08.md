# Typed consumer safety local acceptance — 2026-10-08

**R03003 / #347 locally accepted at `4c8aebc3b94144aa146ca562b3e67cabeb772ed0`.** All four approved criteria are supported by the crosswalk below. This is local parent acceptance, not final milestone or full external audit acceptance.

Root verified unchanged runtime/macros/testkit/proof-runner source trees since5a9cd356, inspected raw retained passing tests for malformed encodings/bounds, forged owner/duplicate allocation, observation consistency and explicit preparation policy, and read the current prepare path's address/state/key/verifier refusal branches. Fresh#409 evidence adds actual external generated positive/negative controls and a separately reviewed current upstream boundary inventory. The signed test commit is pushed; #409 is closed.

Limits remain explicit: inherited upstream unsafe/FFI and accepted advisory residuals; provider-specific historical scalar behavior; no implicit domain tags added to Keccak; local consistency is not authenticated provenance/finality; owned moves are not deep rollback or exclusive global state. Historical proof receipts are not fresh Linux or current-candidate proof runs. Full#357/#361/#364 obligations remain open.

Parent count advances from12 to **13/19 required outcomes accepted** (13/20 original,1removedACC,6openparents). No new broad tests were needed because semantic and test sources behind reused receipts are unchanged. New147-test Python and external consumer execution remain scoped to#409.

## Independent criterion crosswalk

# R03003 / #347 acceptance reconciliation

2026-10-08, read-only review at `4c8aebc3b94144aa146ca562b3e67cabeb772ed0`. Source: midnight `Milestone 0.3.0/backlog.md`, its four R03003 criteria. No tests, repository edits, issue mutations or network calls. This is a parent acceptance recommendation, not a new execution receipt or final milestone qualification.

## Evidence continuity checked

`git diff 5a9cd35613c0a973c5c5134e7f93fa906bdb3594 HEAD -- runtime-rs runtime-rs-macros testkit-rs tools/compact-rust-proof-smoke` is empty. Therefore the retained 5a9cd356 core execution and semantic source references below still describe these exact implementation/test sources. Read raw `tests.log` inside `Evidence/Bounded Linux validation at5a9cd356.zip`, not just its passed summary. The new #409 external consumer archive was also opened and its six command statuses and intended error codes inspected. Its runtime-source mode is distinct from final archive packaging.

## 1. Prevented misuses, fair TS comparison, static and dynamic controls

**Locally supported.** ADR0285/#409 now supplies the missing focused consumer evidence: `Evidence/ADR0285 — Resumed typed consumer qualification.zip` / `consumer-receipt.json` retains two valid cargo-check/test pairs and two expected cargo-check refusals. Context reuse is exclusively E0382; unchecked tuple construction exclusively E0423. Positive calls increment twice and read 2; BoundedUint<255> accepts 0/255 and rejects 256 with exact payload. The qualified harness inspects error codes and primary target spans, rather than treating any Cargo failure as a passing negative.

`Reviews/ADR0285 — Current boundary inventory.md` fairly compares these against mutable TS CircuitContext, generated bigint/bounds checks (`compiler/typescript-passes.ss:1353`), readonly TS witness fields and descriptor decoding (`runtime/src/compact-types.ts:298`). Rust ownership is not claimed to prove deep state isolation or forbid deliberate shared mutation.

Existing dynamic malformed-input evidence is broader than the new tuple-control: raw 5a9cd356 log passes `wide_decoders_reject_wrong_arity_and_fab_overwidth`, `fixed_bytes_reject_bits_outside_full_and_partial_field_chunks`, `bounded_uint_cell_rejects_a_value_above_its_declared_maximum`, `successful_host_arithmetic_still_enforces_the_declared_result_bound`, and native scalar refusals. These are actual semantic expectations, not compilation alone. Corresponding files: `runtime-rs/tests/primitive_boundaries.rs`, `ledger_cells.rs`, `bounded_uint.rs`, `native_boundaries.rs`.

Remaining: no concrete implementation/test gap identified for this criterion's bounded misuse inventory. Archive-integrated rerun belongs to #364; don't claim that #409 already ran it. No universal enumeration of every possible consumer misuse is implied.

## 2. Canonical/reduced scalars, bounds, domain separation, binding and allocation

**Locally supported with explicit provider and proof-tier limits.** Retained raw 5a9cd356 execution proves:

- `native_boundaries.rs:256,297`: q−1 accepted; q/q+1 refused by canonical EC APIs; explicit reduction maps q/q+1 to 0/1; registry TS high-scalar refusal/reduction fixture retained. ADR0200/0234 distinguish signed reduction and canonical signing from provider-dependent raw Field multiplication. Nix's historical 3.1.0-rc.1 reduction differs from registry 3.0.0; no universal raw-Field/provider parity assertion.
- `bounded_uint.rs:82,146,155`, `wide_uint.rs:51,70`, `primitive_boundaries.rs:162`: declared integer bounds, malformed decoding, carry/narrowing and result bounds remain checked.
- `native_boundaries.rs:47,76,99,345`, `shielded_coin_identity_vectors.rs:75`: hashes/commitments/FAB preimages and recipient domains retain frozen TS/upstream expectations. Keccak deliberately hashes concatenated normalized atoms **without additional type tags**; preserving domain semantics does not authorize adding tags to this API.
- `transaction/zswap_tests.rs:186,262,475,546,613` and `transient_tests.rs:239`: explicit wallet inputs, exact disjoint input union, output order/bijection, sealed allocation, forged owner, duplicate/non-normal form and canonical-policy refusal tests all pass in that log. ADR0199/0204/0205 define these exact policies.

Verifier/address/state checks are explicit in current `transaction.rs:806–825`; the proof runner has direct wrong-verifier, wrong-address and stale-state controls at `tools/compact-rust-proof-smoke/src/main.rs:3472–3527`. Public input is carried into the prototype at `transaction.rs:998`; the proof runner checks exact expected transcript inputs at main.rs:303 and verifies then rejects a changed binding at lines 338–351. Historical full-proof gates, ADR0204's default-strict funded-transient receipt, and `Evidence/ADR0294 — Nine maintained DID primitive reducers.md` retain successful real proof calls and changed-binding refusals. The latter records 21 exact-key proofs/default-strict applications, not constructor execution proofs.

Remaining: no concrete code gap identified. The bounded Linux lane is **not** a fresh proof run; preserve proof receipt dates, seeds and source scope. Final exact-candidate proof repeats remain #364. A claim that the two #409 compile failures alone establish verifier/input/offer security would be unsupported.

## 3. Caller identity, observations and authenticated ownership

**Locally supported, explicitly non-authenticating.** `transaction/observation.rs:20` says checkpoint constructors cannot authenticate network facts. `context.rs` exposes execution identity only as supplied context; `testkit-rs/src/lib.rs:19` documents trusted adapters and no deep rollback for shared witness state.

Raw 5a9cd356 tests pass:

- `checkpoint_mismatch_checks_do_not_claim_to_authenticate_network_provenance` (`observation_tests.rs:264`), including the deliberate positive case where equal but potentially dishonest endpoint facts are accepted for consistency;
- `missing_history_is_an_explicit_node_admission_obligation` (line 412);
- `funding_identity_owner_transient_and_capacity_boundaries` (line 502);
- `execution_context_replacement_cannot_change_sealed_identity` (`runtime-rs/tests/recording_coin_identity.rs:99`) and preparation's public rebind/changed-final-identity refusals;
- ContractLab `trusted_adapter_boundary_does_not_attest_transient_policy_changes`.

ADR0042 retains historical local node/indexer consistency validation with an explicit lack of independent consensus/finality authentication. The current boundary report carries the same distinction. These are accurate limitations, not missing guarantees that the backlog promised types would supply.

Remaining: no new authorization experiment is necessary to accept this criterion's distinction. Do not widen local consistency into authenticated ownership or finality.

## 4. Owned unsafe, inherited unsafe/FFI, and no implicit strict fallback

**Locally supported within an inventory/review interpretation.** ADR0285 boundary inventory scanned all 74 runtime/macro/testkit Rust files and retained their hashes: no owned unsafe implementation/FFI declaration; runtime root `#![forbid(unsafe_code)]` at line 22. Macro invalid-source strings are negative parser fixtures. Upstream FAB casts, curves/blst C+assembly, proof MSM and storage casts are separately identified. ADR0345 independent review and selected graphs qualify exact pinned dependencies; unresolved lru and maintenance notices remain explicit engineering residuals, not a clean global safety certificate.

No implicit downgrade appears in the inspected preparation path: `RecordedCall::prepare` calls one checked implementation (`transaction.rs:791`); mismatch/refusal returns propagate through `?`/typed errors. Offer preparation (`transaction.rs:384`) preserves an explicitly scoped old exact-policy empty-plan branch, not a retry after strict failure. Canonical/funded empty plans retain distinct rejections. Raw 5a9cd356 passes `public_prepare_preserves_default_and_funded_empty_call_boundaries`, `transient_options_require_explicit_canonical_mode_and_preserve_old_refusal`, exact segment policy restrictions and identity guards.

Some historical proof smoke scenarios explicitly disable balancing; they are visibly separate fixture policies, not an automatic production fallback. ADR0204 and maintained reducers separately retain actual default-strict funded application receipts. Do not merge those categories in the closure report.

Remaining: full upstream memory-safety/constant-time certification was never established; acceptance should use the scoped boundary inventory plus retained independent dependency disposition. Broader internal/external audit and final candidate dependency rescan remain #357/#364.

## Recommendation and exact outstanding work

I found **no concrete R03003 implementation blocker after the bounded #409 delivery**. The four approved criteria have specific, reusable source/execution/documentation evidence above. Root can accept #347 locally after retaining this crosswalk and explicitly preserving limits. Do not derive acceptance merely from #409 closure or a test count.

Administrative work still required: append a parent acceptance note, update its four backlog checkboxes/status and parent issue with evidence; refresh stale ADR0285 publication staging. These actions are root-owned. They do not close assurance #361, broad audit #357, documentation publication or final qualification #364. Fresh final-candidate validation must remain separately tracked. No additional broad test sweep is recommended for this unchanged semantic-source reconciliation.
