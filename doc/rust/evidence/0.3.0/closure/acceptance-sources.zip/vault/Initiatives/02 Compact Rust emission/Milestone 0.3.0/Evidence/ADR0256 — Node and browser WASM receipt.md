# ADR0256 — Generated Rust WebAssembly feasibility receipt

**Bounded prototype accepted locally, 2026-10-07.** Four unedited generated crates execute in native Rust, Node 24.14.0 and headless Chromium 151.0.7922.34. No production compiler/runtime changes or production WASM support promise.

## Supported subset actually exercised

- Pure Field subtraction/multiplication and persistent hash, with byte-exact transport. Boundary pairs include zero, subtraction wrap, 2^160 and field modulus minus one.
- Counter native/recorded equality, real VM replay, rejected underflow, rollback and snapshot restore.
- Witnessed Field Cell with a typed private witness script and metered ledger read; exact native/recorded state, effects, private outputs and query gas, replay, and exhausted-script rollback.
- Invalid byte length and noncanonical all-FF Field input receive explicit JS errors. No Field or large integer crosses the boundary through a JS Number.
- Ten repeated combined scenarios per instance, three Node processes and three browser contexts. Exact outputs match the native receipt.

## Build and resource observations

Rust1.99.0, ABI50, ledger8.0.3, wasm-bindgen0.2.129, wasm-pack0.13.1, wasm32-unknown-unknown. Default runtime features; ledger-transaction is disabled. The actual target-specific feature/dependency graph, imported functions and target_features section are retained below. Installed LLVM Clang and llvm-ar are required by blst in this host setup; Apple Clang lacked this target.

Dev artifact: **9,860,409 bytes**, **1,015,109 bytes gzip**. This is an unoptimized experimental artifact with a large name section, not a release-size estimate. All six runs started with 1,441,792 bytes of linear memory and reached an observed 1,507,328 bytes at call boundaries. This excludes JS heap/process RSS and does not bound future inputs.

Startup and call samples are in the receipt. Filesystem/browser caches and concurrent machine load were not controlled; do not infer a speedup or compare engines as a benchmark. Four pure boundary calls precede the first combined scenario.

## Scope and reproducibility

The compiled artifact and all consumer code are retained in [[Attachments/ADR0256-wasm-prototype.zip]]. The archive contains executable JS/Wasm plus source/lock/provenance. The binary attachment was copied as an artifact; this Markdown receipt and all planning were written and byte-verified through Obsidian CLI.

No fake entropy, substitute VM, native subprocess inside JS tests, browser prover, network call or live wallet acceptance. The typed witness adapter is owned Rust test code; it does not sandbox arbitrary host callbacks. We have qualified these small scenarios, not all contracts or all browser engines.

Scratch failures are preserved honestly: initial host Clang target failure; an incorrect Option/Result assumption in the wrapper; a wrapper export named memory colliding with the module memory (renamed wasm_memory); and a native vector harness array/Vec mismatch. None required changing generated Rust or the production runtime.

## Commands

```sh
rustup target add wasm32-unknown-unknown --toolchain 1.99.0
# Generate each of field_arithmetic, persistent_hash, counter_parameter, witnesses_oracle:
compactc --target rust --skip-zk --rust-runtime-root /absolute/compact source.compact output
# Shared target, incremental disabled; actual exact command log retained below.
CC_wasm32_unknown_unknown=/opt/homebrew/opt/llvm/bin/clang \
AR_wasm32_unknown_unknown=/opt/homebrew/opt/llvm/bin/llvm-ar \
RUSTUP_TOOLCHAIN=1.99.0 wasm-pack build /tmp/rust030-wasm-probe --target web --dev --out-dir pkg-web -- --locked --offline -j4
node run-node.mjs
NODE_PATH=/path/to/node_modules node run-browser.cjs
```

## Primary platform references

The Rust target documentation describes host-function limitations and target features; wasm-bindgen documents JS bindings. Actual compatibility conclusions here come from the retained execution results.

- [Rust target guide](https://doc.rust-lang.org/rustc/platform-support/wasm32-unknown-unknown.html)
- [wasm-bindgen guide](https://wasm-bindgen.github.io/wasm-bindgen/print.html)

Archive SHA256: `ca1ad96ceddb5f7c2e6b9faf113482cb7e88b3663f993161d85492e5439a70e0`

## receipt.json

````text
{
  "adr": "0256",
  "issue": 381,
  "parent": 359,
  "source_head": "24fa6639441495858b2d3c5e132182febcb2626d",
  "status": "bounded prototype passed; production unchanged",
  "compiler": "/tmp/compact-adr254/bin/compactc",
  "compiler_sha256": "f5d38979b0e958f11d548fd80babc871d5a2335283c1ceeef77310a790c9d69f",
  "profile": "dev, opt-level0, debug=0, incremental=false, ledger-transaction disabled",
  "runtime_abi": 50,
  "ledger": "8.0.3",
  "node": "v24.14.0",
  "chromium": "151.0.7922.34",
  "target": "wasm32-unknown-unknown",
  "target_features": [
    "+bulk-memory",
    "+bulk-memory-opt",
    "+call-indirect-overlong",
    "+multivalue",
    "+mutable-globals",
    "+nontrapping-fptoint",
    "+reference-types",
    "+sign-ext"
  ],
  "wasm_bytes": 9860409,
  "gzip_level9_mtime0_bytes": 1015109,
  "wasm_imports": [
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_new_typed_b01cb72a8af741a3",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_call_187d372bd5fdd4aa",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_view_9c570f33e8d6ab96",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_respond_c102fabcc79e5ef0",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_close_748f26698dabe269",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_enqueue_4a01c128f9a0de16",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_byobRequest_54f7ce41d584549a",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_close_185286988f30f252",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_then_e71170d78fcf8954",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_resolve_0076e10020304ede",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_new_343a093a3c2ffb4e",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_new_with_byte_offset_and_length_2f5d7fc2a828b74d",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_buffer_56ec2905a66f58b9",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_length_7f3c00c40364105e",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_byteLength_9f985b8373f1f3fe",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_byteOffset_0bd5a6a03553639c",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_set_575d3ddb70fe831d",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_static_accessor_GLOBAL_THIS_10fb7dc1ae063179",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_static_accessor_SELF_0b583911f537483a",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_static_accessor_GLOBAL_266715b9d96ba635",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_static_accessor_WINDOW_d7f903d1508cbdc4",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_run_6e1f787af721bfe6",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_queueMicrotask_9833f9a49df95a49",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_queueMicrotask_a72f977e97f23c5f",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg_static_accessor_CREATE_TASK_7e310091636beacc",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg___wbindgen_throw_41e9ee4f547fc59a",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg___wbindgen_memory_caa4a6165639c8b5",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg___wbindgen_is_function_1f9d30630b8b1d3d",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg___wbindgen_debug_string_4687d8d8c2017d52",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg___wbindgen_is_undefined_8865fb403f8fe9d8",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbg__wbg_cb_unref_dcc1a90847f04c41",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbindgen_init_externref_table",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbindgen_generic_0000000000000001",
      "kind": "function"
    },
    {
      "module": "./compact_wasm_probe_bg.js",
      "name": "__wbindgen_generic_0000000000000002",
      "kind": "function"
    }
  ],
  "wasm_exports": [
    {
      "name": "memory",
      "kind": "memory"
    },
    {
      "name": "__wbg_intounderlyingbytesource_free",
      "kind": "function"
    },
    {
      "name": "__wbg_intounderlyingsink_free",
      "kind": "function"
    },
    {
      "name": "__wbg_intounderlyingsource_free",
      "kind": "function"
    },
    {
      "name": "intounderlyingbytesource_autoAllocateChunkSize",
      "kind": "function"
    },
    {
      "name": "intounderlyingbytesource_cancel",
      "kind": "function"
    },
    {
      "name": "intounderlyingbytesource_pull",
      "kind": "function"
    },
    {
      "name": "intounderlyingbytesource_start",
      "kind": "function"
    },
    {
      "name": "intounderlyingbytesource_type",
      "kind": "function"
    },
    {
      "name": "intounderlyingsink_abort",
      "kind": "function"
    },
    {
      "name": "intounderlyingsink_close",
      "kind": "function"
    },
    {
      "name": "intounderlyingsink_write",
      "kind": "function"
    },
    {
      "name": "intounderlyingsource_cancel",
      "kind": "function"
    },
    {
      "name": "intounderlyingsource_pull",
      "kind": "function"
    },
    {
      "name": "pure",
      "kind": "function"
    },
    {
      "name": "scenarios",
      "kind": "function"
    },
    {
      "name": "wasm_memory",
      "kind": "function"
    },
    {
      "name": "__abort_handler",
      "kind": "global"
    },
    {
      "name": "__instance_terminated",
      "kind": "global"
    },
    {
      "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___js_sys_b550cbf6bc75e07e___Function_fn_wasm_bindgen_baf214f361e9b98d___JsValue_____wasm_bindgen_baf214f361e9b98d___sys__Undefined___js_sys_b550cbf6bc75e07e___Function_fn_wasm_bindgen_baf214f361e9b98d___JsValue_____wasm_bindgen_baf214f361e9b98d___sys__Undefined_______true_",
      "kind": "function"
    },
    {
      "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___wasm_bindgen_baf214f361e9b98d___JsValue__core_608f92abc48d28da___result__Result_____wasm_bindgen_baf214f361e9b98d___JsError___true_",
      "kind": "function"
    },
    {
      "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___bool__true_",
      "kind": "function"
    },
    {
      "name": "__wbindgen_malloc",
      "kind": "function"
    },
    {
      "name": "__wbindgen_realloc",
      "kind": "function"
    },
    {
      "name": "__externref_table_alloc",
      "kind": "function"
    },
    {
      "name": "__wbindgen_externrefs",
      "kind": "table"
    },
    {
      "name": "__wbindgen_exn_store",
      "kind": "function"
    },
    {
      "name": "__wbindgen_destroy_closure",
      "kind": "function"
    },
    {
      "name": "__externref_table_dealloc",
      "kind": "function"
    },
    {
      "name": "__wbindgen_free",
      "kind": "function"
    },
    {
      "name": "__wbindgen_start",
      "kind": "function"
    }
  ],
  "semantic_results": {
    "pure_boundary_cases": 4,
    "large_field": "2^160; also zero, subtraction wrap, field modulus minus one",
    "malformed": "31-byte input and noncanonical all-FF field rejected",
    "counter": "native/recorded state effects gas equality, actual VM replay, underflow and restore",
    "cell": "typed witness plus metered ledger read, native/recorded state effects private gas equality, replay and exhausted-script rollback",
    "repetitions_per_instance": 10,
    "node_instances": 3,
    "browser_instances": 3
  },
  "measurement": {
    "node_startup_ms": [
      47.03333299999999,
      57.202875,
      116.38325
    ],
    "browser_startup_ms": [
      28.899999976158142,
      24.40000009536743,
      25.700000047683716
    ],
    "node_first_scenario_ms": [
      89.226292,
      127.299125,
      118.722625
    ],
    "browser_first_scenario_ms": [
      75.39999997615814,
      76.40000009536743,
      76.40000009536743
    ],
    "initial_memory_bytes": [
      1441792,
      1441792,
      1441792,
      1441792,
      1441792,
      1441792
    ],
    "observed_peak_memory_bytes": [
      1507328,
      1507328,
      1507328,
      1507328,
      1507328,
      1507328
    ],
    "limitations": "Dev artifact only. Startup includes module load/compile/instantiate but caches uncontrolled. Four pure boundary calls precede first combined scenario. Memory is linear-memory pages observed at call boundaries, not process RSS/JS heap or future inputs. Per-run repeated-call samples retained."
  },
  "scratch_corrections": [
    "AppleClang lackedWasm target: used installed LLVMClang/llvm-ar",
    "Field::from_le_bytes returnsOption: corrected scratch wrapper error handling",
    "Export namedmemory collided with actual Wasm memory: renamed scratch bindingwasm_memory",
    "Native vector harness mixedVec andarray: corrected only scratch harness"
  ],
  "production_changes": false,
  "proof_or_network_claim": false,
  "files": {
    "Cargo.toml": {
      "sha256": "d1f7767977669645cee7da3683a10b233329f902da4be7204ddfb44b04a0b457",
      "bytes": 735
    },
    "Cargo.lock": {
      "sha256": "783fc027e78878bee7a09ca400b7e2a753df7e8300053d5b6ca916edbd590fa1",
      "bytes": 82559
    },
    "src/lib.rs": {
      "sha256": "4777b430c1fa91086ca3e0663c4131f95dee54e83ca70c62b90dfe0e0b63ac2b",
      "bytes": 6251
    },
    "src/main.rs": {
      "sha256": "f044192907dca9c57ddcf8f76252769521148e393f37ee0bf165448b41462d03",
      "bytes": 768
    },
    "verify.mjs": {
      "sha256": "a8bd08577df15a6b751a943828af5eb969d72a90092891c3a212533be7487cc5",
      "bytes": 1673
    },
    "run-node.mjs": {
      "sha256": "425ec5d4ccaee1cb7f80a755bfe20a0032411073e2d56c1edea4843e395e807f",
      "bytes": 760
    },
    "run-browser.cjs": {
      "sha256": "05082e2e322d8707332a0554ecf948843eb8b209c2a86165951e14a740fb9869",
      "bytes": 1877
    },
    "native.json": {
      "sha256": "221b106a4a5cf869ca55cb13c267b3a8d477f003df5153787ffb86f2dc5e5faf",
      "bytes": 1530
    },
    "native-pure.json": {
      "sha256": "708d6eed1e0d1df9442d6bfa141f8d448643e8942ce5f2b2ad28e4a1f8840beb",
      "bytes": 1589
    },
    "node-runs.json": {
      "sha256": "42269fc861320df3adb23fca2706adce286d0572bf403dbeade5dea79509c870",
      "bytes": 38070
    },
    "browser-result.json": {
      "sha256": "9882312cd054c7fd897df364315477ee6e7ff10865aec71a3fde234c3958158b",
      "bytes": 6413
    },
    "resolved-packages.json": {
      "sha256": "21caae33fae1b49755c884f35a8c26471d728ac1825894d979f1a3af11be133d",
      "bytes": 43476
    },
    "features-wasm.txt": {
      "sha256": "382be6b3c593186d1f0c5631b8cf16f3bd70197b8f7bb7689b5a1a0c876c214a",
      "bytes": 123116
    },
    "rustc.txt": {
      "sha256": "352d6857968e80a6357a926ac685b9b07f77c479aaafde33e73a53945e802909",
      "bytes": 192
    },
    "clang.txt": {
      "sha256": "5a6bda6fcbe3f68defa76d8b732b0d4eec3337ff2585200c90be6b930c40fac9",
      "bytes": 201
    },
    "pkg-web/compact_wasm_probe.js": {
      "sha256": "d8e206965a0f47204986407596389f864cf50cca30c0edfef127225e99f024e1",
      "bytes": 28479
    },
    "pkg-web/compact_wasm_probe_bg.wasm": {
      "sha256": "3c6d0fae33eadde7669806a0c67fb7adac9ffe02aabb803e9ef42f830075143d",
      "bytes": 9860409
    },
    "field_arithmetic.compact": {
      "sha256": "c89d48211bc4fab2764c85c48f9235df1bf1dadd1edcf7064c47be53e91c93f3",
      "bytes": 871
    },
    "field_arithmetic/contract/lib.rs": {
      "sha256": "a948ed7604c6453fbb9016bf1e801c854421c5c69663d8e4d1febde673cc07c0",
      "bytes": 1378
    },
    "field_arithmetic/contract/Cargo.toml": {
      "sha256": "74c329dd2e839f9a0fc42f1a62ce89d93bed649bf5d92d68fbb24e6d367bd673",
      "bytes": 475
    },
    "field_arithmetic/contract/compact-rust-ir.json": {
      "sha256": "4802d03566e8da02da83a951c7dcadc0e64bcadaefba1345ec2bd9d79798a343",
      "bytes": 1480
    },
    "persistent_hash.compact": {
      "sha256": "de489f56dd68cb70c3d66fd0908a8a4bc4fac5542f75418a01a52d83d0980f40",
      "bytes": 1404
    },
    "persistent_hash/contract/lib.rs": {
      "sha256": "15611666fcd83c74327b69be7d7b647ce2f35608743ac9b2c93208ac561d72c1",
      "bytes": 2188
    },
    "persistent_hash/contract/Cargo.toml": {
      "sha256": "63c318afbf608c5986c1f2830837a617092f808cdbfb36bdf7ebfe86059f71d8",
      "bytes": 473
    },
    "persistent_hash/contract/compact-rust-ir.json": {
      "sha256": "8e698d0172532528fa53ec0dfdd31df9c4d53894abdbdc585a0bb859aed35b33",
      "bytes": 3586
    },
    "counter_parameter.compact": {
      "sha256": "fc47339706358bae1428c1d0373cae15583f2f72f00abecaf1e3cceccf1f4358",
      "bytes": 978
    },
    "counter_parameter/contract/lib.rs": {
      "sha256": "cd660cbd3f418369490fee5b470aa397776f1192547088c482b2543602bc0452",
      "bytes": 13033
    },
    "counter_parameter/contract/Cargo.toml": {
      "sha256": "d3cbf9731e6ed5930e6c670293458626ca9b6f80c60417038b4bf3289a21a9a5",
      "bytes": 477
    },
    "counter_parameter/contract/compact-rust-ir.json": {
      "sha256": "ee4c423f5388f76bfb7e560db42a142ac50c0c52b92d68b7392fb457cc053877",
      "bytes": 2149
    },
    "witnesses_oracle.compact": {
      "sha256": "61b24d39ae57d4ae1c05311d19af9a2e8f094d7f86062e54c89fe3a6eb6ba227",
      "bytes": 1130
    },
    "witnesses_oracle/contract/lib.rs": {
      "sha256": "b33c8cdb19bca0a5ce35832345cf9520c2aac8e37dbb3e52c48a52051a44f9b4",
      "bytes": 8523
    },
    "witnesses_oracle/contract/Cargo.toml": {
      "sha256": "66d65409828219f4ebe2f97b67cee23107e8881ab3a0f691d988dac2d0ef3429",
      "bytes": 475
    },
    "witnesses_oracle/contract/compact-rust-ir.json": {
      "sha256": "9c3c676a86578bb48f63ff7f300ad242d8058fd18be435b12ded1cf3107574b2",
      "bytes": 1586
    }
  }
}

````

## src/lib.rs

````text
use cell_contract::ledger_contract as cell;
use counter_contract::ledger_contract as counter;
use midnight_compact_testkit::{ArtifactIdentity, ContractLab, Environment, WitnessScript};
use midnight_compact_testkit::runtime as rt;
use rt::{BoundedUint, CompactError, Field, context::{ConstructorContext, WitnessContext}, ledger::{ContractAddress, read_root_cell}};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use wasm_bindgen::prelude::*;

fn identity(source: &[u8], generated: &[u8]) -> ArtifactIdentity {
    ArtifactIdentity { source_sha256: Sha256::digest(source).into(), generated_sha256: Sha256::digest(generated).into() }
}
fn environment() -> Environment {
    Environment::new(ContractAddress::default(), Default::default(), [7; 32])
}
fn fail(e: impl std::fmt::Display) -> String { e.to_string() }
fn field_bytes(value: Field) -> String { hex::encode(value.as_le_bytes()) }

pub fn pure_internal(left: &[u8], right: &[u8]) -> Result<String, String> {
    if left.len() != 32 || right.len() != 32 { return Err("field encoding must contain exactly 32 bytes".into()); }
    let left = Field::from_le_bytes(left).ok_or("noncanonical field encoding")?;
    let right = Field::from_le_bytes(right).ok_or("noncanonical field encoding")?;
    let difference = field_contract::pure_circuits::subtract(left, right).map_err(fail)?;
    let product = field_contract::pure_circuits::multiply(left, right).map_err(fail)?;
    let hash = hash_contract::pure_circuits::hash_field(product).map_err(fail)?;
    Ok(json!({"differenceLE":field_bytes(difference),"productLE":field_bytes(product),"hash":hex::encode(hash.into_array())}).to_string())
}
#[wasm_bindgen]
pub fn pure(left: &[u8], right: &[u8]) -> Result<String, JsValue> {
    pure_internal(left, right).map_err(|e| JsValue::from_str(&e))
}

#[derive(Clone)]
struct Private { script: WitnessScript<(), Field>, calls: u64 }
struct Witness;
impl cell::TryWitnesses<Private> for Witness {
    fn fetch_field(&self, context: WitnessContext<'_, Private, cell::LedgerView<'_>>) -> Result<(Private, Field), CompactError> {
        let _observed = context.ledger.v()?;
        let mut private = context.private_state.clone();
        let result = private.script.answer(())?;
        private.calls += 1;
        Ok((private, result))
    }
}
pub fn scenario_internal() -> Result<String, String> {
    let initial = counter::initial_state(ConstructorContext::new(())).map_err(fail)?;
    let mut lab = ContractLab::from_constructor(
        identity(include_bytes!("../counter_parameter.compact"), include_bytes!("../counter_parameter/contract/lib.rs")),
        environment(), initial).map_err(fail)?;
    let start = lab.snapshot();
    let mut native = lab.fork();
    let expected = native.native(|c| counter::increment_by(c, BoundedUint::new(3)?)).map_err(fail)?;
    let actual = lab.recorded(|c| counter::recorded::increment_by(c, BoundedUint::new(3)?)).map_err(fail)?;
    if actual.public_state() != expected.public_state() || actual.effects() != expected.effects() || actual.execution_gas() != expected.execution_gas() { return Err("counter native/replay mismatch".into()); }
    let counter_receipt = json!({
        "value":counter_contract::ledger_slots::round.inspect(actual.public_state().get_ref()).map_err(fail)?.to_string(),
        "executionGas":actual.execution_gas(),
        "replayGas":actual.replay().ok_or("missing replay")?.gas(),
        "program":actual.replay().ok_or("missing replay")?.program(),
    });
    let before = lab.snapshot();
    let error = lab.recorded(|c| counter::recorded::decrement_by(c, BoundedUint::new(4)?)).err().ok_or("underflow accepted")?;
    let underflow = error.execution_error().ok_or("wrong underflow error")?.to_string();
    if lab.snapshot().public_state() != before.public_state() { return Err("rollback failed".into()); }
    lab.restore(&start).map_err(fail)?;
    if counter_contract::ledger_slots::round.inspect(lab.snapshot().public_state().get_ref()).map_err(fail)? != 0 { return Err("restore failed".into()); }
    let private = Private { script: WitnessScript::new([((), Ok(Field::from(42_u64)))]), calls: 0 };
    let initial = cell::initial_state(ConstructorContext::new(private)).map_err(fail)?;
    let mut lab = ContractLab::from_constructor(
        identity(include_bytes!("../witnesses_oracle.compact"), include_bytes!("../witnesses_oracle/contract/lib.rs")),
        environment(), initial).map_err(fail)?;
    let mut native = lab.fork();
    let expected = native.native(|c| cell::pull(c, &Witness)).map_err(fail)?;
    let actual = lab.recorded(|c| cell::recorded::pull(c, &Witness)).map_err(fail)?;
    if actual.public_state() != expected.public_state() || actual.effects() != expected.effects() || actual.execution_gas() != expected.execution_gas() || actual.private_outputs() != expected.private_outputs() { return Err("cell native/replay mismatch".into()); }
    let cell_receipt = json!({
        "valueLE":field_bytes(read_root_cell::<Field,_>(actual.public_state().get_ref(), 0).map_err(fail)?),
        "executionGas":actual.execution_gas(),"replayGas":actual.replay().ok_or("missing replay")?.gas(),
        "program":actual.replay().ok_or("missing replay")?.program(),"privateOutputs":actual.private_outputs(),
        "witnessCalls":lab.private_state().calls,"remainingAnswers":lab.private_state().script.remaining(),
    });
    let before = lab.snapshot();
    let error = lab.recorded(|c| cell::recorded::pull(c, &Witness)).err().ok_or("missing witness accepted")?;
    let exhausted = error.execution_error().ok_or("wrong witness error")?.to_string();
    if lab.snapshot().public_state() != before.public_state() || lab.private_state().calls != 1 { return Err("witness rollback failed".into()); }
    let pure_result: Value = serde_json::from_str(&pure_internal(&Field::from(9_u64).as_le_bytes(), &Field::from(4_u64).as_le_bytes())?).map_err(fail)?;
    Ok(json!({"counter":counter_receipt,"cell":cell_receipt,"underflow":underflow,"witnessExhausted":exhausted,"pure":pure_result}).to_string())
}
#[wasm_bindgen]
pub fn scenarios() -> Result<String, JsValue> { scenario_internal().map_err(|e| JsValue::from_str(&e)) }
#[wasm_bindgen]
pub fn wasm_memory() -> JsValue { wasm_bindgen::memory() }

````

## src/main.rs

````text
use midnight_compact_testkit::runtime::Field;
fn main() {
    let mut large = [0u8;32]; large[20]=1;
    let max = (Field::from(0_u64)-Field::from(1_u64)).as_le_bytes();
    let pairs = [(vec![0;32],vec![0;32]),(Field::from(0_u64).as_le_bytes(),Field::from(1_u64).as_le_bytes()),(large.to_vec(),Field::from(4_u64).as_le_bytes()),(max.clone(),max)];
    let cases:Vec<_> = pairs.into_iter().map(|(a,b)| serde_json::json!({"left":hex::encode(&a),"right":hex::encode(&b),"result":serde_json::from_str::<serde_json::Value>(&compact_wasm_probe::pure_internal(&a,&b).unwrap()).unwrap()})).collect();
    println!("{}",serde_json::json!({"scenario":serde_json::from_str::<serde_json::Value>(&compact_wasm_probe::scenario_internal().unwrap()).unwrap(),"pureCases":cases}));
}

````

## verify.mjs

````text
export function verify(m, expected, pureCases) {
  const beforeBytes = m.wasm_memory().buffer.byteLength;
  for (const row of pureCases) {
    const decode = (s) => Uint8Array.from(s.match(/../g), b => parseInt(b,16));
    if(JSON.stringify(JSON.parse(m.pure(decode(row.left),decode(row.right))))!==JSON.stringify(row.result)) throw Error('lossless boundary mismatch');
  }
  const start = performance.now();
  const actual = JSON.parse(m.scenarios());
  const elapsed = performance.now() - start;
  if (JSON.stringify(actual) !== JSON.stringify(expected)) throw Error('native/wasm scenario mismatch');
  const left = new Uint8Array(32); left[0] = 9;
  const right = new Uint8Array(32); right[0] = 4;
  if (JSON.stringify(JSON.parse(m.pure(left, right))) !== JSON.stringify(expected.pure)) throw Error('pure input mismatch');
  const errors = [];
  for (const [a, b] of [[new Uint8Array(31), right], [new Uint8Array(32).fill(255), right]]) {
    let rejected = false;
    try { m.pure(a,b); } catch (e) { rejected = true; errors.push(String(e)); }
    if (!rejected) throw Error('malformed input accepted');
  }
  let observedPeakBytes = m.wasm_memory().buffer.byteLength;
  const timings = [];
  for (let i=0;i<10;i++) {
    const begin = performance.now();
    if (m.scenarios() !== JSON.stringify(expected)) throw Error('repeated scenario drift');
    timings.push(performance.now()-begin);
    observedPeakBytes = Math.max(observedPeakBytes, m.wasm_memory().buffer.byteLength);
  }
  return {actual, pureBoundaryCases:pureCases.length, errors, firstScenarioMs:elapsed, warmScenarioMs:timings, initialMemoryBytes:beforeBytes, observedPeakBytes, repeatedScenarios:10};
}

````

## run-node.mjs

````text
import fs from 'node:fs';
import {verify} from './verify.mjs';
const start = performance.now();
const m = await import('./pkg-web/compact_wasm_probe.js');
const bytes = fs.readFileSync(new URL('./pkg-web/compact_wasm_probe_bg.wasm', import.meta.url));
const module = await WebAssembly.compile(bytes);
await m.default({module_or_path:module});
const startupMs = performance.now()-start;
const expected = JSON.parse(fs.readFileSync(new URL('./native.json',import.meta.url),'utf8'));
const result = {runtime:process.version,startupMs,imports:WebAssembly.Module.imports(module),exports:WebAssembly.Module.exports(module),...verify(m,expected,JSON.parse(fs.readFileSync(new URL('./native-pure.json',import.meta.url),'utf8')))};
console.log(JSON.stringify(result));

````

## run-browser.cjs

````text
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { chromium } = require('playwright');
(async () => {
  const root = __dirname;
  const server = http.createServer((req, res) => {
    const name = new URL(req.url,'http://127.0.0.1').pathname;
    if (name === '/') {res.setHeader('Content-Type','text/html');res.end('<!doctype html><title>Compact Wasm probe</title>');return;}
    const file = path.resolve(root,'.'+name);
    if (!file.startsWith(root + path.sep) || !fs.existsSync(file)) {res.writeHead(404);res.end();return;}
    const type = file.endsWith('.wasm')?'application/wasm':file.endsWith('.json')?'application/json':'text/javascript';
    res.setHeader('Content-Type',type);fs.createReadStream(file).pipe(res);
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  let browser;
  try {
    browser = await chromium.launch({headless:true});
    const results=[];
    for(let i=0;i<3;i++) {
      const context = await browser.newContext(); const page=await context.newPage();
      await page.goto(`http://127.0.0.1:${server.address().port}`);
      const result=await page.evaluate(async()=>{
        const expected = await (await fetch('/native.json')).json();
        const {verify} = await import('/verify.mjs');
        const start=performance.now();
        const m=await import('/pkg-web/compact_wasm_probe.js');
        await m.default();
        const startupMs=performance.now()-start;
        return {userAgent:navigator.userAgent,startupMs,...verify(m,expected,await (await fetch('/native-pure.json')).json())};
      });
      results.push(result);await context.close();
    }
    console.log(JSON.stringify({browserVersion:browser.version(),results}));
  } finally {if(browser)await browser.close();server.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});

````

## native-pure.json

````text
[{"left":"0000000000000000000000000000000000000000000000000000000000000000","result":{"differenceLE":"0000000000000000000000000000000000000000000000000000000000000000","hash":"66687aadf862bd776c8fc18b8e9f8e20089714856ee233b3902a591d0d5f2925","productLE":"0000000000000000000000000000000000000000000000000000000000000000"},"right":"0000000000000000000000000000000000000000000000000000000000000000"},{"left":"0000000000000000000000000000000000000000000000000000000000000000","result":{"differenceLE":"00000000fffffffffe5bfeff02a4bd5305d8a10908d83933487d9d2953a7ed73","hash":"66687aadf862bd776c8fc18b8e9f8e20089714856ee233b3902a591d0d5f2925","productLE":"0000000000000000000000000000000000000000000000000000000000000000"},"right":"0100000000000000000000000000000000000000000000000000000000000000"},{"left":"0000000000000000000000000000000000000000010000000000000000000000","result":{"differenceLE":"fcffffffffffffffffffffffffffffffffffffff000000000000000000000000","hash":"9c15e4a671eb6e390bdb67ac4441da8ccc9e56afe28b8bcc928fc6f3e552569a","productLE":"0000000000000000000000000000000000000000040000000000000000000000"},"right":"0400000000000000000000000000000000000000000000000000000000000000"},{"left":"00000000fffffffffe5bfeff02a4bd5305d8a10908d83933487d9d2953a7ed73","result":{"differenceLE":"0000000000000000000000000000000000000000000000000000000000000000","hash":"01d0fabd251fcbbe2b93b4b927b26ad2a1a99077152e45ded1e678afa45dbec5","productLE":"0100000000000000000000000000000000000000000000000000000000000000"},"right":"00000000fffffffffe5bfeff02a4bd5305d8a10908d83933487d9d2953a7ed73"}]
````

## node-runs.json

````text
[
  {
    "runtime": "v24.14.0",
    "startupMs": 47.03333299999999,
    "imports": [
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_new_typed_b01cb72a8af741a3",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_call_187d372bd5fdd4aa",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_view_9c570f33e8d6ab96",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_respond_c102fabcc79e5ef0",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_close_748f26698dabe269",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_enqueue_4a01c128f9a0de16",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_byobRequest_54f7ce41d584549a",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_close_185286988f30f252",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_then_e71170d78fcf8954",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_resolve_0076e10020304ede",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_new_343a093a3c2ffb4e",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_new_with_byte_offset_and_length_2f5d7fc2a828b74d",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_buffer_56ec2905a66f58b9",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_length_7f3c00c40364105e",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_byteLength_9f985b8373f1f3fe",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_byteOffset_0bd5a6a03553639c",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_set_575d3ddb70fe831d",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_GLOBAL_THIS_10fb7dc1ae063179",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_SELF_0b583911f537483a",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_GLOBAL_266715b9d96ba635",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_WINDOW_d7f903d1508cbdc4",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_run_6e1f787af721bfe6",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_queueMicrotask_9833f9a49df95a49",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_queueMicrotask_a72f977e97f23c5f",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_CREATE_TASK_7e310091636beacc",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_throw_41e9ee4f547fc59a",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_memory_caa4a6165639c8b5",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_is_function_1f9d30630b8b1d3d",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_debug_string_4687d8d8c2017d52",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_is_undefined_8865fb403f8fe9d8",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg__wbg_cb_unref_dcc1a90847f04c41",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbindgen_init_externref_table",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbindgen_generic_0000000000000001",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbindgen_generic_0000000000000002",
        "kind": "function"
      }
    ],
    "exports": [
      {
        "name": "memory",
        "kind": "memory"
      },
      {
        "name": "__wbg_intounderlyingbytesource_free",
        "kind": "function"
      },
      {
        "name": "__wbg_intounderlyingsink_free",
        "kind": "function"
      },
      {
        "name": "__wbg_intounderlyingsource_free",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_autoAllocateChunkSize",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_cancel",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_pull",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_start",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_type",
        "kind": "function"
      },
      {
        "name": "intounderlyingsink_abort",
        "kind": "function"
      },
      {
        "name": "intounderlyingsink_close",
        "kind": "function"
      },
      {
        "name": "intounderlyingsink_write",
        "kind": "function"
      },
      {
        "name": "intounderlyingsource_cancel",
        "kind": "function"
      },
      {
        "name": "intounderlyingsource_pull",
        "kind": "function"
      },
      {
        "name": "pure",
        "kind": "function"
      },
      {
        "name": "scenarios",
        "kind": "function"
      },
      {
        "name": "wasm_memory",
        "kind": "function"
      },
      {
        "name": "__abort_handler",
        "kind": "global"
      },
      {
        "name": "__instance_terminated",
        "kind": "global"
      },
      {
        "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___js_sys_b550cbf6bc75e07e___Function_fn_wasm_bindgen_baf214f361e9b98d___JsValue_____wasm_bindgen_baf214f361e9b98d___sys__Undefined___js_sys_b550cbf6bc75e07e___Function_fn_wasm_bindgen_baf214f361e9b98d___JsValue_____wasm_bindgen_baf214f361e9b98d___sys__Undefined_______true_",
        "kind": "function"
      },
      {
        "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___wasm_bindgen_baf214f361e9b98d___JsValue__core_608f92abc48d28da___result__Result_____wasm_bindgen_baf214f361e9b98d___JsError___true_",
        "kind": "function"
      },
      {
        "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___bool__true_",
        "kind": "function"
      },
      {
        "name": "__wbindgen_malloc",
        "kind": "function"
      },
      {
        "name": "__wbindgen_realloc",
        "kind": "function"
      },
      {
        "name": "__externref_table_alloc",
        "kind": "function"
      },
      {
        "name": "__wbindgen_externrefs",
        "kind": "table"
      },
      {
        "name": "__wbindgen_exn_store",
        "kind": "function"
      },
      {
        "name": "__wbindgen_destroy_closure",
        "kind": "function"
      },
      {
        "name": "__externref_table_dealloc",
        "kind": "function"
      },
      {
        "name": "__wbindgen_free",
        "kind": "function"
      },
      {
        "name": "__wbindgen_start",
        "kind": "function"
      }
    ],
    "actual": {
      "cell": {
        "executionGas": {
          "bytesDeleted": 36,
          "bytesWritten": 38,
          "computeTime": 2483857785,
          "readTime": 255000000
        },
        "privateOutputs": [
          {
            "alignment": [
              {
                "tag": "atom",
                "value": {
                  "tag": "field"
                }
              }
            ],
            "value": [
              [
                42
              ]
            ]
          }
        ],
        "program": [
          {
            "push": {
              "storage": false,
              "value": {
                "content": {
                  "alignment": [
                    {
                      "tag": "atom",
                      "value": {
                        "length": 1,
                        "tag": "bytes"
                      }
                    }
                  ],
                  "value": [
                    []
                  ]
                },
                "tag": "cell"
              }
            }
          },
          {
            "push": {
              "storage": true,
              "value": {
                "content": {
                  "alignment": [
                    {
                      "tag": "atom",
                      "value": {
                        "tag": "field"
                      }
                    }
                  ],
                  "value": [
                    [
                      42
                    ]
                  ]
                },
                "tag": "cell"
              }
            }
          },
          {
            "ins": {
              "cached": false,
              "n": 1
            }
          }
        ],
        "remainingAnswers": 0,
        "replayGas": {
          "bytesDeleted": 36,
          "bytesWritten": 38,
          "computeTime": 1233942932,
          "readTime": 85000000
        },
        "valueLE": "2a00000000000000000000000000000000000000000000000000000000000000",
        "witnessCalls": 1
      },
      "counter": {
        "executionGas": {
          "bytesDeleted": 36,
          "bytesWritten": 36,
          "computeTime": 1323481916,
          "readTime": 170000000
        },
        "program": [
          {
            "idx": {
              "cached": false,
              "path": [
                {
                  "tag": "value",
                  "value": {
                    "alignment": [
                      {
                        "tag": "atom",
                        "value": {
                          "length": 1,
                          "tag": "bytes"
                        }
                      }
                    ],
                    "value": [
                      []
                    ]
                  }
                }
              ],
              "pushPath": true
            }
          },
          {
            "addi": {
              "immediate": 3
            }
          },
          {
            "ins": {
              "cached": true,
              "n": 1
            }
          }
        ],
        "replayGas": {
          "bytesDeleted": 36,
          "bytesWritten": 36,
          "computeTime": 1323481916,
          "readTime": 170000000
        },
        "value": "3"
      },
      "pure": {
        "differenceLE": "0500000000000000000000000000000000000000000000000000000000000000",
        "hash": "16b0e2b324c1ff8e3dc91395162d67da1e2d71cf42e022a0ad9882e35c3f3ac3",
        "productLE": "2400000000000000000000000000000000000000000000000000000000000000"
      },
      "underflow": "ledger query rejected: Execution(ArithmeticOverflow)",
      "witnessExhausted": "failed assert: witness script exhausted"
    },
    "pureBoundaryCases": 4,
    "errors": [
      "field encoding must contain exactly 32 bytes",
      "noncanonical field encoding"
    ],
    "firstScenarioMs": 89.226292,
    "warmScenarioMs": [
      36.300332999999995,
      33.314374999999984,
      32.691958,
      30.94591600000001,
      30.110000000000014,
      30.761833000000024,
      29.43462500000004,
      28.43183300000004,
      28.960999999999956,
      28.515667000000008
    ],
    "initialMemoryBytes": 1441792,
    "observedPeakBytes": 1507328,
    "repeatedScenarios": 10
  },
  {
    "runtime": "v24.14.0",
    "startupMs": 57.202875,
    "imports": [
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_new_typed_b01cb72a8af741a3",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_call_187d372bd5fdd4aa",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_view_9c570f33e8d6ab96",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_respond_c102fabcc79e5ef0",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_close_748f26698dabe269",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_enqueue_4a01c128f9a0de16",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_byobRequest_54f7ce41d584549a",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_close_185286988f30f252",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_then_e71170d78fcf8954",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_resolve_0076e10020304ede",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_new_343a093a3c2ffb4e",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_new_with_byte_offset_and_length_2f5d7fc2a828b74d",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_buffer_56ec2905a66f58b9",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_length_7f3c00c40364105e",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_byteLength_9f985b8373f1f3fe",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_byteOffset_0bd5a6a03553639c",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_set_575d3ddb70fe831d",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_GLOBAL_THIS_10fb7dc1ae063179",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_SELF_0b583911f537483a",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_GLOBAL_266715b9d96ba635",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_WINDOW_d7f903d1508cbdc4",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_run_6e1f787af721bfe6",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_queueMicrotask_9833f9a49df95a49",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_queueMicrotask_a72f977e97f23c5f",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_CREATE_TASK_7e310091636beacc",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_throw_41e9ee4f547fc59a",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_memory_caa4a6165639c8b5",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_is_function_1f9d30630b8b1d3d",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_debug_string_4687d8d8c2017d52",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_is_undefined_8865fb403f8fe9d8",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg__wbg_cb_unref_dcc1a90847f04c41",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbindgen_init_externref_table",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbindgen_generic_0000000000000001",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbindgen_generic_0000000000000002",
        "kind": "function"
      }
    ],
    "exports": [
      {
        "name": "memory",
        "kind": "memory"
      },
      {
        "name": "__wbg_intounderlyingbytesource_free",
        "kind": "function"
      },
      {
        "name": "__wbg_intounderlyingsink_free",
        "kind": "function"
      },
      {
        "name": "__wbg_intounderlyingsource_free",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_autoAllocateChunkSize",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_cancel",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_pull",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_start",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_type",
        "kind": "function"
      },
      {
        "name": "intounderlyingsink_abort",
        "kind": "function"
      },
      {
        "name": "intounderlyingsink_close",
        "kind": "function"
      },
      {
        "name": "intounderlyingsink_write",
        "kind": "function"
      },
      {
        "name": "intounderlyingsource_cancel",
        "kind": "function"
      },
      {
        "name": "intounderlyingsource_pull",
        "kind": "function"
      },
      {
        "name": "pure",
        "kind": "function"
      },
      {
        "name": "scenarios",
        "kind": "function"
      },
      {
        "name": "wasm_memory",
        "kind": "function"
      },
      {
        "name": "__abort_handler",
        "kind": "global"
      },
      {
        "name": "__instance_terminated",
        "kind": "global"
      },
      {
        "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___js_sys_b550cbf6bc75e07e___Function_fn_wasm_bindgen_baf214f361e9b98d___JsValue_____wasm_bindgen_baf214f361e9b98d___sys__Undefined___js_sys_b550cbf6bc75e07e___Function_fn_wasm_bindgen_baf214f361e9b98d___JsValue_____wasm_bindgen_baf214f361e9b98d___sys__Undefined_______true_",
        "kind": "function"
      },
      {
        "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___wasm_bindgen_baf214f361e9b98d___JsValue__core_608f92abc48d28da___result__Result_____wasm_bindgen_baf214f361e9b98d___JsError___true_",
        "kind": "function"
      },
      {
        "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___bool__true_",
        "kind": "function"
      },
      {
        "name": "__wbindgen_malloc",
        "kind": "function"
      },
      {
        "name": "__wbindgen_realloc",
        "kind": "function"
      },
      {
        "name": "__externref_table_alloc",
        "kind": "function"
      },
      {
        "name": "__wbindgen_externrefs",
        "kind": "table"
      },
      {
        "name": "__wbindgen_exn_store",
        "kind": "function"
      },
      {
        "name": "__wbindgen_destroy_closure",
        "kind": "function"
      },
      {
        "name": "__externref_table_dealloc",
        "kind": "function"
      },
      {
        "name": "__wbindgen_free",
        "kind": "function"
      },
      {
        "name": "__wbindgen_start",
        "kind": "function"
      }
    ],
    "actual": {
      "cell": {
        "executionGas": {
          "bytesDeleted": 36,
          "bytesWritten": 38,
          "computeTime": 2483857785,
          "readTime": 255000000
        },
        "privateOutputs": [
          {
            "alignment": [
              {
                "tag": "atom",
                "value": {
                  "tag": "field"
                }
              }
            ],
            "value": [
              [
                42
              ]
            ]
          }
        ],
        "program": [
          {
            "push": {
              "storage": false,
              "value": {
                "content": {
                  "alignment": [
                    {
                      "tag": "atom",
                      "value": {
                        "length": 1,
                        "tag": "bytes"
                      }
                    }
                  ],
                  "value": [
                    []
                  ]
                },
                "tag": "cell"
              }
            }
          },
          {
            "push": {
              "storage": true,
              "value": {
                "content": {
                  "alignment": [
                    {
                      "tag": "atom",
                      "value": {
                        "tag": "field"
                      }
                    }
                  ],
                  "value": [
                    [
                      42
                    ]
                  ]
                },
                "tag": "cell"
              }
            }
          },
          {
            "ins": {
              "cached": false,
              "n": 1
            }
          }
        ],
        "remainingAnswers": 0,
        "replayGas": {
          "bytesDeleted": 36,
          "bytesWritten": 38,
          "computeTime": 1233942932,
          "readTime": 85000000
        },
        "valueLE": "2a00000000000000000000000000000000000000000000000000000000000000",
        "witnessCalls": 1
      },
      "counter": {
        "executionGas": {
          "bytesDeleted": 36,
          "bytesWritten": 36,
          "computeTime": 1323481916,
          "readTime": 170000000
        },
        "program": [
          {
            "idx": {
              "cached": false,
              "path": [
                {
                  "tag": "value",
                  "value": {
                    "alignment": [
                      {
                        "tag": "atom",
                        "value": {
                          "length": 1,
                          "tag": "bytes"
                        }
                      }
                    ],
                    "value": [
                      []
                    ]
                  }
                }
              ],
              "pushPath": true
            }
          },
          {
            "addi": {
              "immediate": 3
            }
          },
          {
            "ins": {
              "cached": true,
              "n": 1
            }
          }
        ],
        "replayGas": {
          "bytesDeleted": 36,
          "bytesWritten": 36,
          "computeTime": 1323481916,
          "readTime": 170000000
        },
        "value": "3"
      },
      "pure": {
        "differenceLE": "0500000000000000000000000000000000000000000000000000000000000000",
        "hash": "16b0e2b324c1ff8e3dc91395162d67da1e2d71cf42e022a0ad9882e35c3f3ac3",
        "productLE": "2400000000000000000000000000000000000000000000000000000000000000"
      },
      "underflow": "ledger query rejected: Execution(ArithmeticOverflow)",
      "witnessExhausted": "failed assert: witness script exhausted"
    },
    "pureBoundaryCases": 4,
    "errors": [
      "field encoding must contain exactly 32 bytes",
      "noncanonical field encoding"
    ],
    "firstScenarioMs": 127.299125,
    "warmScenarioMs": [
      52.66104200000001,
      48.21470800000003,
      46.043875000000014,
      39.748541999999986,
      34.622915999999975,
      30.857000000000028,
      59.55137500000001,
      60.8531670000001,
      84.88254200000006,
      54.28758400000004
    ],
    "initialMemoryBytes": 1441792,
    "observedPeakBytes": 1507328,
    "repeatedScenarios": 10
  },
  {
    "runtime": "v24.14.0",
    "startupMs": 116.38325,
    "imports": [
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_new_typed_b01cb72a8af741a3",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_call_187d372bd5fdd4aa",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_view_9c570f33e8d6ab96",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_respond_c102fabcc79e5ef0",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_close_748f26698dabe269",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_enqueue_4a01c128f9a0de16",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_byobRequest_54f7ce41d584549a",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_close_185286988f30f252",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_then_e71170d78fcf8954",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_resolve_0076e10020304ede",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_new_343a093a3c2ffb4e",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_new_with_byte_offset_and_length_2f5d7fc2a828b74d",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_buffer_56ec2905a66f58b9",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_length_7f3c00c40364105e",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_byteLength_9f985b8373f1f3fe",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_byteOffset_0bd5a6a03553639c",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_set_575d3ddb70fe831d",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_GLOBAL_THIS_10fb7dc1ae063179",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_SELF_0b583911f537483a",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_GLOBAL_266715b9d96ba635",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_WINDOW_d7f903d1508cbdc4",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_run_6e1f787af721bfe6",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_queueMicrotask_9833f9a49df95a49",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_queueMicrotask_a72f977e97f23c5f",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg_static_accessor_CREATE_TASK_7e310091636beacc",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_throw_41e9ee4f547fc59a",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_memory_caa4a6165639c8b5",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_is_function_1f9d30630b8b1d3d",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_debug_string_4687d8d8c2017d52",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg___wbindgen_is_undefined_8865fb403f8fe9d8",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbg__wbg_cb_unref_dcc1a90847f04c41",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbindgen_init_externref_table",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbindgen_generic_0000000000000001",
        "kind": "function"
      },
      {
        "module": "./compact_wasm_probe_bg.js",
        "name": "__wbindgen_generic_0000000000000002",
        "kind": "function"
      }
    ],
    "exports": [
      {
        "name": "memory",
        "kind": "memory"
      },
      {
        "name": "__wbg_intounderlyingbytesource_free",
        "kind": "function"
      },
      {
        "name": "__wbg_intounderlyingsink_free",
        "kind": "function"
      },
      {
        "name": "__wbg_intounderlyingsource_free",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_autoAllocateChunkSize",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_cancel",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_pull",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_start",
        "kind": "function"
      },
      {
        "name": "intounderlyingbytesource_type",
        "kind": "function"
      },
      {
        "name": "intounderlyingsink_abort",
        "kind": "function"
      },
      {
        "name": "intounderlyingsink_close",
        "kind": "function"
      },
      {
        "name": "intounderlyingsink_write",
        "kind": "function"
      },
      {
        "name": "intounderlyingsource_cancel",
        "kind": "function"
      },
      {
        "name": "intounderlyingsource_pull",
        "kind": "function"
      },
      {
        "name": "pure",
        "kind": "function"
      },
      {
        "name": "scenarios",
        "kind": "function"
      },
      {
        "name": "wasm_memory",
        "kind": "function"
      },
      {
        "name": "__abort_handler",
        "kind": "global"
      },
      {
        "name": "__instance_terminated",
        "kind": "global"
      },
      {
        "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___js_sys_b550cbf6bc75e07e___Function_fn_wasm_bindgen_baf214f361e9b98d___JsValue_____wasm_bindgen_baf214f361e9b98d___sys__Undefined___js_sys_b550cbf6bc75e07e___Function_fn_wasm_bindgen_baf214f361e9b98d___JsValue_____wasm_bindgen_baf214f361e9b98d___sys__Undefined_______true_",
        "kind": "function"
      },
      {
        "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___wasm_bindgen_baf214f361e9b98d___JsValue__core_608f92abc48d28da___result__Result_____wasm_bindgen_baf214f361e9b98d___JsError___true_",
        "kind": "function"
      },
      {
        "name": "wasm_bindgen_baf214f361e9b98d___convert__closures_____invoke___bool__true_",
        "kind": "function"
      },
      {
        "name": "__wbindgen_malloc",
        "kind": "function"
      },
      {
        "name": "__wbindgen_realloc",
        "kind": "function"
      },
      {
        "name": "__externref_table_alloc",
        "kind": "function"
      },
      {
        "name": "__wbindgen_externrefs",
        "kind": "table"
      },
      {
        "name": "__wbindgen_exn_store",
        "kind": "function"
      },
      {
        "name": "__wbindgen_destroy_closure",
        "kind": "function"
      },
      {
        "name": "__externref_table_dealloc",
        "kind": "function"
      },
      {
        "name": "__wbindgen_free",
        "kind": "function"
      },
      {
        "name": "__wbindgen_start",
        "kind": "function"
      }
    ],
    "actual": {
      "cell": {
        "executionGas": {
          "bytesDeleted": 36,
          "bytesWritten": 38,
          "computeTime": 2483857785,
          "readTime": 255000000
        },
        "privateOutputs": [
          {
            "alignment": [
              {
                "tag": "atom",
                "value": {
                  "tag": "field"
                }
              }
            ],
            "value": [
              [
                42
              ]
            ]
          }
        ],
        "program": [
          {
            "push": {
              "storage": false,
              "value": {
                "content": {
                  "alignment": [
                    {
                      "tag": "atom",
                      "value": {
                        "length": 1,
                        "tag": "bytes"
                      }
                    }
                  ],
                  "value": [
                    []
                  ]
                },
                "tag": "cell"
              }
            }
          },
          {
            "push": {
              "storage": true,
              "value": {
                "content": {
                  "alignment": [
                    {
                      "tag": "atom",
                      "value": {
                        "tag": "field"
                      }
                    }
                  ],
                  "value": [
                    [
                      42
                    ]
                  ]
                },
                "tag": "cell"
              }
            }
          },
          {
            "ins": {
              "cached": false,
              "n": 1
            }
          }
        ],
        "remainingAnswers": 0,
        "replayGas": {
          "bytesDeleted": 36,
          "bytesWritten": 38,
          "computeTime": 1233942932,
          "readTime": 85000000
        },
        "valueLE": "2a00000000000000000000000000000000000000000000000000000000000000",
        "witnessCalls": 1
      },
      "counter": {
        "executionGas": {
          "bytesDeleted": 36,
          "bytesWritten": 36,
          "computeTime": 1323481916,
          "readTime": 170000000
        },
        "program": [
          {
            "idx": {
              "cached": false,
              "path": [
                {
                  "tag": "value",
                  "value": {
                    "alignment": [
                      {
                        "tag": "atom",
                        "value": {
                          "length": 1,
                          "tag": "bytes"
                        }
                      }
                    ],
                    "value": [
                      []
                    ]
                  }
                }
              ],
              "pushPath": true
            }
          },
          {
            "addi": {
              "immediate": 3
            }
          },
          {
            "ins": {
              "cached": true,
              "n": 1
            }
          }
        ],
        "replayGas": {
          "bytesDeleted": 36,
          "bytesWritten": 36,
          "computeTime": 1323481916,
          "readTime": 170000000
        },
        "value": "3"
      },
      "pure": {
        "differenceLE": "0500000000000000000000000000000000000000000000000000000000000000",
        "hash": "16b0e2b324c1ff8e3dc91395162d67da1e2d71cf42e022a0ad9882e35c3f3ac3",
        "productLE": "2400000000000000000000000000000000000000000000000000000000000000"
      },
      "underflow": "ledger query rejected: Execution(ArithmeticOverflow)",
      "witnessExhausted": "failed assert: witness script exhausted"
    },
    "pureBoundaryCases": 4,
    "errors": [
      "field encoding must contain exactly 32 bytes",
      "noncanonical field encoding"
    ],
    "firstScenarioMs": 118.722625,
    "warmScenarioMs": [
      37.382000000000005,
      33.153790999999956,
      32.18595800000003,
      50.74083400000001,
      39.45383399999997,
      36.77687500000002,
      51.10645899999997,
      104.15112499999998,
      58.23804099999995,
      31.750167000000033
    ],
    "initialMemoryBytes": 1441792,
    "observedPeakBytes": 1507328,
    "repeatedScenarios": 10
  }
]

````

## browser-result.json

````text
{"browserVersion":"151.0.7922.34","results":[{"userAgent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36","startupMs":28.899999976158142,"actual":{"cell":{"executionGas":{"bytesDeleted":36,"bytesWritten":38,"computeTime":2483857785,"readTime":255000000},"privateOutputs":[{"alignment":[{"tag":"atom","value":{"tag":"field"}}],"value":[[42]]}],"program":[{"push":{"storage":false,"value":{"content":{"alignment":[{"tag":"atom","value":{"length":1,"tag":"bytes"}}],"value":[[]]},"tag":"cell"}}},{"push":{"storage":true,"value":{"content":{"alignment":[{"tag":"atom","value":{"tag":"field"}}],"value":[[42]]},"tag":"cell"}}},{"ins":{"cached":false,"n":1}}],"remainingAnswers":0,"replayGas":{"bytesDeleted":36,"bytesWritten":38,"computeTime":1233942932,"readTime":85000000},"valueLE":"2a00000000000000000000000000000000000000000000000000000000000000","witnessCalls":1},"counter":{"executionGas":{"bytesDeleted":36,"bytesWritten":36,"computeTime":1323481916,"readTime":170000000},"program":[{"idx":{"cached":false,"path":[{"tag":"value","value":{"alignment":[{"tag":"atom","value":{"length":1,"tag":"bytes"}}],"value":[[]]}}],"pushPath":true}},{"addi":{"immediate":3}},{"ins":{"cached":true,"n":1}}],"replayGas":{"bytesDeleted":36,"bytesWritten":36,"computeTime":1323481916,"readTime":170000000},"value":"3"},"pure":{"differenceLE":"0500000000000000000000000000000000000000000000000000000000000000","hash":"16b0e2b324c1ff8e3dc91395162d67da1e2d71cf42e022a0ad9882e35c3f3ac3","productLE":"2400000000000000000000000000000000000000000000000000000000000000"},"underflow":"ledger query rejected: Execution(ArithmeticOverflow)","witnessExhausted":"failed assert: witness script exhausted"},"pureBoundaryCases":4,"errors":["field encoding must contain exactly 32 bytes","noncanonical field encoding"],"firstScenarioMs":75.39999997615814,"warmScenarioMs":[33.59999990463257,32.800000071525574,31.699999928474426,32.300000071525574,29.699999928474426,29.100000023841858,29.200000047683716,28.199999928474426,28.399999976158142,28.600000023841858],"initialMemoryBytes":1441792,"observedPeakBytes":1507328,"repeatedScenarios":10},{"userAgent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36","startupMs":24.40000009536743,"actual":{"cell":{"executionGas":{"bytesDeleted":36,"bytesWritten":38,"computeTime":2483857785,"readTime":255000000},"privateOutputs":[{"alignment":[{"tag":"atom","value":{"tag":"field"}}],"value":[[42]]}],"program":[{"push":{"storage":false,"value":{"content":{"alignment":[{"tag":"atom","value":{"length":1,"tag":"bytes"}}],"value":[[]]},"tag":"cell"}}},{"push":{"storage":true,"value":{"content":{"alignment":[{"tag":"atom","value":{"tag":"field"}}],"value":[[42]]},"tag":"cell"}}},{"ins":{"cached":false,"n":1}}],"remainingAnswers":0,"replayGas":{"bytesDeleted":36,"bytesWritten":38,"computeTime":1233942932,"readTime":85000000},"valueLE":"2a00000000000000000000000000000000000000000000000000000000000000","witnessCalls":1},"counter":{"executionGas":{"bytesDeleted":36,"bytesWritten":36,"computeTime":1323481916,"readTime":170000000},"program":[{"idx":{"cached":false,"path":[{"tag":"value","value":{"alignment":[{"tag":"atom","value":{"length":1,"tag":"bytes"}}],"value":[[]]}}],"pushPath":true}},{"addi":{"immediate":3}},{"ins":{"cached":true,"n":1}}],"replayGas":{"bytesDeleted":36,"bytesWritten":36,"computeTime":1323481916,"readTime":170000000},"value":"3"},"pure":{"differenceLE":"0500000000000000000000000000000000000000000000000000000000000000","hash":"16b0e2b324c1ff8e3dc91395162d67da1e2d71cf42e022a0ad9882e35c3f3ac3","productLE":"2400000000000000000000000000000000000000000000000000000000000000"},"underflow":"ledger query rejected: Execution(ArithmeticOverflow)","witnessExhausted":"failed assert: witness script exhausted"},"pureBoundaryCases":4,"errors":["field encoding must contain exactly 32 bytes","noncanonical field encoding"],"firstScenarioMs":76.40000009536743,"warmScenarioMs":[34.200000047683716,33.799999952316284,31.5,30.600000023841858,28.700000047683716,28.299999952316284,28.100000023841858,28.199999928474426,29.5,29.5],"initialMemoryBytes":1441792,"observedPeakBytes":1507328,"repeatedScenarios":10},{"userAgent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/151.0.7922.34 Safari/537.36","startupMs":25.700000047683716,"actual":{"cell":{"executionGas":{"bytesDeleted":36,"bytesWritten":38,"computeTime":2483857785,"readTime":255000000},"privateOutputs":[{"alignment":[{"tag":"atom","value":{"tag":"field"}}],"value":[[42]]}],"program":[{"push":{"storage":false,"value":{"content":{"alignment":[{"tag":"atom","value":{"length":1,"tag":"bytes"}}],"value":[[]]},"tag":"cell"}}},{"push":{"storage":true,"value":{"content":{"alignment":[{"tag":"atom","value":{"tag":"field"}}],"value":[[42]]},"tag":"cell"}}},{"ins":{"cached":false,"n":1}}],"remainingAnswers":0,"replayGas":{"bytesDeleted":36,"bytesWritten":38,"computeTime":1233942932,"readTime":85000000},"valueLE":"2a00000000000000000000000000000000000000000000000000000000000000","witnessCalls":1},"counter":{"executionGas":{"bytesDeleted":36,"bytesWritten":36,"computeTime":1323481916,"readTime":170000000},"program":[{"idx":{"cached":false,"path":[{"tag":"value","value":{"alignment":[{"tag":"atom","value":{"length":1,"tag":"bytes"}}],"value":[[]]}}],"pushPath":true}},{"addi":{"immediate":3}},{"ins":{"cached":true,"n":1}}],"replayGas":{"bytesDeleted":36,"bytesWritten":36,"computeTime":1323481916,"readTime":170000000},"value":"3"},"pure":{"differenceLE":"0500000000000000000000000000000000000000000000000000000000000000","hash":"16b0e2b324c1ff8e3dc91395162d67da1e2d71cf42e022a0ad9882e35c3f3ac3","productLE":"2400000000000000000000000000000000000000000000000000000000000000"},"underflow":"ledger query rejected: Execution(ArithmeticOverflow)","witnessExhausted":"failed assert: witness script exhausted"},"pureBoundaryCases":4,"errors":["field encoding must contain exactly 32 bytes","noncanonical field encoding"],"firstScenarioMs":76.40000009536743,"warmScenarioMs":[34.799999952316284,34.300000071525574,32.199999928474426,30.300000071525574,29.699999928474426,28.300000071525574,28.799999952316284,29,28,27.5],"initialMemoryBytes":1441792,"observedPeakBytes":1507328,"repeatedScenarios":10}]}

````

## rustc.txt

````text
rustc 1.99.0 (b940084d7 2026-09-28)
binary: rustc
commit-hash: b940084d7eb6a299eb4bfeb8e34901bc051e7ac4
commit-date: 2026-09-28
host: aarch64-apple-darwin
release: 1.99.0
LLVM version: 23.1.1

````

## clang.txt

````text
Homebrew clang version 20.1.6
Target: arm64-apple-darwin25.2.0
Thread model: posix
InstalledDir: /opt/homebrew/Cellar/llvm/20.1.6/bin
Configuration file: /opt/homebrew/etc/clang/arm64-apple-darwin.cfg

````

## rust030-wasm-initial.log

````text
   Compiling unicode-ident v1.0.26
   Compiling proc-macro2 v1.0.107
   Compiling quote v1.0.47
   Compiling wasm-bindgen-shared v0.2.129
    Checking cfg-if v1.0.5
    Checking memchr v2.8.3
    Checking futures-core v0.3.34
   Compiling rustversion v1.0.23
    Checking once_cell v1.21.4
    Checking futures-sink v0.3.34
   Compiling syn v3.0.6
   Compiling syn v2.0.119
    Checking pin-project-lite v0.2.17
    Checking futures-channel v0.3.34
    Checking futures-io v0.3.34
    Checking futures-task v0.3.34
    Checking slab v0.4.12
   Compiling bumpalo v3.20.3
   Compiling wasm-bindgen v0.2.129
   Compiling version_check v0.9.5
   Compiling generic-array v0.14.7
    Checking typenum v1.20.1
    Checking subtle v2.6.1
    Checking const-oid v0.9.6
   Compiling wasm-bindgen-macro-support v0.2.129
   Compiling serde_core v1.0.229
   Compiling zeroize_derive v1.5.0
   Compiling futures-macro v0.3.34
    Checking zeroize v1.9.1
    Checking futures-util v0.3.34
   Compiling zerocopy v0.8.60
   Compiling serde v1.0.229
    Checking block-buffer v0.10.4
    Checking crypto-common v0.1.7
   Compiling serde_derive v1.0.229
   Compiling wasm-bindgen-macro v0.2.129
   Compiling synstructure v0.14.0
    Checking digest v0.10.7
   Compiling zerofrom-derive v0.1.8
   Compiling radium v0.7.0
    Checking js-sys v0.3.106
    Checking zerofrom v0.1.8
    Checking ppv-lite86 v0.2.21
   Compiling yoke-derive v0.8.4
    Checking tap v1.0.1
    Checking stable_deref_trait v1.2.1
   Compiling autocfg v1.5.1
    Checking wyz v0.5.1
    Checking funty v2.0.0
   Compiling zerovec-derive v0.11.6
    Checking yoke v0.8.3
    Checking bitvec v1.1.1
   Compiling displaydoc v0.2.7
    Checking zerovec v0.11.8
   Compiling syn v1.0.109
   Compiling crossbeam-utils v0.8.23
    Checking tinystr v0.8.4
   Compiling num-traits v0.2.19
    Checking litemap v0.8.3
    Checking writeable v0.6.4
   Compiling crossbeam-epoch v0.9.21
    Checking icu_locale_core v2.3.0
    Checking potential_utf v0.1.6
    Checking zerotrie v0.2.5
    Checking sha2 v0.10.9
   Compiling icu_normalizer_data v2.3.0
   Compiling icu_properties_data v2.3.0
    Checking lazy_static v1.5.1
   Compiling zmij v1.0.23
    Checking itoa v1.0.18
   Compiling shlex v2.0.1
   Compiling crossbeam-deque v0.8.8
    Checking utf8_iter v1.0.4
    Checking smallvec v1.16.2
   Compiling find-msvc-tools v0.1.14
    Checking either v1.19.0
   Compiling cc v1.6.0
    Checking icu_collections v2.3.0
    Checking getrandom v0.2.17
    Checking rand_core v0.6.4
    Checking rand_chacha v0.3.1
    Checking rand v0.8.5
    Checking ff v0.13.1
    Checking rand_xorshift v0.3.0
    Checking group v0.13.0
    Checking icu_provider v2.3.1
    Checking der v0.7.10
   Compiling tracing-attributes v0.1.31
    Checking tracing-core v0.1.36
   Compiling rayon-core v1.13.0
   Compiling serde_json v1.0.151
    Checking tracing v0.1.44
   Compiling num-integer v0.1.47
   Compiling blst v0.3.17
    Checking hex v0.4.3
    Checking base16ct v0.2.0
   Compiling ident_case v1.0.1
   Compiling typewit_proc_macros v1.8.1
   Compiling paste v1.0.15
   Compiling fnv v1.0.7
   Compiling darling_core v0.20.11
    Checking typewit v1.15.2
    Checking serdect v0.2.0
   Compiling num-bigint v0.4.8
    Checking icu_properties v2.3.0
    Checking icu_normalizer v2.3.0
    Checking spki v0.7.3
    Checking percent-encoding v2.3.2
    Checking form_urlencoded v1.2.2
    Checking pkcs8 v0.10.2
   Compiling halo2derive v0.2.0
    Checking idna_adapter v1.2.2
    Checking rayon v1.12.0
warning: blst@0.3.17: error: unable to create target: 'No available targets are compatible with triple "wasm32-unknown-unknown"'
warning: blst@0.3.17: 1 error generated.
error: failed to run custom build command for `blst v0.3.17`

Caused by:
  process didn't exit successfully: `/tmp/rust030-wasm-target/debug/build/blst-c716ef57ae6fcc3c/build-script-build` (exit status: 1)
  --- stdout
  cargo:rerun-if-env-changed=BLST_TEST_NO_STD
  Using blst source directory /Users/ysh/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/blst-0.3.17/blst
  cargo:rerun-if-changed=/Users/ysh/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/blst-0.3.17/blst/src
  cargo:rerun-if-env-changed=CC_FORCE_DISABLE
  CC_FORCE_DISABLE = None
  cargo:rerun-if-env-changed=CC_wasm32-unknown-unknown
  CC_wasm32-unknown-unknown = None
  cargo:rerun-if-env-changed=CC_wasm32_unknown_unknown
  CC_wasm32_unknown_unknown = None
  cargo:rerun-if-env-changed=TARGET_CC
  TARGET_CC = None
  cargo:rerun-if-env-changed=CC
  CC = None
  cargo:rerun-if-env-changed=CC_ENABLE_DEBUG_OUTPUT
  cargo:rerun-if-env-changed=CRATE_CC_NO_DEFAULTS
  CRATE_CC_NO_DEFAULTS = None
  cargo:rerun-if-env-changed=CFLAGS
  CFLAGS = None
  cargo:rerun-if-env-changed=TARGET_CFLAGS
  TARGET_CFLAGS = None
  cargo:rerun-if-env-changed=CFLAGS_wasm32_unknown_unknown
  CFLAGS_wasm32_unknown_unknown = None
  cargo:rerun-if-env-changed=CFLAGS_wasm32-unknown-unknown
  CFLAGS_wasm32-unknown-unknown = None
  cargo:rerun-if-env-changed=CRATE_CC_NO_DEFAULTS
  CRATE_CC_NO_DEFAULTS = None
  cargo:rerun-if-env-changed=CFLAGS
  CFLAGS = None
  cargo:rerun-if-env-changed=TARGET_CFLAGS
  TARGET_CFLAGS = None
  cargo:rerun-if-env-changed=CFLAGS_wasm32_unknown_unknown
  CFLAGS_wasm32_unknown_unknown = None
  cargo:rerun-if-env-changed=CFLAGS_wasm32-unknown-unknown
  CFLAGS_wasm32-unknown-unknown = None
  cargo:rerun-if-env-changed=CRATE_CC_NO_DEFAULTS
  CRATE_CC_NO_DEFAULTS = None
  cargo:rerun-if-env-changed=CFLAGS
  CFLAGS = None
  cargo:rerun-if-env-changed=TARGET_CFLAGS
  TARGET_CFLAGS = None
  cargo:rerun-if-env-changed=CFLAGS_wasm32_unknown_unknown
  CFLAGS_wasm32_unknown_unknown = None
  cargo:rerun-if-env-changed=CFLAGS_wasm32-unknown-unknown
  CFLAGS_wasm32-unknown-unknown = None
  cargo:rerun-if-env-changed=CRATE_CC_NO_DEFAULTS
  CRATE_CC_NO_DEFAULTS = None
  cargo:rerun-if-env-changed=CFLAGS
  CFLAGS = None
  cargo:rerun-if-env-changed=TARGET_CFLAGS
  TARGET_CFLAGS = None
  cargo:rerun-if-env-changed=CFLAGS_wasm32_unknown_unknown
  CFLAGS_wasm32_unknown_unknown = None
  cargo:rerun-if-env-changed=CFLAGS_wasm32-unknown-unknown
  CFLAGS_wasm32-unknown-unknown = None
  cargo:rerun-if-env-changed=CRATE_CC_NO_DEFAULTS
  CRATE_CC_NO_DEFAULTS = None
  cargo:rerun-if-env-changed=CFLAGS
  CFLAGS = None
  cargo:rerun-if-env-changed=TARGET_CFLAGS
  TARGET_CFLAGS = None
  cargo:rerun-if-env-changed=CFLAGS_wasm32_unknown_unknown
  CFLAGS_wasm32_unknown_unknown = None
  cargo:rerun-if-env-changed=CFLAGS_wasm32-unknown-unknown
  CFLAGS_wasm32-unknown-unknown = None
  cargo:warning=error: unable to create target: 'No available targets are compatible with triple "wasm32-unknown-unknown"'
  cargo:warning=1 error generated.

  --- stderr


  error occurred in cc-rs: command did not execute successfully (status code exit status: 1): "clang" "-O0" "-ffunction-sections" "-fdata-sections" "--target=wasm32-unknown-unknown" "-Wall" "-Wextra" "-ffreestanding" "-D__BLST_NO_ASM__" "-DSCRATCH_LIMIT=(45 * 1024)" "-o" "/tmp/rust030-wasm-target/wasm32-unknown-unknown/debug/build/blst-e2e930fd209be2ba/out/3ce72ea41a6346fd-server.o" "-c" "/Users/ysh/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/blst-0.3.17/blst/src/server.c"


warning: build failed, waiting for other jobs to finish...

````

## rust030-wasm-llvm.log

````text
   Compiling blst v0.3.17
   Compiling darling_macro v0.20.11
   Compiling paste v1.0.15
    Checking sec1 v0.7.3
    Checking pairing v0.23.0
    Checking serde_arrays v0.2.0
    Checking hmac v0.12.1
    Checking crypto-bigint v0.5.5
    Checking byte-slice-cast v1.2.3
   Compiling crc32fast v1.5.2
    Checking constant_time_eq v0.4.2
    Checking arrayvec v0.7.8
    Checking blake2b_simd v1.0.5
    Checking rfc6979 v0.4.0
   Compiling darling v0.20.11
    Checking elliptic-curve v0.13.8
    Checking idna v1.1.0
    Checking konst_kernel v0.3.15
    Checking const_panic v0.2.17
    Checking signature v2.2.0
    Checking wasm-bindgen-futures v0.4.79
    Checking web-sys v0.3.106
   Compiling midnight-serialize-macros v1.0.0
   Compiling konst_proc_macros v0.3.10
   Compiling parking_lot_core v0.9.12
    Checking adler2 v2.0.1
    Checking bytes v1.12.1
   Compiling anyhow v1.0.104
    Checking ryu v1.0.23
    Checking simd-adler32 v0.3.10
    Checking serde_urlencoded v0.7.1
    Checking miniz_oxide v0.9.1
    Checking http v1.5.0
    Checking konst v0.3.17
   Compiling dummy v0.8.0
    Checking midnight-curves v0.2.0
    Checking ecdsa v0.16.9
    Checking url v2.5.8
    Checking crypto v0.5.1
    Checking serde_bytes v0.11.19
    Checking futures-executor v0.3.34
    Checking sync_wrapper v1.0.2
    Checking equivalent v1.0.2
    Checking allocator-api2 v0.2.21
    Checking static_assertions v1.1.0
    Checking base64 v0.22.1
    Checking deunicode v1.6.2
    Checking scopeguard v1.2.0
    Checking wasm-streams v0.4.2
    Checking foldhash v0.2.0
    Checking fake v2.10.0
    Checking hashbrown v0.16.1
    Checking reqwest v0.12.28
    Checking lock_api v0.4.14
    Checking archery v0.5.0
    Checking futures v0.3.34
    Checking midnight-serialize v1.0.0
    Checking flate2 v1.1.10
    Checking k256 v0.13.4
    Checking midnight-proofs v0.7.0
   Compiling midnight-base-crypto-derive v1.0.0
    Checking atomic-write-file v0.2.3
    Checking const-hex v1.19.3
   Compiling virtue v0.0.18
   Compiling pastey v0.1.1
    Checking ethnum v1.5.3
    Checking fastrand v2.5.0
   Compiling bincode_derive v2.0.1
    Checking tempfile v3.27.0
    Checking parking_lot v0.12.5
    Checking midnight-base-crypto v1.0.0
    Checking lru v0.16.4
   Compiling midnight-storage-macros v1.0.0
    Checking itertools v0.14.0
   Compiling derive-where v1.7.0
    Checking blake2b_halo2 v0.1.0
    Checking sha3-circuit v0.1.0
    Checking sysinfo v0.34.2
    Checking base64 v0.13.1
    Checking rustc-hash v2.1.3
    Checking unty v0.0.4
    Checking bincode v2.0.1
   Compiling unicode-xid v0.0.4
    Checking midnight-circuits v6.0.0
   Compiling synom v0.11.3
   Compiling quote v0.3.15
    Checking midnight-storage-core v1.1.0
   Compiling syn v0.11.11
    Checking rpds v0.13.0
   Compiling midnight-onchain-runtime v3.0.0
   Compiling enum_index_derive v0.2.0
    Checking enum_index v0.2.0
   Compiling midnight-ledger-static v9.0.0
    Checking keccak v0.1.6
    Checking is_sorted v0.1.1
    Checking sha3 v0.10.8
   Compiling midnight-compact-runtime-macros v0.1.0 (/Users/ysh/.codex/worktrees/07ae/compact/runtime-rs-macros)
    Checking midnight-zk-stdlib v1.0.0
    Checking midnight-storage v2.0.1
    Checking midnight-transient-crypto v2.0.1
    Checking midnight-coin-structure v2.0.1
    Checking midnight-onchain-state v3.0.0
    Checking midnight-onchain-vm v3.0.0
    Checking midnight-zswap v8.0.3
    Checking midnight-compact-runtime v0.1.0 (/Users/ysh/.codex/worktrees/07ae/compact/runtime-rs)
    Checking compact-contract-counter-parameter v0.1.0 (/tmp/rust030-testkit-consumer/generated/contract)
    Finished `dev` profile [unoptimized] target(s) in 12.51s

````

## rust030-wasm-build-final.log

````text
[INFO]: 🎯  Checking for the Wasm target...
[INFO]: 🌀  Compiling to Wasm...
   Compiling compact-wasm-probe v0.0.0 (/private/tmp/rust030-wasm-probe)
    Finished `dev` profile [unoptimized] target(s) in 0.49s
[INFO]: ⬇️  Installing wasm-bindgen...
[INFO]: Optional fields missing from Cargo.toml: 'description', 'repository', and 'license'. These are not necessary, but recommended
[INFO]: ✨   Done in 1.04s
[INFO]: 📦   Your wasm pkg is ready to publish at /tmp/rust030-wasm-probe/pkg-web.
[WARN]: ⚠️   There's a newer version of wasm-pack available, the new version is: 0.15.0, you are using: 0.13.1. To update, navigate to: https://rustwasm.github.io/wasm-pack/installer/

````

## rust030-wasm-native-final.log

````text
   Compiling compact-wasm-probe v0.0.0 (/tmp/rust030-wasm-probe)
    Finished `dev` profile [unoptimized] target(s) in 1.07s
     Running `/tmp/rust030-wasm-target/debug/compact-wasm-probe`
{"cell":{"executionGas":{"bytesDeleted":36,"bytesWritten":38,"computeTime":2483857785,"readTime":255000000},"privateOutputs":[{"alignment":[{"tag":"atom","value":{"tag":"field"}}],"value":[[42]]}],"program":[{"push":{"storage":false,"value":{"content":{"alignment":[{"tag":"atom","value":{"length":1,"tag":"bytes"}}],"value":[[]]},"tag":"cell"}}},{"push":{"storage":true,"value":{"content":{"alignment":[{"tag":"atom","value":{"tag":"field"}}],"value":[[42]]},"tag":"cell"}}},{"ins":{"cached":false,"n":1}}],"remainingAnswers":0,"replayGas":{"bytesDeleted":36,"bytesWritten":38,"computeTime":1233942932,"readTime":85000000},"valueLE":"2a00000000000000000000000000000000000000000000000000000000000000","witnessCalls":1},"counter":{"executionGas":{"bytesDeleted":36,"bytesWritten":36,"computeTime":1323481916,"readTime":170000000},"program":[{"idx":{"cached":false,"path":[{"tag":"value","value":{"alignment":[{"tag":"atom","value":{"length":1,"tag":"bytes"}}],"value":[[]]}}],"pushPath":true}},{"addi":{"immediate":3}},{"ins":{"cached":true,"n":1}}],"replayGas":{"bytesDeleted":36,"bytesWritten":36,"computeTime":1323481916,"readTime":170000000},"value":"3"},"pure":{"differenceLE":"0500000000000000000000000000000000000000000000000000000000000000","hash":"16b0e2b324c1ff8e3dc91395162d67da1e2d71cf42e022a0ad9882e35c3f3ac3","productLE":"2400000000000000000000000000000000000000000000000000000000000000"},"underflow":"ledger query rejected: Execution(ArithmeticOverflow)","witnessExhausted":"failed assert: witness script exhausted"}

````
