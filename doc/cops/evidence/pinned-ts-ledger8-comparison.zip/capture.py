from pathlib import Path
import subprocess,json,hashlib,tomllib
s=Path(__file__).parent;r=Path.cwd();l=Path('/Users/ysh/iohk/lg8p');reg=Path('/Users/ysh/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f');records=[]
def save(name,data,origin):
 p=s/'sources'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);records.append({'snapshot':str(p.relative_to(s)),'origin':origin,'sha256':hashlib.sha256(data).hexdigest()})
for ref,paths,repo,prefix in [('eb72a5ab6085bf9b8564cc80c98c973e04825c2d',['runtime/src/index.ts','runtime/package.json','runtime/package-lock.json'],r,'compact-ledger8'),('3e72c13160328368ade84fb4b73fb944caeeb781',['onchain-runtime-wasm/src/lib.rs','onchain-runtime-wasm/src/state.rs','serialize/src/deserializable.rs','serialize/src/util.rs'],l,'onchain-3.0.0'),('615be91b079ed8df4026c1fd75352ea6d49de1a4',['ledger-wasm/src/contract.rs','ledger-wasm/src/lib.rs','onchain-runtime-wasm/src/lib.rs','onchain-runtime-wasm/src/state.rs','serialize/src/deserializable.rs','serialize/src/util.rs'],l,'ledger-8.0.3')]:
 for p in paths:save(prefix+'/'+p,subprocess.check_output(['git','show',ref+':'+p],cwd=repo),{'repo':str(repo),'commit':ref,'path':p})
for rel in ['runtime/node_modules/@midnight-ntwrk/onchain-runtime-v3/package.json','runtime/node_modules/@midnight-ntwrk/onchain-runtime-v3/midnight_onchain_runtime_wasm_bg.js','runtime/node_modules/@midnight-ntwrk/onchain-runtime-v3/onchain-runtime-v3.d.ts','tools/compact-rust-backend/wallet-live/node_modules/@midnight-ntwrk/ledger-v8/package.json','tools/compact-rust-backend/wallet-live/node_modules/@midnight-ntwrk/ledger-v8/midnight_ledger_wasm_bg.js','runtime-rs/src/transaction/decoding.rs','Cargo.lock']:
 save('installed/'+rel,(r/rel).read_bytes(),{'working_path':str(r/rel)})
for rel in ['midnight-serialize-1.0.0/src/deserializable.rs','midnight-serialize-1.0.0/src/util.rs','midnight-serialize-1.0.0/.cargo_vcs_info.json']:
 save('cargo/'+rel,(reg/rel).read_bytes(),{'working_path':str(reg/rel)})
wasm=[]
for p in [r/'runtime/node_modules/@midnight-ntwrk/onchain-runtime-v3/midnight_onchain_runtime_wasm_bg.wasm',r/'tools/compact-rust-backend/wallet-live/node_modules/@midnight-ntwrk/ledger-v8/midnight_ledger_wasm_bg.wasm']:
 wasm.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'copied':False})
locks=tomllib.loads((r/'Cargo.lock').read_text())['package'];packages=[{k:v for k,v in p.items() if k in ['name','version','source','checksum']} for p in locks if p['name'] in ['midnight-ledger','midnight-onchain-runtime','midnight-serialize','midnight-transient-crypto']]
(s/'source-identities.json').write_text(json.dumps({'status':'read-only source comparison; no build/stress test','compact_remote_ledger8':'eb72a5ab6085bf9b8564cc80c98c973e04825c2d','onchain_remote_tag':'3e72c13160328368ade84fb4b73fb944caeeb781','ledger_remote_tag':'615be91b079ed8df4026c1fd75352ea6d49de1a4','local_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'snapshots':records,'installed_wasm_identity_only':wasm,'current_rust_packages':packages},indent=2)+'\n')
