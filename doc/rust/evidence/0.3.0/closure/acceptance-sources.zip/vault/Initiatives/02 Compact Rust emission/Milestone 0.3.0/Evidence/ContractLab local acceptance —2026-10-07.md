# ContractLab local acceptance —2026-10-07

R030-06/#350 accepted locally after ADR0248/0258/0262. Testkit core remains `ceaac44c`; Merkle scenarios `c43e8fd3`; original DID recorded consumer `0b297501` integrates with Point recording `51b9ea43`. The testkit is source-distributed and publish=false.

## Criterion map

1. Explicit environment, typed native/recorded callbacks, deterministic caller fixtures, ordered typed witness answers/errors/journal, snapshots/forks: ADR0248 plus original Counter/Cell/collection tests. `fixture_seed` labels caller fixture provenance; it does not instantiate an RNG.
2. Restore checks snapshot version, declared source/generated hashes, runtime ABI, ledger label, state mode and environment. Owned scenarios/forks are isolated; no global witness registry. Caller hashes are not authenticated provenance.
3. Reports preserve typed output/state/effects and ordered aligned private values, query-summed execution gas and separately reported replay gas. Default Debug omits private payloads. Gas limit is per query, not aggregate replay/call budget.
4. Failure commits no changed owned lab checkpoint. Original DID late timestamp failure is explicitly tested while external witness journal stays observable. No fabricated partial Rust trace and no external-side-effect rollback promise.
5. Counter, witnessed Cell, Set/Map and Merkle demonstrations pass. Original DID native lifecycle plus recorded deactivate passes through actual ContractLab replay, built from original constructor. Passport has89pure/75public/0stateful exports: direct typed pure/codec evidence is applicable, no invented state/proof adapter. Strict proof/application remains a separate optional tier, now demonstrated by an explicit DID proof harness; network tier has no acceptance claim.

Evidence: [[ADR0248 — ContractLab local receipt]], [[ADR0258 — ContractLab Merkle local receipt]], [[ADR0262 — Adopted DID ContractLab local receipt]], [[ContractLab standalone consumer —2026-10-07]], [[Testing generated contracts with ContractLab]]. Full testkit17integrationtests/Clippy pass; original testkit production coverage329/336 (97.92%) remains scoped to that production revision. Two DID-specific lab tests pass at root frozenhead0b297501. Full DID parent remains open (recording3/12); optional proof tiers do not turn lab replay into proof or network certification.

The tested usage guide is drafted in Obsidian, as required by vault-first documentation. Publication and final candidate revalidation remain R030-08/R030-20 obligations and do not change the testkit API acceptance criteria.
