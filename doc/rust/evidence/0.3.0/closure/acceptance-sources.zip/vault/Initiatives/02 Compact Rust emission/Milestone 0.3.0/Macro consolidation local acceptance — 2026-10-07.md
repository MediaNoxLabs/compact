# R030-04 / #348 — selective macro acceptance audit

Initial read-only review, followed by root-authorized scratch-only measurement, 2026-10-07. Repository HEAD at initial review: `6b5e98e8`; measurement head: `91bf9a15` (includes committed ADR0270/271/272). No repository source edits, issue closure or vault updates. ADR269 concurrent WIP is outside this measurement. GitHub issue body saved in `/tmp/rust030-r03004-issue348.json`.

## Recommendation

This parent does not require a new body DSL, a generated named-argument API, general-purpose generic derives, or rewriting every repeated emitter expression. Its bounded technical direction is delivered. The inventory below now consolidates ownership/selected-declined decisions; ADR0272 is committed as `6250d454`; the formerly missing CompactStructRepr expansion/build-cost comparison has completed in scratch at `91bf9a15` (results below). I recommend root review/publish this consolidated inventory and measurement in the vault, then accept #348 at its scoped local milestone boundary. No further production macro work or proof suite is required by these four criteria. Final independent review remains R030-13 scope, not an implied outcome of this internal audit.

## Acceptance matrix

| Exact criterion | Verified evidence | Remaining obligation |
|---|---|---|
| Publish duplication inventory, ownership and selected/declined decisions | ADR0243 separates ordinary frames, argument adapters and body helpers; ADR0257 lists exactly 17 eligible native leaves and exclusions; current named/role probes distinguish application recipe from codegen | Consolidated inventory below is ready for root review/publication; preserve historical decisions. |
| Preserve FAB/hash/ordinal/layout, supported generics, hygiene and source diagnostics; positive/compile-fail expansion tests | ADR0004 historical enum expansion and ordinal/width/FAB checks; ADR0247 macro-owned hygiene, alias positive/negative Cargo consumers; ADR0249 owned representation versus upstream plus malformed lengths/empty/nested structs and actual source-name fixture; current macro tests validate unsupported declarations with `syn::Error::new_spanned`; witness bridge generic Private control | ADR0272 is committed as6250d454:27 macro,3 enum,2 hygiene tests, strict Clippy and real public discriminant rejection/valid control. Link that receipt. Do not say arbitrary generic declarations or every conceivable Rust namespace is supported. Existing syn expansion rejection tests are not all independent Cargo UI tests; actual alias/discriminant external compile failures supply concrete public diagnostics. |
| Prefer functions for shared VM/gas/context; retain actual atoms and upstream programs | `context.rs:366` CircuitFrame::apply and `:388` finish; `recording.rs:295` common verify execution; `recording.rs:829–836` retains actual observed Read value; ADR0257 normal helper reuse preserves recorded/capabilities across 182 fixtures | Consolidate evidence only. Do not invent another macro for these operations. |
| Report expansion/build effects and examples; retaining explicit Rust may be selected | ADR0004 historical enum source reductions, actual expansion, alternating check timings with no speedup claim; ADR0243 five paired scratch frame builds (larger debug rlib), native parity/errors and named FAB/observation test; current named-role probe has source/expanded size, rlib and alternating build timings | Historical measurements remain scoped. Current CompactStructRepr scratch comparison now completes this evidence gap: explicit equivalent impls, upstream equivalence controls, inspected expansion, six accepted warm samples; detailed result below. |

## Consolidated inventory proposal

| Repetition/domain | Owner and selected mechanism | Alternatives/disposition | Evidence and limits |
|---|---|---|---|
| Enum default/field/binary ordinal glue | macros `CompactEnum` plus `CompactCellValue`, common inferred width | Handwritten emitter impls retired; explicit discriminants unsupported | ADR0004; runtime enum tests cover singleton, ordinary, 257 variants; current272 fixes CellValue disagreement. ABI4 was historical introduction, current ABI50. |
| Struct field/binary representation | `CompactStructRepr` owned macro delegates each field to pinned upstream traits | Upstream derives alone declined for source-name hygiene; source-name bans declined | ADR0249. Named concrete structs including empty; no arbitrary generic/tuple/unit/union declaration support. `struct_repr.rs:22–109`, runtime tests `struct_repr.rs:73–175`. |
| Struct/enum Cell/FAB encoding | `CompactCellValue` | No new codec/serialization protocol | Macro lib.rs:77 and expansion checks; runtime struct/enum and macro-hygiene tests. Full macro output is ordinary inspectable Rust. |
| Compact stdlib Merkle conversion glue | three focused Merkle derives | No copied ledger hashing/path algorithm | macros `merkle.rs:23+`; runtime macro_hygiene conversion/depth checks. Concrete source shape; certain member type errors intentionally remain rustc type errors, not a claim of bespoke diagnostic for every shape. |
| Infallible→fallible witness trait adapter | `compact_witness_bridge` small attribute | Handwritten duplicate companion signatures avoided; effectful witness bodies are untouched | `witness_bridge.rs:22–147`; one unbounded `Private`, ordinary methods only, argument order/docs/errors preserved. Not an arbitrary trait adapter. |
| Native query/context/gas transfer | ordinary `CircuitFrame`, generated 17 leaf selection | New macro/body DSL declined | ADR0243/0257; zero increments still query; exclusion is optimization selection, not removal of existing native support. |
| Recorded VM/query/gas mechanics | typed slots/RecordingFrame and canonical ledger program constructors | Body-wide macro declined; actual observed atoms never reconstructed from decoded values | ADR0005 and recording/context code above. Semantic lowering/admission stays compiler-owned. |
| Source argument grouping | ordinary external consumer named records forwarding positional facade | Generated API not yet adopted; codec derive unnecessary; builder/global abstraction-level switch declined | ADR0243 successful microDAO FAB/preparation plus current Cell/DID/passport probes. Current DID wrapper typechecked only; it is not a new DID proof result. |
| Repeated primitive semantic roles | application-owned ordinary newtypes | Automatic role inference from names and role-derive declined | Current named/role probe: swapped typed values fail, but explicit wrong wrapping still possible; no authorization guarantee. |
| Circuit semantic/effect composition | explicit checked compiler plan and ordered generated Rust | Consumer macros intentionally excluded | Existing typed lowering/composition; this parent does not require full DID capability closure. |

## Current CompactStructRepr measurement — executed scratch only

Receipt `/tmp/rust030-struct-repr-measure/receipt.json`, SHA256 `40ce756a2086b6fca1e0556c52fb3a953dbb528f00a468b55ca0effc43c686a3`. Source/head `91bf9a1521321214bf5bdc1bf751dcecb5369a18`, Rust1.99.0, aarch64 macOS, default dev debug, incremental disabled, same runtime/macros paths and pinned registry package graph. Six current production file hashes were unchanged throughout the successful measurement. No product files changed.

Three concrete structs (record with Boolean/Uint8/vector fields, nested record, empty named record) use either explicit ordinary representation impls or CompactStructRepr; field definitions, normal Debug/Clone/Eq derives and public encode function are fixed. This is a deliberately written explicit alternative, **not historical generated output**. No CellValue implementation is changed by this probe; its FAB checks remain the existing runtime suite evidence.

Both variants pass the same upstream field/binary equivalence and checked-decoding test: truncated/trailing fields, invalid bounded member, nested order/roundtrip and empty boundaries. Both expanded files contain exactly nine representation impls (three traits × three structs). The owned derive qualifies paths and checks slices incrementally; the explicit alternative checks total length first. Expanded bytes are not expected to match, but delegation and field order match. Runtime source semantics were not reimplemented in a new library.

| Variant | Source lines / bytes | Expanded lines / bytes | Debug rlib | Warm rebuild median (range) |
|---|---:|---:|---:|---:|
| Explicit impls | 127 / 4,153 | 224 / 7,223 | 246,336 B | 0.305 s (0.304–0.320) |
| CompactStructRepr | 20 / 648 | 290 / 11,635 | 245,144 B | 0.310 s (0.302–0.326) |

One setup pair excluded, then three alternating pairs; each accepted sample force-rebuilt only the scratch library and verified every dependency artifact fresh from Cargo JSON. Tests/expansion/setup are outside the times. `RUSTC_BOOTSTRAP` was used only for temporary expanded-code inspection, never as a consumer requirement. The first attempt correctly rejected a dependency rebuild after expansion toggled fingerprints; that log is preserved and none of its time entered the accepted samples.

The macro reduces handwritten source, while full qualification/check structure increases expanded text in this example. The 1,192-byte smaller debug rlib and overlapping timing ranges do not justify speed, memory, stack, proof, whole-compiler or cross-platform claims. This neutral result supports selective representation ownership and readable source, without an optimization claim.

## Evidence anchors

- `Milestone 0.3.0/backlog.md:57–72`, README.md:131–137: exact acceptance and macro policy.
- ADR0247 + `Evidence/ADR0247 — Macro hygiene local receipt.md`: 23 macro +9 selected runtime tests, alias positive/negative and strict Clippy; commit77c9ee14.
- ADR0249 + its local receipt/regression log: 795 tests/180 packages at ee768a60,177 regenerated fixtures, 26 macro tests and upstream representation controls. Those counts are historical qualification, not a claim about this audit HEAD.
- ADR0257 + its candidate inventory/local receipt: 17 native leaves,269 backend+37 fixture tests,182 freshness, recorded/capability bytes unchanged; commit012fbb44.
- `doc/rust/adr/0004-derive-only-mechanical-rust-representation-rules.md`: historical expansion/cost and no reliable speedup.
- `Milestone 0.3.0/Research/Generated API — Named argument and role-type probes.md`: current application-only API alternatives and exact comparative measurement scope.
- ADR0272: committed6250d454; `Evidence/ADR0272 — Local delivery receipt.md`, exact receipt SHA25617c24a638a0ee5f5115481915ab7b9d0c7d2ada25f786d4b9d8f34b58f753e35. Independent final retest remains parent R030-13 audit scope.

## Closure boundary

Root can resolve #348 after reviewing and publishing this consolidation with the completed measurement and ADR272 receipt; production named arguments are a later separately reviewed API candidate. Do not count parent closure from child count, a checkbox edit, whole-project coverage percentages, or a newer proof gate. No all-platform compile-cost, all-names hygiene, generic macro framework, in-browser runtime or cryptographic security claim follows from this slice.

## Root local acceptance — 2026-10-07

R030-04/#348 is locally accepted at scoped source91bf9a15. Root reviewed the inventory, scratch alternatives and exact measurement/representation receipts, and the latest independent component re-review found F3 resolved with no macro regression. All four frozen criteria have evidence above. Publication of this inventory is in Obsidian under the user's milestone policy; repository guide/ADR publication remains closeout work. Parent audit/final qualification remain open.

This acceptance does not cover the pending generated named-argument API, the concurrent Map-lowering default-worker stack regression, all-platform cost claims or full DID adoption. Those are separate outcomes with explicit remaining gates. Accepted parents become4/20 (20%); CI stabilization still begins at10/20.
