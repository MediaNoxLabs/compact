# Passport adoption acceptance — 2026-10-07

R030-10 / #354 accepted locally. Child #375 / ADR0250 complete. Source baseline remains midnight-vc-passport `2e13b029f7f9e37a7ba1e4d987fdcd8620c4eab3`, declared credential-compact0.2.0 from source `1a65558b9fcc1c3334932464ca23141f82c8e974`; all17 Compact files unchanged.

## Acceptance map

1. Immutable consumer/core/source and lock/tarball integrity: [[ADR0250 — Passport codec and maintained suite receipt]] and original source manifest.
2. All75 public pure exports execute in unedited generated Rust; 202 independent exact cases compare original-release and branch TS profiles with Rust.
3. Required maintained families covered: claim roots, age/date, requests/disclosure, private parts, holder binding, issuance/verification and authorization guards. Pinned upstream package suite passes67tests across8files; build and packed consumer validate four public imports and protocol/codec round trips.
4. Four direct credential/proof cross-language codec vectors compare FAB/alignment/MCV1. Authoritative IR classifies89total pure circuits,75public, zero stateful/ledger/witness exports. There are zero proof-applicable exports in this source family; no recorded/proof/ledger-application claim is made.
5. No failed required primitive remains within these75exports; no source feature was silently omitted. Tests are sampled behavior and maintained-family acceptance, not exhaustive inputs or security certification. R030-11 remains open for other adoption work.

Final implementation tranche `8490847f65137bd219dcf15e0772419c0fea7186`; integrated root gate at `012fbb44f8c4df3c3dc78ee97b209476e4541db8` passed47Rusttests:19passport+28DID, allfeatures/offline/locked. DID native evidence does not close DID recording or compatibility requirements. R030-09 remains open. Final release qualification will rerun relevant tests at its frozen candidate.

Command: `CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=target/compactc-consumer cargo +1.99.0 test --offline --locked -j4 -p compact-rust-did-adoption-fixture -p compact-rust-vc-passport-adoption-fixture --all-features`.

Combined log SHA256 `9dd755ca361716636e8201ea518d30b0be4526a2b60ad80f30241c4270cc3cfb`.

```text
   Compiling midnight-compact-runtime v0.1.0 (/Users/ysh/.codex/worktrees/07ae/compact/runtime-rs)
   Compiling compact-rust-vc-passport-adoption-fixture v0.1.0 (/Users/ysh/.codex/worktrees/07ae/compact/tests-rust-backend/vc-passport-adoption)
   Compiling midnight-compact-testkit v0.1.0 (/Users/ysh/.codex/worktrees/07ae/compact/testkit-rs)
   Compiling compact-rust-did-adoption-fixture v0.1.0 (/Users/ysh/.codex/worktrees/07ae/compact/tests-rust-backend/did-adoption)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 13.19s
     Running unittests lib.rs (target/compactc-consumer/debug/deps/compact_rust_did_adoption_fixture-f0352e77ca64bb80)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/composition.rs (target/compactc-consumer/debug/deps/composition-b7b0b34d7b7200ea)

running 1 test
test independent_typescript_native_recorded_order_state_and_failures ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 2.33s

     Running tests/lifecycle.rs (target/compactc-consumer/debug/deps/lifecycle-a8d8c92e91b6b818)

running 11 tests
test constructor_controller_failure ... ok
test constructor_recovery_failure ... ok
test constructor_timestamp_failure ... ok
test constructor_equal_keys ... ok
test constructor_zero_time ... ok
test constructor ... ok
test constructor_max_time ... ok
test rotation_recovery_and_deactivation ... ok
test aliases_services_and_late_rollback ... ok
test schnorr_crud_and_readonly_verification ... ok
test all_method_and_relation_domains ... ok

test result: ok. 11 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 10.38s

     Running tests/provenance.rs (target/compactc-consumer/debug/deps/provenance-7dba49debc7e0d5d)

running 3 tests
test exact_twelve_direct_pure_exports_and_unique_cases ... ok
test exact_reviewed_native_cohort_and_outcomes ... ok
test capture_source_and_reviewed_test_identities ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.34s

     Running tests/pure_apis.rs (target/compactc-consumer/debug/deps/pure_apis-cdc646170410b092)

running 13 tests
test controller_domain ... ok
test remove_service ... ok
test remove_schnorr_method ... ok
test set_alias ... ok
test recover_controller ... ok
test set_schnorr_method ... ok
test rotate_controller ... ok
test deactivate ... ok
test distinct_operation_domains_for_reviewed_base_calls ... ok
test remove_method ... ok
test set_relation ... ok
test set_service ... ok
test set_method ... ok

test result: ok. 13 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s

     Running unittests lib.rs (target/compactc-consumer/debug/deps/compact_rust_vc_passport_adoption_fixture-bd68948ce30f2a69)

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/age_predicate.rs (target/compactc-consumer/debug/deps/age_predicate-574af2a71d6639fa)

running 1 test
test pinned_passport_age_predicate_matches_dual_typescript_capture ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/bindings.rs (target/compactc-consumer/debug/deps/bindings-e61d8774e592a9b7)

running 2 tests
test holder_and_status_bindings_match_both_typescript_oracles ... ok
test identity_proof_is_rejected_by_each_context ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/codec.rs (target/compactc-consumer/debug/deps/codec-a461c41104c56d56)

running 1 test
test generated_fab_codecs_match_pinned_passport_descriptors_and_transport_frame ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/complete_flow.rs (target/compactc-consumer/debug/deps/complete_flow-13b91ed2fa122356)

running 1 test
test complete_signed_issuance_and_verification_match_dual_typescript ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.05s

     Running tests/private_parts.rs (target/compactc-consumer/debug/deps/private_parts-923015bb386dcc2c)

running 1 test
test private_parts_validation_matches_dual_typescript_capture ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/protocol.rs (target/compactc-consumer/debug/deps/protocol-0ff8fc60158b4264)

running 2 tests
test protocol_envelopes_and_wrappers_match_dual_typescript_capture ... ok
test protocol_roundtrip_guards_match_dual_typescript_capture ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/provenance.rs (target/compactc-consumer/debug/deps/provenance-6e6a6b1a64ac4a0d)

running 3 tests
test dual_typescript_captures_and_export_inventory_remain_exact ... ok
test pinned_source_closure_matches_all_seventeen_hashes ... ok
test oracle_programs_and_captures_match_recorded_provenance ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.04s

     Running tests/pure_oracle.rs (target/compactc-consumer/debug/deps/pure_oracle-5baaf88ba7a1ffc3)

running 3 tests
test constructors_and_hashes_match_independent_ts_capture ... ok
test schema_and_envelope_errors_match_independent_ts_capture ... ok
test context_tags_and_remaining_claim_commitments_match_dual_ts_capture ... ok

test result: ok. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/request_validation.rs (target/compactc-consumer/debug/deps/request_validation-f78d26db7e8229c7)

running 1 test
test family_schema_and_presentation_request_match_dual_typescript_capture ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/roots.rs (target/compactc-consumer/debug/deps/roots-80769161b74b3bc2)

running 2 tests
test body_roots ... ok
test proof_roots ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

     Running tests/signed_flow.rs (target/compactc-consumer/debug/deps/signed_flow-24524a3acbfc8359)

running 2 tests
test valid_signatures_and_tamper_paths_match_pinned_typescript ... ok
test authorization_descriptor_and_issuer_binding_match_pinned_typescript ... ok

test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s

   Doc-tests compact_rust_did_adoption_fixture

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s

   Doc-tests compact_rust_vc_passport_adoption_fixture

running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s


```
