# ADR0329 — Accept the bounded generated API research portfolio

Status: locally accepted; 2026-10-07; R03002/#346. Source checkpoint bf7c719beea14f7532feaf0d57577245f42c98ca.

## Problem and decision
The approved research program asks for measured choices, repeated review after adoption, and human-friendly generated APIs. It does not require promoting a macro/DSL merely because it was prototyped. Existing probes now have a post-DID public API review, a compiled ordinary named-input recipe, current default-worker/effect tests and a qualified cost baseline.

Accept the current local research/design outcome. Retain positional generated APIs, bounded existing CircuitFrame helpers and mechanical derives. Keep generated Args promotion deferred and BindingId/Rc alternatives rejected under their existing ADRs. No new public abstraction-level flag or role inference is introduced. Final frozen-candidate public API/consumer/cost-drift review remains required under R03020/#364.

## Before / after developer choice
```rust
// Generated API remains source-shaped:
pure_circuits::assertValidDigitalPassportAgePredicate(
    credential, presentation, current_day, birth_day, opening, current_date, birth_date,
)?;
// Optional application-owned record makes a repeated call easier to read:
AgePredicateInputs {
    credential, presentation, current_day,
    date_of_birth_days: birth_day, date_of_birth_opening: opening,
    current_date, date_of_birth_date: birth_date,
}.evaluate()?;
```
The full typed wrapper is in the current passport developer guide and exact external recipe archive. It consumes its fields, forwards source order and preserves contract errors. Same-typed role swaps remain possible. This application pattern changes neither emitter/runtime implementation nor ABI.

## Evidence and measured limits
Independent agent acceptance review reverified1799 artifact/log hashes with zero mismatches and five public/emitter surfaces byte-identical to accepted dce3 baseline. Historical frame/Args/derive/lexical probes retain before/after output, ordinary alternatives, diagnostics and costs. Current679-owner local and Linux test cohorts preserve worker/effect controls;197fixture renders are unchanged. Witnessed/DID external tutorials pass3tests with unedited output; passport named-input recipe executes25storedTS cases,6successes/19exact refusals. Accepted ADR0317 portfolio baseline remains source-scoped.

No numerical Args-specific stack peak or runtime latency was measured. The rejected/unpromoted prototype has displayed/expanded/build/diagnostic costs; ordinary-worker passes and portfolio RSS/heap data are separate dimensions. No Args speedup, universal stack bound, cold-dependency timing or TS performance advantage is claimed. Its extra surface and roughly20% displayed-source growth already support deferral; another experiment without a concrete usability hypothesis is unwarranted. This scoped research acceptance does not turn unmeasured dimensions into measurements.

## Final candidate ownership
R03020 must recheck exact final API/source/lock/toolchain/platform identities, clean external consumers, affected semantic/diagnostic gates, full applicable local/remote suites, migration/package/audit results and any matching-candidate cost drift. Publish ADR/probe history and documentation at closeout. Do not refresh rejected historical prototypes only to rewrite their provenance. Parent audit/coverage/security gates remain open, including stoppedADR0285.


## Criterion review
# R030-02 / #346 — local acceptance assessment

Read-only assessment, 2026-10-07, current source `bf7c719beea14f7532feaf0d57577245f42c98ca`. No new experiment, build, test, production edit, issue update or vault mutation was performed for this assessment. This is an agent evidence review, not the milestone's independent external coding-agent audit. ADR0285 remains outside scope.

## Recommendation

**Accept the current local research/design outcome, with an explicit bounded acceptance record and a frozen-release repeat retained under #364.** I found no remaining concrete design-research defect that requires another abstraction experiment. This does not accept the milestone, promote generated Args, establish a new performance improvement, or satisfy the final candidate gates.

The original inventory's four substantive current gaps have now been addressed: post-DID public API review, an actually compiled ordinary named-record recipe, a current joined ordinary-worker cohort, and the accepted performance/resource baseline. Its future final-source/RC language belongs to #364 and must remain executable work, not disappear when #346 closes.

Do not mark the issue as though every candidate received every conceivable metric. In particular, the Args experiment explicitly did **not** measure its own runtime latency or stack footprint. The evidence supports a measured research portfolio and a decision against default promotion; it does not support a per-Args stack optimization claim. If the issue sentence “measure … stack/memory” is intended to require numerical stack and memory measurements for **every rejected, non-promoted candidate**, that stricter interpretation remains unmet. The approved bounded ADRs do not adopt that interpretation: they preserve negative decisions, default-worker controls, separate RSS/heap/resource measurements, and explicit unmeasured dimensions. The acceptance record should say this plainly rather than silently relabel tests as stack measurements.

## Criterion joins

| #346 criterion | Concrete evidence and disposition | Current local result / remaining boundary |
|---|---|---|
| Every candidate records problem, real emitted before/after, ordinary Rust alternative, ownership and ABI implications in an ADR | ADR0243 first distinguishes illustrative proposals from executed Cell/Counter and ordinary microDAO adapter evidence. ADR0257 records actual 17-leaf promotion with unchanged runtime/ABI50/IR20. ADR0249 repairs reproduced source-name failures with an owned derive delegating upstream semantics and explicitly bumps ABI49→50. ADR0276 preserves actual scratch-emitted Cell/DID/passport Args versus positional code and ordinary application alternatives. ADR0281 separately fixes the raw-identifier defect found by that experiment. ADR0284 retains both actual Rc and BindingId alternatives and the decision against promotion. | Locally satisfied as a decision history, not a claim that initial illustrative snippets were measured. Retain those ADRs/artifacts when publishing at closeout. |
| Unedited generated crates in external consumers; displayed/expanded/build/stack-memory/diagnostic evidence | ADR0276 generated bodies/manifests are unedited; deleting only new Args modules restores old code. It measures displayed source, diagnostic-only expansion, paired forced package rebuilds and debug rlibs, plus seven deliberate compile-error classes. ADR0284 measures actual emitter timings/RSS with equal outputs and focused tests. ADR0243/0257 show ordinary frame ownership and bounded semantic/default-worker controls; ADR0297/0317 supplies the accepted phase-separated generated-consumer/heap/resource baseline. Current ADR0324 external W2/D2 examples retain one runtime identity and qualified registry graph; the named passport record retains the exact generated library. | Satisfied for the approved bounded portfolio. Numerical per-Args stack/runtime latency and cold-dependency performance remain unmeasured and unclaimed. Default-worker pass is behavioral stack-boundary evidence, not a measured stack peak. Final frozen-candidate consumer/platform repeat remains #364. |
| Preserve effect/witness order, hygiene, early errors, ordinary debug-worker execution; retain rejected experiments | ADR0243 compares full state/effects/private outputs/gas, zero-budget/malformed-state failures and source-order FAB. ADR0257 preserves ten malformed diagnostics, all recorded bytes and capabilities across its 182-source cohort; 269 backend/37 affected-fixture tests. ADR0276 compares actual prepared DID bytes, Cell state/effects/witness/private/gas and 25 passport cases. ADR0281 refresh verifies both raw-name orders, 26 positional/named binding assertions and four witnessed calls. ADR0284 retains exact 43 outputs/22 errors, 23 focused tests per variant. Current local core runs 679 tests with RUST_MIN_STACK unset; Linux core independently also passes 679. | Locally satisfied for the retained bounded contracts and regressions. No arbitrary-depth safety, new proof qualification or universal semantics claim. Current 197-render receipt covers freshness; it does not replace direct behavioral evidence. |
| Adopt only with measured usability/maintenance benefit; line count/macros alone insufficient | ADR0257 promotes ownership consolidation into existing CircuitFrame, explicitly denying a speedup because paired ranges overlap and scratch rlib grows. ADR0249 promotes a concrete compile defect repair, not aesthetic macro growth. ADR0281 repairs an actually reproduced identifier collision. ADR0276 retains generated Args as an experiment because 24 DID/39 passport records add about 20% displayed source without enough targeted benefit. ADR0284 rejects extra indirection/IDs because output-equivalent timings/RSS show no reliable benefit. | Satisfied. Post-DID review finds no checked planner internals leaking into the public facade and no demonstrated need for another broad API. The new application wrapper solves the identified guide gap without emitter/runtime changes. |
| Prototype selectable abstraction levels against ordinary Rust, derives and small runtime helpers; semantic equivalence, diagnostics, build costs; no promised public switch | ADR0243 compares explicit native result plumbing, existing CircuitFrame and ordinary argument records. ADR0257 delivers the bounded helper choice; ADR0249 owns mechanical derives. ADR0276 supplies an actual scratch compiler variant and ordinary forwarding alternative, with semantic/diagnostic/cost controls. ADR0284 tests another concrete internal representation alternative. Decisions explain why these are separate dimensions rather than a meaningful low/medium/high public switch. | Satisfied as nonblocking research. No public codegen level flag, new DSL, blanket Args expansion or semantic-role inference is delivered. |

## Repeated checkpoints and current drift

1. **Baseline:** ADR0243 executed frame and ordinary named-adapter probes, with actual controls and neutral cost findings.
2. **API/testkit-era:** ADR0257 and ADR0249 production ownership/hygiene slices; ADR0276 actual generated Args experiment and diagnostic matrix. Historical candidate receipt remains at frozen `fca7577b` plus its isolated naming-fix amendment; it is not relabeled current code.
3. **Post DID/passport:** ADR0284 retained representation alternatives, the current post-DID public API inspection, validated W2/D2 guides, and the external age-predicate record test.
4. **Pre-RC repeat:** #364 explicitly freezes source/toolchain/dependencies/contracts and requires current full local/remote checks, clean generated consumers, supported platforms/MSRV/features, migration and audits. The public API usability review should be repeated after that freeze, especially if audit fixes, package versions or exported capabilities change.

I independently compared five relevant current production/public files to accepted measured `dce3c9e9`: native facade, recorded facade, naming allocator, full DID generated library and full passport generated library are byte-identical. From current complete-render/core checkpoint `fba6845f` to current `bf7c719b`, the only tracked change is the bounded workflow push trigger. Therefore no new API behavior or cost is inferred merely from the new Git HEAD.

## Current consumer/effect/freshness evidence

- **Local core:** `fba6845f`, 679 tests, zero failures/ignored/filtered; strict all-target/all-feature four-owner Clippy and workspace fmt. Default worker stack, normal local debug symbols. All 1,758 source identities unchanged. This checks current owner semantics/diagnostics; it is not the entire generated-fixture behavior suite.
- **197 render refresh:** `fba6845f`, 197 roots/destinations, zero stale/failed, 231 resolved Compact source/import files and 1,259 stable identities. Fresh 472 capability records: 416 available, 54 not applicable, two unavailable reducer controls explicitly retained. This is render/source/capability evidence, not 472 proof successes or direct runtime invocations.
- **External W2/D2:** immutable `5efa91c2` SDK snapshot; witnessed tutorial one test and DID lifecycle two tests; strict Clippy/format pass, unedited generated output, 324 qualified registry identities in each graph, one shared runtime identity. This uses the recorded compiler pair, not a claim that its compiler binary equals the later render-refresh binary. Later SDK implementation is unchanged; intervening WitnessScript rustdoc is separately tested by the core cohort.
- **Application named record:** unchanged passport generated library; one integration test executes all 25 retained TS age rows, six accepted and 19 exact captured errors; upstream and branch rows must match. Strict all-target Clippy/fmt pass. Same-typed field swaps remain possible and are documented. No automatic generated Args support is implied.
- **Additional remote check:** `bf7c719b`, first bounded Linux run37601602223 passes the same679 owner tests/lints/fmt and real Rust1.88 backend/Jubjub/standalone checks. It is supplementary host evidence, not full compiler/proof/release qualification.

## Cost interpretation

ADR0276 observed Cell/DID/passport display lines 705→775, 5,173→6,430 and 4,117→5,091; expanded lines 628→685, 9,186→10,041 and 13,750→14,562. Expansion is a separate diagnostic-only rustc observation; it used RUSTC_BOOTSTRAP, unlike ordinary compiled consumers. Its paired build ranges do not establish speedup or a universal regression threshold. No isolated Args runtime/stack measurement was attempted.

ADR0284 actual-emitter RSS ranges overlap (DID roughly41.7–43.0MB; passport28.2–28.9MB); these are process peaks including input/output, not isolated lexical-map allocation counts. Candidate timings do not justify Rc/BindingId promotion.

ADR0317 accepts the scoped dce3 baseline: five same-candidate A/A pairs,136 measured phase-separated rows plus independent heap windows/resource inventory. The approved >10% trigger concerns a matching later candidate's median regression, not this baseline's A/A range. Cold dependencies, stable latency ceilings, p99, TS speed comparisons and controlled prover latency remain unqualified. Source equivalence permits current applicability of that baseline; it does not produce new current-head measurements.

## Explicit remaining work for #364

- Freeze exact final source, compiler binaries, toolchains, locks, contract closures and features; record any API/generation drift since this acceptance.
- Re-run the current public facade/call-site review and clean external examples on the final declared platform/MSRV/feature matrix. Re-run affected semantic/effect/diagnostic gates for actual changes.
- Re-run the full applicable local suite and required remote checks, migration/package/audit retests; retain current generation/behavior/proof dimensions separately.
- Apply the matching-candidate cost policy if final production inputs change. Do not rebuild historical rejected prototypes solely to make their receipt HEAD current.
- Publish decision/probe history and accepted recipe from Obsidian as part of milestone closeout. Keep deferred Args and rejected Rc/BindingId dispositions intact.

None of these future freeze duties is a reason to invent a new codegen experiment now. They are reasons not to label this local outcome a release candidate or milestone completion.

## Verification scope and hashes

This review reverified **1,799 existing artifact/log hash entries** across the ADR0257 receipt(15), ADR0284 receipt(34), original Args logs(96), local core manifest(10),197-refresh manifest(607), named-record manifest(475), and external guides manifest(562): zero mismatches. Counts include repeated evidence and are not unique tests or independent reviews. Original Args receipt and naming-amendment hashes match their recorded ADR values. ADR0243/0249 historical receipts and accepted performance archive are hash-bound below; I did not re-execute them or audit every historical archive member.

Machine-readable evidence map and source comparisons: `/tmp/rust030-api-acceptance-review-data.json`, SHA256 `2ed79b283dc2de5d8610dc694517f37c14f7c0363662bdb88e301cb09c7b220b`.

The table below identifies exact evidence files. It is a join between scoped cohorts, not one fresh whole-HEAD test run.

| Evidence | SHA256 |
|---|---|
| `/tmp/rust030-api-346.json` | `5a1076ddb0623a6911e00e69d56eeef5d1357304a462cc42257cfc2ad02cada7` |
| `/tmp/rust030-api-364.json` | `f8858c609f2dd109c2534c8939c2e2a51318d4b47db4318312486216276e71a7` |
| `/tmp/rust030-api-review-current.md` | `467804f0bc7ea2d68064ecc2d5f23cc1793f78415895a89254657e95317f634d` |
| `/tmp/rust030-abstraction-probes/receipt.json` | `79173905d5641bddb6cdb519c02df3a6ff322fdad92a9167d5d6157465798d22` |
| `/tmp/rust030-abstraction-probes/measurement.json` | `b16577a68acbaf7ecc662086f40a7af5310e78fd8bec3a48fcbc21f93744264b` |
| `/tmp/compact-adr257/receipt.json` | `cae262fa16ba031ec149212f90878b329fc3b0e093c70388a30b7066806d5968` |
| `/tmp/compact-adr249-macro-receipt.json` | `1d53d4e0a38e13ea7c9e723f8ad8b5619a2e8bde6f2a8a54d85d04c7fcddc15f` |
| `/tmp/rust030-adr284/receipt.json` | `474e294356175946d103090ff0c40e8c3819f30ffe7475bde4e2020f192d6f87` |
| `/tmp/rust030-adr284/timing.json` | `16ee1c15c86c151523983e2698d7e4d21c3e20d6942de76d5e9bd834b73f2cc6` |
| `/tmp/rust030-ci-local-core/receipt.json` | `3b5e57ad132bf9608f3a709308781bae208085ba6c43c9383c739aede54427ea` |
| `/tmp/rust030-fixture-refresh-current/receipt.json` | `a255b53f9aff6b6eba8000f34049643757dcc6e84ada82ab40088d6c801d3b17` |
| `/tmp/rust030-guides-validated-324/validation-receipt.json` | `e0f960c5d9fdc7ba74f0195a482ad294632214a0cec4e5c5cb1a62e007a5ff7e` |
| `/tmp/rust030-named-record-guide/evidence/receipt.json` | `fd50f65079ec8238401e456beedcfbfe10929d17f591649a707b11d1796bc04f` |
| `/tmp/rust030-named-record-guide/src/lib.rs` | `482b5b8c7b8858a9e7a516c3ad3af57ecee4089d9927e059599743b16777a738` |
| `/tmp/rust030-ci-remote-bf7c/verification.json` | `3f63dacceec1b8d765e639342583a1b6185951e63b81ac62ed7b8e8d4c038b52` |
| `/Users/ysh/obsidian/midnight/Initiatives/02 Compact Rust emission/Artifacts/rust030-adr0276-generated-arguments-fca7577b/receipt.json` | `24017360c50838542c60c85bcc7a7597cafc731c716eb48063774f268ec42da2` |
| `/Users/ysh/obsidian/midnight/Initiatives/02 Compact Rust emission/Artifacts/rust030-adr0276-generated-arguments-fca7577b/adr281-refresh/receipt.json` | `9c61646cadd373ab2eed5e0508b72dd4fb6e2d386f1460b5cfb3f644876f9478` |
| `/Users/ysh/obsidian/midnight/Initiatives/02 Compact Rust emission/Artifacts/rust030-adr0276-generated-arguments-fca7577b/measurement.json` | `67b4ad3c43d02e2162c75ac6af1eea8b939dc7435233b25acd33d9a28df3d3f8` |
| `/Users/ysh/obsidian/midnight/Initiatives/02 Compact Rust emission/Artifacts/rust030-adr0276-generated-arguments-fca7577b/consumer-measurement.json` | `6a8a4f347494e32cfd18ee32eb5b7dcb395a58918f8e68f6f05583133313487b` |
| `/Users/ysh/obsidian/midnight/Initiatives/02 Compact Rust emission/Artifacts/rust030-adr0276-generated-arguments-fca7577b/expansion.json` | `fe9492b03d25f360115ca9471467698d1b47987dddd406d80e1d5f94b96c1bd4` |
| `/Users/ysh/obsidian/midnight/Initiatives/02 Compact Rust emission/ADRs/ADR-0317 — Accept the scoped performance and resource baseline.md` | `b98cde53bfaae210dfd85bcca869b91504b2dc5439255d4eca5e59328e56ae04` |
| `/Users/ysh/obsidian/midnight/Initiatives/02 Compact Rust emission/Milestone 0.3.0/Research/Performance baseline at dce3c9e9.md` | `3a433aad51bd3dfe574820e78f23bd5bc7aae8d6df6cb9198401a0b580fdf787` |
| `/Users/ysh/obsidian/midnight/Initiatives/02 Compact Rust emission/Milestone 0.3.0/Evidence/ADR0297 — Actual dce3c9e9 performance baseline.zip` | `9607fa57cdb2481241736a611cc79da2e71ea7e3649deb751bc4e906daa97441` |
| `/Users/ysh/obsidian/midnight/Initiatives/02 Compact Rust emission/Milestone 0.3.0/Evidence/ADR0281-0282 raw local evidence.zip` | `0b949c636672131a858285a493db9497795bf9633de5f6659c34a609fc8820dc` |


Archive [[R03002 — Generated API local acceptance review.zip]], SHA256 `4bb27c1d931cc9dfd1bafef8a3938fee31c00c6b95696b92de11a346c8eb05a4`.
