# 0.3.0 approved delivery backlog

Source of truth: Obsidian `midnight`. Approved 2026-10-07. Publish new milestone documentation at closeout. Dependencies are readiness checkpoints, not completion of every prerequisite. Progress: 13/20 original parent outcomes locally accepted, 1 ACC outcome removed; 13/19 required accepted. Current pushed revision is231559f1. ADR0358/#493 fixes confirmed chunked qualified-Set native addressing and wires the fixture into the full local gate; external retests and runtime97.83% changed-line instrumentation pass. ADR0351–0353 deliver checked VM paths, accurate wide-operation diagnostics and explicit encoded-byte admission; external retest found no actionable defects and refreshed changed-line coverage passes for backend (95.11%) and runtime (97.81%). Parent assurance acceptance awaits the explicit decoder-resource disposition. #409 resumed consumer qualification is delivered; parent347 is locally accepted. Latest retained bounded Linux core and actual Rust1.88 receipt is5a9cd356, not the current revision; final qualification remains open. [[0.3.0 acceptance and final-candidate readiness — 2026-10-08]] records the remaining gate order and criterion snapshot.

## R030-01 — Crystallize runtime and compiler domain models

[Issue #345](https://github.com/MediaNoxLabs/compact/issues/345)

**Status:** locally accepted · **Phase:** B · **Outcome:** required

Write the invariant/ownership map, then consolidate one audited domain at a time: resolved lexical identities → structured admission → checked effect plan → Rust AST. Keep upstream ledger/zk as semantic owners; avoid a runtime rewrite.

### Acceptance

- [x] Document ownership of source typing, declared slots, witness work, VM execution, recording, offer binding, proving and observation trust. Identify public vs internal extension points.
- [x] Distinguish not-applicable, malformed/rejected and admitted lowering; diagnostics retain source/callee context and never silently accept after a rejected guard.
- [x] Migrate representative pure, read-only, witnessed branch and funded composition slices with exact old accept/refuse characterization; preserve ordering, short circuit, alignment and policy boundaries.
- [x] Use explicit binding/circuit IDs and typed operands where the probe proves their value; retain source provenance and reject shadow/scope leakage. Keep domain changes in small ADR-led slices.

**Readiness:** R030-16: version-and-source-baseline, R030-18: measurement-baseline

Local acceptance: [[Domain model local acceptance — 2026-10-07]], #345 closed. Representative checked owners and measured lexical-model disposition; universal profile migration is not claimed.

## R030-02 — Improve generated Rust through repeated design probes

[Issue #346](https://github.com/MediaNoxLabs/compact/issues/346)

**Status:** locally accepted · **Phase:** B/C · **Outcome:** required

Run before/after probes at baseline, after the first API/testkit slice, after DID/digital-passport integration and before RC. Research reusable helpers, source-linked names, modules, argument records, derives and allocation/clone behavior.

### Acceptance

- [x] Each candidate records the problem, real emitted before/after code, ordinary Rust alternative, affected emitter/runtime ownership and ABI implications in an ADR.
- [x] Use unedited generated crates in external consumers; measure expanded and displayed source, build time, stack/memory and diagnostics.
- [x] Preserve effect/witness order, variable hygiene, early errors and default debug-worker execution. Keep rejected experiments and their measurements.
- [x] Adopt improvements only with measured usability or maintenance benefit; fewer lines or more macros alone does not pass.
- [x] Prototype selectable generated-code abstraction levels against ordinary Rust, derives and small runtime helpers; record semantic equivalence, diagnostics and build cost. This research is nonblocking and does not promise a new public switch.

**Readiness:** R030-01: first-checked-plan-vertical, R030-06: native-replay-core-ready, R030-18: measurement-baseline


Local acceptance: [[Generated API local acceptance — 2026-10-07]], ADR0329. Metrics cover the approved bounded portfolio; numerical per-Args stack/runtime remain unmeasured and unclaimed. Final frozen-candidate repeat remains R03020/#364.

## R030-03 — Strengthen typed primitives and consumer safety

[Issue #347](https://github.com/MediaNoxLabs/compact/issues/347)

**Status:** locally accepted · **Phase:** B · **Outcome:** required

Prioritize checked scalar/domain conversion, generated circuit argument descriptors, checked offer-policy constructors and narrower helper capabilities; keep runtime checks at untrusted boundaries.

### Acceptance

- [x] List concrete prevented misuses and compare them with the equivalent TS boundary. Use compile-fail tests for static guarantees and malformed-input tests for dynamic guarantees.
- [x] Preserve canonical vs reduced scalar semantics, declared integer bounds, domain separation, verifier/address/input binding and exact offer ownership/allocation.
- [x] Distinguish caller-provided identity, observed provenance and authenticated ownership; avoid claiming types establish finality or wallet authority.
- [x] No new unsafe code in owned runtime; audit dependency unsafe boundaries and FFI separately. No implicit fallback from strict preparation to a weaker policy.

**Readiness:** R030-01: first-checked-plan-vertical, R030-16: version-and-source-baseline, R030-17: threat-model-and-test-seeds

Local acceptance: [[Typed consumer safety local acceptance — 2026-10-08]]. Four criteria reconciled; broader audit/assurance and final-candidate gates remain separate.

## R030-04 — Consolidate mechanical repetition with selective macros and derives

[Issue #348](https://github.com/MediaNoxLabs/compact/issues/348)

**Status:** locally accepted · **Phase:** B/C · **Outcome:** required

Inventory duplicate representation/witness/argument glue and compare ordinary functions, generic helpers, derives and small attributes. Keep semantic analysis and full circuit bodies outside consumer macro magic.

### Acceptance

- [x] Publish a duplication inventory with ownership and selected/declined abstraction decisions.
- [x] Chosen derives/macros preserve FAB/hash/ordinal/layout behavior, generics where supported, hygiene and source-span diagnostics; positive and compile-fail expansion tests exist.
- [x] Prefer normal functions for shared VM/gas/context mechanics; retain actual observed aligned atoms and canonical upstream programs.
- [x] Report macro expansion/build effects and examples. An evidence-backed decision to retain explicit Rust is a valid outcome for a candidate.

**Readiness:** R030-01: first-checked-plan-vertical, R030-02: baseline-codegen-probes, R030-18: measurement-baseline

Local acceptance: [[Macro consolidation local acceptance — 2026-10-07]], #348 closed.

## R030-05 — Resolve concrete SOLID, KISS and DRY design gaps

[Issue #349](https://github.com/MediaNoxLabs/compact/issues/349)

**Status:** locally accepted · **Phase:** B/C · **Outcome:** required

Decompose mixed responsibilities and overlapping semantic evaluators based on measured change risk. Keep interfaces narrow and explicit rather than adding generic trait hierarchies to satisfy slogans.

### Acceptance

- [x] Inventory high-risk coupling and duplicated invariants with file references and tests that characterize them.
- [x] Preserve native/recorded obligations while sharing semantic leaves and checked plans where valid; remove a duplicate only after differential proof.
- [x] New context fields require explicit classification in helper/recording safety boundaries; error handling does not rely on string sniffing.
- [x] Each refactor has a bounded ownership change, no accidental public API break and documented before/after maintenance benefit.
- [x] Decompose recorded.rs, stateful.rs and lib.rs into cohesive domain/component modules with explicit narrow interfaces and nearby relevant tests. Document how engineers navigate ownership; no generic dumping grounds or module-count target.

**Readiness:** R030-01: first-checked-plan-vertical, R030-16: version-and-source-baseline, R030-17: threat-model-and-test-seeds

Local acceptance: [[Component ownership local acceptance — 2026-10-07]], #349 closed. R030-01 was subsequently accepted; R030-17 resource obligations remain open.

## R030-06 — Deliver ContractLab: the generated-contract testkit

[Issue #350](https://github.com/MediaNoxLabs/compact/issues/350)

**Status:** locally accepted · **Outcome:** required

Propose crate midnight-compact-testkit and API ContractLab. Use generated typed methods/witness traits over real ledger-8 execution, without a second VM or a general contract DSL.

### Acceptance

- [x] Native and recorded/replay scenarios support explicit clock/address/gas/identity, deterministic fixture seeds, typed witness answers/errors/journals and owned snapshots/forks.
- [x] Snapshot restore checks version, source/runtime/ledger identities and state mode; parallel scenarios have no global mutable witness registry.
- [x] Call reports preserve typed output, state/effects, ordered operations/private alignment and separately named query/replay gas; private output is redacted by default.
- [x] Failure keeps committed lab state at its checkpoint; do not invent partial VM traces or promise rollback of external witness side effects.
- [x] Optional strict proof/ledger adapter and explicit network tier have separate requirements and receipts. Demonstrate Counter, witnessed Cell, collections, Merkle and the adopted real contracts.

**Readiness:** R030-16: version-and-source-baseline, R030-17: threat-model-and-test-seeds

Local acceptance: [[ContractLab local acceptance —2026-10-07]], #350 closed.

## R030-07 — Establish meaningful generated-code coverage

[Issue #351](https://github.com/MediaNoxLabs/compact/issues/351)

**Status:** locally accepted · **Phase:** B/C · **Outcome:** required

Publish a source/export/case/dimension matrix plus instrumented coverage. Preserve independent TS observations; never infer behavior or proofs from emitted API availability.

### Acceptance

- [x] Classify 100% of pinned required sources/imports/exports and regenerate the release fixture cohort; compilation, execution, replay, proof and network evidence are separate.
- [x] Every required contract export (and constructor, where present) has a direct typed success invocation or intentional error where success is impossible by design; security-sensitive exports also have negative and state-transition cases.
- [x] Cover every enumerated changed semantic/security obligation and effectful branch; no exclusion may conceal a mandatory contract primitive.
- [x] Proposed instrumentation floor: 90% lines in new testkit-owned code and 95% changed lines in owned runtime/backend/testkit code, measured per component after baseline; exclusions require rationale. Generated line/branch coverage is diagnostic alongside export coverage.
- [x] Keep stable line/region reports; branch coverage uses a separately pinned compatible nightly if adopted. Preserve exact toolchain, features, source hashes and denominators.

**Readiness:** R030-06: native-replay-core-ready, R030-16: version-and-source-baseline, R030-17: threat-model-and-test-seeds, R030-19: focused-pipeline-ready

**Local acceptance:** [[Coverage local acceptance — 2026-10-08]]. Separate#361resource assurance and#364final qualification remain open.

## R030-08 — Create developer-friendly Rust backend documentation

[Issue #352](https://github.com/MediaNoxLabs/compact/issues/352)

**Status:** planned · **Phase:** D · **Outcome:** required

Publish a task-oriented guide under doc/rust, rustdoc examples and runnable standalone consumers; separate tutorials from architecture/history.

### Acceptance

- [ ] Cover install/version selection, compile, generated types/witnesses, ContractLab, errors, recording, proof/ledger integration and trust boundaries.
- [ ] Provide DID and digital-passport walkthroughs, ACC scope/status notes (and ledger-8 migration notes only if activated), TS-to-Rust examples, troubleshooting and supported-target/version matrices.
- [ ] All claimed runnable snippets build/test from a clean external directory without checkout-relative runtime paths; compile-fail examples test documented safety constraints.
- [ ] Keep ADRs as decision history and link current guides to the decisions. Document generated API migration and limitations precisely.
- [ ] Maintain draft developer guides and examples in Obsidian during delivery; publish reviewed documentation and the milestone decision/history corpus to the repository at closeout.

**Readiness:** R030-02: baseline-codegen-probes, R030-03: first-typed-safety-vertical, R030-06: native-replay-core-ready, R030-09: adoption-complete, R030-10: adoption-complete, R030-12: activation-or-deferral-recorded, R030-16: version-and-source-baseline

## R030-09 — Adopt Midnight DID v0.7.0

[Issue #353](https://github.com/MediaNoxLabs/compact/issues/353)

**Status:** locally accepted · **Phase:** C · **Outcome:** required

Use the user-selected midnightntwrk/midnight-did v0.7.0 release and its full import closure, compile unchanged Compact to Rust where compatible and port its maintained TS scenario semantics into direct typed Rust tests.

### Acceptance

- [x] Resolve the v0.7.0 tag to an immutable commit and freeze source/import hashes, lockfile, compiler/language/runtime/ledger versions and exported signatures. Later DID releases do not silently replace the user-selected baseline.
- [x] All required constructor/exports compile and execute through unedited generated Rust; no handwritten generated-source patches or disabled authentication.
- [x] Port positive, wrong-authority, duplicate/missing-key, lifecycle and cryptographic-boundary scenarios that exist in the pinned contract; assert typed output, state, failures and witness effects.
- [x] For every proof-applicable export run a valid default-strict proof/verify/ledger-apply case; cover each distinct authorization/effect path and critical lifecycle, with network acceptance separately recorded.
- [x] Every compatibility failure follows R030-11. No unresolved required primitive or export remains at closure.

**Readiness:** R030-01: first-checked-plan-vertical, R030-02: baseline-codegen-probes, R030-03: first-typed-safety-vertical, R030-06: native-replay-core-ready, R030-07: coverage-matrix-ready, R030-11: reducer-workflow-ready, R030-16: version-and-source-baseline

Local acceptance: [[DID and minimal-reproducer local acceptance — 2026-10-07]] at329bf1bc. These checkmarks reflect the already-recorded bounded adoption acceptance; final candidate reruns remain R03020.

## R030-10 — Adopt the latest maintained digital-passport contract

[Issue #354](https://github.com/MediaNoxLabs/compact/issues/354)

**Status:** locally accepted · **Outcome:** required

Use user-selected midnightntwrk/midnight-vc-passport as the integration root. Inspect its latest contributions and follow its actual declared contract/core dependency, preserving the source/import closure and maintained TS tests and consumer scenarios.

### Acceptance

- [x] Pin midnight-vc-passport consumer commit, latest relevant contributions and exact resolved contract/core package and source hashes. Distinguish merged work from open PRs; do not replace the declared dependency with a similarly named repository by assumption.
- [x] All compiled required pure exports compile and execute through unedited generated Rust, including composed imported functions.
- [x] Port claim-root, age/date-boundary, selective-disclosure/request, private-part opening, holder-binding and issuance/verification envelope cases from the pinned pure family. Assert invalid claims/authorization and context matching; do not invent ledger state transitions absent from the source.
- [x] Classify the compiled pure family honestly: direct typed value/error and cross-language codec evidence is mandatory; proof/verify/ledger-apply is required only for actual proof-applicable exports. If none exist, record zero with authoritative compiler metadata; do not fabricate recorded calls or ledger application.
- [x] R030-11 resolves every failed required primitive; no silently narrowed feature set qualifies as adoption.

**Readiness:** R030-01: first-checked-plan-vertical, R030-02: baseline-codegen-probes, R030-03: first-typed-safety-vertical, R030-06: native-replay-core-ready, R030-07: coverage-matrix-ready, R030-11: reducer-workflow-ready, R030-16: version-and-source-baseline

Local acceptance: [[Passport adoption acceptance — 2026-10-07]], #354/#375 closed.

## R030-11 — Turn contract compatibility failures into minimal regression slices

[Issue #355](https://github.com/MediaNoxLabs/compact/issues/355)

**Status:** locally accepted · **Phase:** A/C · **Outcome:** required

Build a reducer/triage workflow joining real source exports to the failing compiler IR, primitive, runtime operation, upstream version and independent oracle evidence.

### Acceptance

- [x] Each failure has original source hash/export/input, expected vs actual behavior, minimized .compact reproducer and first failing layer.
- [x] Create a focused issue and ADR when design changes; add renderer/admission negative tests, a generated-crate behavior test and TS/upstream comparison as appropriate.
- [x] Fix the smallest semantic cause using upstream primitives; for proof-applicable reproducers, prove/verify/default-strict apply the snippet, and always re-run the original contract scenario. Pure/diagnostic/non-proof reproducers retain their legitimate proof refusal or not-applicable classification.
- [x] Unsupported source diagnostics remain typed and actionable; no blanket denylist or fixture-specific name match substitutes for the fix.
- [x] Preserve the full contract regression after minimization, including any failure that exposes a TS/upstream defect rather than a Rust defect.

**Readiness:** R030-06: native-replay-core-ready, R030-16: version-and-source-baseline, R030-19: focused-pipeline-ready

Local acceptance: [[DID and minimal-reproducer local acceptance — 2026-10-07]] at329bf1bc. These checkmarks reflect the already-recorded bounded adoption acceptance; final candidate reruns remain R03020.

## R030-12 — Removed: Passport ACC adoption

[Issue #356](https://github.com/MediaNoxLabs/compact/issues/356) · [[ADR-0316 — Remove ACC adoption while retaining generic backend evidence]]

**Status:** removed-from-initiative · **Outcome:** removed-scope

Owner-authorized removal after ADR0316 construct review found no unique witness/struct/ledger primitive requirement. Not delivered; no ACC follow-up scheduled. Preserve generic tests and history.

- Publish the ADR0316 construct inventory and explicit removal disposition. ACC support is not a release criterion.
- Close ACC adoption/inventory issues as not planned; preserve prior evidence without implying contract acceptance.
- Retain delivered generic Jubjub tests/proofs; track ledger8 block-time support independently at https://github.com/MediaNoxLabs/compact/issues/442.

## R030-13 — Complete internal and independent external audits

[Issue #357](https://github.com/MediaNoxLabs/compact/issues/357)

**Status:** locally accepted · **Phase:** D · **Outcome:** required

Use one requirements/threat-model checklist for architecture, security, correctness, performance and operational behavior, with independent evidence and tracked remediation.

### Acceptance

- [x] Internal review covers semantic ownership, IR/admission, generated output, codecs, witness/privacy, offer/proof/observation trust and failure behavior.
- [x] Independent external coding-agent review uses a separately configured tool/model and exact frozen source; implementing agents do not grade their own changes. The user selected independent external coding-agent review; this is not a human security audit.
- [x] Each finding has severity, reproducer/source evidence, owner, remediation and independent retest; no open critical/high security or correctness finding at closure.
- [x] Medium/low findings have explicit disposition and residual-risk documentation; neither tests nor agent review are called a human security certification.
- [x] Repeat relevant review after fixes and preserve architecture/functional/nonfunctional checklists in the closure bundle.

**Readiness:** R030-01: first-checked-plan-vertical, R030-02: baseline-codegen-probes, R030-03: first-typed-safety-vertical, R030-04: selected-abstractions-reviewed, R030-05: initial-ownership-refactor, R030-06: native-replay-core-ready, R030-07: coverage-matrix-ready, R030-08: consumer-guides-ready, R030-09: adoption-complete, R030-10: adoption-complete, R030-11: reducer-workflow-ready, R030-12: activation-or-deferral-recorded, R030-15: prototype-disposition-recorded, R030-16: version-and-source-baseline, R030-17: threat-model-and-test-seeds, R030-18: measurement-baseline, R030-19: focused-pipeline-ready

**Local acceptance:** [[Source audit local acceptance — 2026-10-08]]. Separate#361resource assurance and#364final qualification remain open.

## R030-14 — Compose the 0.3.0 closure report

[Issue #358](https://github.com/MediaNoxLabs/compact/issues/358)

**Status:** planned · **Phase:** E · **Outcome:** required

Write a publishable engineering report with the final domain model, generated code examples, compatibility matrix, audits, performance and precise coverage/parity evidence.

### Acceptance

- [ ] Map every deliverable, issue, ADR, commit and acceptance criterion to an immutable result or explicit experimental outcome.
- [ ] Include ACC deferred/activated scope and provenance (if activated), direct DID/passport results, code/ABI migration notes and supported target/feature matrices.
- [ ] Separate inventory, sampled behavior, source branch obligations, replay, strict proofs, live runs and WASM feasibility; record failed/rejected approaches.
- [ ] Provide final known limits, audit residuals, local/remote exact-commit results and developer entry points; reconcile Git and Obsidian.
- [ ] Close only after R030-20 passes; documentation does not convert blocked required contract work into completion.

**Readiness:** R030-20: candidate-qualified

## R030-15 — Prototype generated Rust in Node.js and browsers through WASM

[Issue #359](https://github.com/MediaNoxLabs/compact/issues/359)

**Status:** locally accepted · **Outcome:** required (WASM: bounded experimental outcome)

Treat “wast” as WebAssembly wasm, pending correction. Test wasm32-unknown-unknown with thin wasm-bindgen adapters; WASI is a separate comparison, not browser proof.

### Acceptance

- [x] Resolve the exact target-specific dependency/feature graph; dependency presence in Cargo.lock alone is not proof of a target blocker.
- [x] Probe untouched pure arithmetic/hash and Counter/witnessed-Cell generated crates in pinned Node and headless browser engines, using actual VM semantics.
- [x] Test large-integer/bytes marshalling, results/state/replay, witness order and error mapping; no lossy JS Number conversion for Field/u128.
- [x] Record module/import graph, compressed size, startup, peak linear memory and per-call measurements; fixture entropy and production entropy remain separate.
- [x] Exit with a validated supported subset or an exact blocker/minimal reproducer plus proposed dependency boundary. No browser-prover or production WASM support promise follows from feasibility alone.

**Readiness:** R030-01: first-checked-plan-vertical, R030-06: native-replay-core-ready, R030-16: version-and-source-baseline, R030-18: measurement-baseline

**Local acceptance:** ADR0256/#381, native/Node/Chromium probe with exact source, graph, transport, execution and resource receipts. [[ADR0256 — Node and browser WASM receipt]]. Production support remains experimental.

## R030-16 — Define version, compatibility and migration contracts

[Issue #360](https://github.com/MediaNoxLabs/compact/issues/360)

**Status:** locally accepted · **Phase:** A · **Outcome:** required

Keep milestone 0.3.0 separate from compiler 0.31.133, Rust backend/runtime/macros0.2.0 and testkit0.1.0 labels, runtime ABI 50, private IR 20, capability schema 3 and ledger8 pins. ABI 49 is the historical starting baseline. ADR0293/0304 mapping and migration are delivered; ADR0321 supplies current source/feature/MSRV and drift reconciliation.

### Acceptance

- [x] Publish a machine-readable compatibility/source matrix and feature policy for Rust-only, ledger transaction, testkit and experimental WASM consumers.
- [x] Validate the declared MSRV independently from the tested Rust 1.99 toolchain; update the claim or toolchain only with an explicit decision.
- [x] Decide SemVer changes, generated/runtime pairing, ABI/IR migration and deprecated low-level APIs before breaking public consumers.
- [x] Compile old/new compatible consumer fixtures; mismatches fail clearly. A ledger9 package must not enter the ledger8 graph unnoticed. DID declares ledger-v8 8.1.0 while the Rust baseline uses ledger 8.0.3: prove the required compatibility or adopt an explicitly reviewed coherent ledger/zk pin update before DID acceptance.
- [x] Resolve latest-contract policy at implementation start and recheck drift before RC; no moving branch name is the sole provenance.

**Readiness:** 

Local acceptance: [[Compatibility local acceptance — 2026-10-07]]. Current drift check passed2026-10-07; R03020 still requires final frozen-candidate/platform/drift qualification.

## R030-17 — Build adversarial, property and differential assurance

[Issue #361](https://github.com/MediaNoxLabs/compact/issues/361)

**Status:** locally accepted · **Phase:** A/D · **Outcome:** required

Create a threat model and finite semantic obligation registry, then property/fuzz/mutation tests around typed admission, codecs, witness boundaries, offer binding and snapshots.

### Acceptance

- [x] Enumerate malformed IR, scope/slot/type/call mismatches, overflow/canonical scalars, aliasing, invalid FAB, duplicate/foreign offers and observation mismatch cases before changing behavior.
- [x] Use upstream ledger/zk and independent TS captures as applicable; label known oracle/provider disagreements instead of auto-blessing one backend.
- [x] Each owned trust boundary has deterministic seeds and minimized regression corpus; no panic or unbounded resource use for supported untrusted-input APIs.
  - Owner-approved exception (2026-10-08, ADR0359/CoPS-001): raw tagged contract-state/verifier decoding is qualified for explicit encoded-byte admission and its deterministic codec corpus; aggregate decoded heap/object/CPU containment is deferred beyond0.3.0. Transport acquisition and deployment budgets remain caller responsibilities; no total containment guarantee is claimed.
- [x] Fuzzing runs have reproducible seeds/budgets/results; targeted mutants prove important guards are exercised. Do not disable cryptographic validation in acceptance paths.
- [x] Security-critical state transitions and privacy output policies retain explicit positive/negative tests and no open critical/high findings.

**Readiness:** R030-16: version-and-source-baseline


**Local acceptance:** [[Assurance local acceptance — 2026-10-08]]. Explicit decoder scope exception approved by owner; finalcandidate#364remains.
## R030-18 — Set and measure performance and resource budgets

[Issue #362](https://github.com/MediaNoxLabs/compact/issues/362)

**Status:** locally-accepted · **Phase:** A/D · **Outcome:** required

Baseline compile time, generated size, runtime latency, allocations, memory, default-worker stack and proof resources before changing architecture. Treat design wins as measurements.

### Acceptance

- [x] Pin compiler/source/lock/toolchain/target/profile/hardware and separate cold dependency builds, warm generated builds, runtime, proof and startup costs.
- [x] Use small controls plus DID and digital-passport cohorts (ACC only after activation), paired samples and spread; retain the default debug-worker stack regression.
- [x] Proposed regression trigger: >10% median runtime/warm-build/peak-memory increase on controlled matching cases requires investigation and reviewed acceptance, never a single noisy sample verdict.
- [x] Measure circuit/prover rows/k/key size when source changes; For a later activated ACC scope, assess resource feasibility before full key generation.
- [x] Freeze practical ceilings after baseline; publish tradeoffs and rejected macro/helper optimizations rather than asserting Rust always wins.

**Readiness:** R030-16: version-and-source-baseline

Local acceptance: [[ADR-0317 — Accept the scoped performance and resource baseline]]. Existing criterion references to activated ACC are superseded by ADR0316. Final candidate qualification remains separate.

## R030-19 — Make the local delivery pipeline reproducible and efficient

[Issue #363](https://github.com/MediaNoxLabs/compact/issues/363)

**Status:** locally accepted · **Phase:** A/E · **Outcome:** required

Reuse the existing focused gate and immutable compiler handoffs. Add only missing scheduling/provenance/selection facilities, with bounded parallel worktree ownership.

### Acceptance

- [ ] Seal compiler, Scheme runtime, lockfile, generated source and fixture identities in receipts; concurrent slices do not share mutable compiler artifacts.
- [ ] Use affected renderer/generated/TS tests per slice; expand for ABI/schema/effects and full integration checkpoints. Measure checks rather than skipping equivalent assertions by assumption.
- [ ] Keep caches scoped to source/toolchain/features/profile; record command selection and prove generated behavior targets really ran.
- [ ] Capture dependency/license/advisory review and artifact checksums; use locked, reproducible external consumers and explicit provider/material prerequisites.
- [ ] Defer broad remote CI until required local implementation and acceptance prerequisites pass (excluding remote qualification and the final report), then qualify the final revision; keep conventional GPG/DCO commits, ADR→issue→milestone links and vault history.
- [ ] Prefer focused local gates. Begin remote CI stabilization when 10 of the frozen 20 parent outcomes satisfy local acceptance. Child issue closures and deferred ACC do not increase progress; keep final remote qualification at the release candidate.

**Readiness:** R030-16: version-and-source-baseline

Local mechanism acceptance: [[Local delivery pipeline acceptance — 2026-10-07]] at22ef5f23. The criteria above remain the approved text; final-revision execution is still open underR03020, not checked off here.

## R030-20 — Qualify the final release candidate and downstream migration

[Issue #364](https://github.com/MediaNoxLabs/compact/issues/364)

**Status:** planned · **Phase:** E · **Outcome:** required

Freeze one final source/toolchain/dependency/contract cohort and verify independent consumers, supported host platforms, packaged distribution and upgrade paths before calling 0.3.0 complete.

### Acceptance

- [ ] All required deliverables 1–11,13 and 16–19 pass; WASM15 has its documented experimental outcome. ACC12 is removed under ADR0316; publish its removal disposition without an adoption claim. No required DID/digital-passport feature remains unsupported.
- [ ] Run the full applicable local suite and required remote checks at the frozen revision, with artifact provenance and no unrelated dirty source in release inputs.
- [ ] Exercise clean generated-crate consumers on declared supported hosts and the asserted MSRV; qualify default and transaction/testkit feature graphs.
- [ ] Validate runtime/API/ABI migration examples and final audit retests; authenticate package inputs and account for all dependency/advisory dispositions.
- [ ] Produce signed/DCO commit and candidate manifest. Tags, registries, upstream PRs and production deployment require their own explicit publication scope; milestone naming alone is not a compiler or package-version bump.

**Readiness:** R030-01: first-checked-plan-vertical, R030-02: baseline-codegen-probes, R030-03: first-typed-safety-vertical, R030-04: selected-abstractions-reviewed, R030-05: initial-ownership-refactor, R030-06: native-replay-core-ready, R030-07: coverage-matrix-ready, R030-08: consumer-guides-ready, R030-09: adoption-complete, R030-10: adoption-complete, R030-11: reducer-workflow-ready, R030-12: activation-or-deferral-recorded, R030-13: audit-remediation-complete, R030-15: prototype-disposition-recorded, R030-16: version-and-source-baseline, R030-17: threat-model-and-test-seeds, R030-18: measurement-baseline, R030-19: focused-pipeline-ready



## 2026-10-07 — Jubjub only; full ACC deferred by authorized fallback (ADR0314/#439)

The owner also excludes secp256k1 and permits removing full ACC adoption from 0.3.0. [[ADR-0314 — Restrict ACC authorization to Jubjub and bound adoption work]] supersedes ADR0313's retained k256 obligation. The isolated Jubjub-only variant removes 35 k256 exports and four helpers, retains 45 circuit exports and all 25 ledger fields, and preserves retained declarations byte-for-byte. TS generation passes; Rust refuses `Kernel operation blockTimeLessThan`. Full retained-account behavior/recording/proof qualification remains substantial and unaccepted. Use the authorized fallback: defer full ACC beyond 0.3.0; #356/#429 remain open, outside the milestone. No further ACC/foreign-curve work is scheduled for 0.3.0.

Branch audit finds no Compact P256/k1 implementation to delete. Preserve DID JWK metadata, immutable upstream history and k256 required by pinned native ledger8 crates. Preserve delivered generic Jubjub functionality and its maintained proof gate. Remove ACC-only adoption/resource/coverage/audit closure obligations; all other gates remain. Frozen original inventory: 8 accepted, 1 deferred, 11 open; effective required outcomes 19. Deferral adds zero completed outcomes; midpoint CI remains ten accepted original parents.

[[ACC PR177 — Jubjub-only variant and milestone deferral]] contains the boundary and future entry criteria. Receipt SHA256 `5885463ffc4f2d4b0955119c2979423f5494519ff2136f0b3e8cdabc2db92631`; archive [[ADR0314 — Jubjub-only ACC probe and deferral.zip]], SHA256 `0e37c82f44da56d354c7c93ae48ae78d13ce49fcd5a3ece8369c18d572f265a8`. No production changes, signing/commit, push or remote CI.


## 2026-10-07 — ACC removed from initiative after construct review (ADR0316)

The owner condition is satisfied: no unique ACC witness mechanism, struct construct or ledger type was identified. One typed coin witness, two nested records and25 fields(20cells,4maps,1set) reuse existing backend/runtime categories. Exact ACC combinations and application invariants are not claimed tested. [[ADR-0316 — Remove ACC adoption while retaining generic backend evidence]] removes adoption entirely; #356/#429 close as not planned, with no replacement ACC follow-up.

Retain delivered generic Jubjub regression/proof gates and immutable historical evidence. The ledger8 time-lowering gap remains independently open at https://github.com/MediaNoxLabs/compact/issues/442, unscheduled and outside any milestone. It is not an ACC restart. Scope/removal decision: https://github.com/MediaNoxLabs/compact/issues/441. Original20 inventory:8 accepted,1 removed,11 open; required19; no completion increase; CI threshold still ten accepted original parents.


## 2026-10-07 — R030-18 locally accepted; next slice is coverage

[[ADR-0317 — Accept the scoped performance and resource baseline]] accepts the scoped frozen performance/resource baseline after root and delegated evidence review and ACC scope removal. Hashes/source drift were rechecked; no benchmark/build/proof rerun. Parent #362 closes with limitations explicit. Original20:9 accepted,1 removed,10 open; effective required19. CI begins only after ten accepted original outcomes.

Next coding slice: meaningful collection-query diagnostics/effect tests through the real stateful expression dispatcher, then bounded instrumented coverage reconciliation. Current changed backend coverage remains8587/9060=94.78%;95% is not yet attained. Focus wrong field/index/kind,operand domains and query/witness effects; no implementation-mirroring or weakened acceptance. Reconcile generated export/effect obligations before considering parent #351 complete.


## 2026-10-07 — R03016 local compatibility acceptance (ADR0321/#446)

Current checkpoint `5efa91c280c059e375dcde0998c64dd88f615fb6` retains backend/runtime/macros0.2.0, testkit0.1.0, ABI50, IR20, capability3 and native ledger8.0.3. The machine-readable [[Compatibility feature-source policy.json]] joins source/feature/migration/support limits; milestone0.3.0 is not a package/ABI version.

Independent review verified78migration artifacts,35selected bridge artifacts and2vault archives. Runtime/macros/testkit/public compatibility source and registry package records remain unchanged; existing old/new ABI and migration receipts are reused within their original scope. Actual Rust1.88 on macOS ARM64 passes current backend plus new Jubjub fixture all-feature compilation and isolated standalone backend compilation at signed49898aeda (4.74s/3.77s, warm cached checks);805workspace and75standalone files bound, locks unchanged. Subsequent c924/5efa changes are two test files only. This is not Linux/WASM1.88/fullNix or whole-corpus qualification.

Read-only GitHub drift check `2026-10-07T08:20:54.167066+00:00` confirms DIDv0.7.0 and passport develop still match selected commits, all3pinned commits exist and19adopted source hashes match remote bytes. Passport still pins credential-compact0.2.0. Core main advanced39commits to0.3.0, an unselected newer dependency; retain the owner-approved passport closure without promotion. Eight initial path404 lookups were corrected and retained as lookup attempts. FinalRC must repeat source/ref drift and frozen-candidate checks.

R03016/#360 is locally accepted for present compatibility/migration/MSRV/source-policy criteria. Its future final-candidate obligations remain explicitly owned by R03020; none are called executed. ADR0285/#409 consumer safety remains stopped/unaccepted, and independent security audit remains open. No remote registry or network acceptance claim.

Archive [[ADR0321 — Compatibility policy and current MSRV.zip]], SHA256 `e87b8acab734cf37a11059a71cf74f33261b8cf04332d950534b9cf6d7c8284a`; policy SHA256 `c9491c30fab726cd03fe22389e6a2c12ea678230e079123481392f861d2646f9`. #446 bounded reconciliation closes. This is the **tenth accepted original parent**: original20=10accepted,1removedACC,9open; required19=10accepted/9open. Begin CI stabilization inventory under R03019; full frozen-revision remote qualification is later. Build-heavy local follow-ups wait for disk capacity (below2GiB); no caches/evidence removed.
