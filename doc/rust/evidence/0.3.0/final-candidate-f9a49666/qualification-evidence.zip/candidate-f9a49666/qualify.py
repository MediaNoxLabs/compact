from pathlib import Path
import json,hashlib,subprocess
R=Path('/Users/ysh/.codex/worktrees/07ae/compact');C=Path(__file__).resolve().parent;P=Path('/tmp/rust030-candidate-551f065c');HEAD='f9a496660a4a69f4dd7c7927111767ad5c0c12b2';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
a=load(P/'full-gate/receipt.json');b=load(C/'remaining-receipt.json');assert a['status']=='failed' and b['status']=='passed' and b['candidate']==HEAD
assert h(P/'full-gate/receipt.json')==b['prior_failed_receipt']['sha256'];assert a['build_input_drift']==b['build_input_drift']==[]
commands=a['commands'][:-1]+b['commands'];assert len(a['commands'][:-1])==423
for row in a['commands']+b['commands']:
 assert h(Path(row['log']))==row['log_sha256']
 if row in commands:assert row['exit_code']==0
for row in a['fixtures']:
 assert h(R/row['source'])==row['source_sha256'];assert h(R/row['fixture'])==row['fixture_sha256']
for name in ['compiler','scheme']:assert h(Path(a[name]['snapshot']))==a[name]['sha256']
changed=set(b['changed_paths']);tree=subprocess.check_output(['git','rev-parse',HEAD+'^{tree}'],cwd=R,text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD
for name,digest in b['source_hashes'].items():
 p=R/name;data=p.readlink().as_posix().encode() if p.is_symlink() else p.read_bytes();assert hashlib.sha256(data).hexdigest()==digest,name
children=[]
for key in ['did_proof_gate','did_digest_reducer_gate','did_primitive_reducer_gate']:
 ref=a[key];p=Path(ref['path']);assert h(p)==ref['sha256'];children.append((key,p,load(p)))
for key in ['did-relation-proofs','acc-jubjub-proofs']:
 ref=b[key];p=Path(ref['path']);assert h(p)==ref['sha256'];children.append((key,p,load(p)))
for key,p,x in children:
 assert x['status']=='passed',key
 for row in x['commands']:
  assert row['exit_code']==0 and h(Path(row['log']))==row['log_sha256'],(key,row['label'])
 for name,digest in x.get('source_hashes',{}).items():
  src=Path(name)
  if src.is_relative_to(R) and str(src.relative_to(R)) in changed:continue
  assert h(src)==digest,(key,name)
remote=load(C/'remote-verification.json')
for row in remote['lanes']:
 p=C/'remote-receipts'/f"rust-bounded-{row['lane']}-{HEAD}";s=load(p/'source.json');r=load(p/'result.json')
 assert s['source_commit']==HEAD and s['source_tree']==tree and r['status']=='passed'
 for name,digest in s['locks'].items():assert h(R/name)==digest
 for name,digest in r['artifacts'].items():assert h(p/name)==digest
remote['source_tree_and_local_locks_verified']=True;(C/'remote-verification.json').write_text(json.dumps(remote,indent=2)+'\n')
result={'format':'compact-rust-technical-qualification/v1','status':'passed','candidate':HEAD,'source_tree':tree,'qualification_mode':'completed unchanged prefix plus repaired and remaining gates','full_run_status_preserved':'551f065c full run remains failed; no relabeling or claim of a single fresh full run at f9a49666','successful_prefix_commands':423,'recovery_commands':len(b['commands']),'fixtures_verified':len(a['fixtures']),'all_required_proof_gates':[{'gate':key,'path':str(p),'sha256':h(p)} for key,p,x in children],'prefix_receipt':{'path':str(P/'full-gate/receipt.json'),'sha256':h(P/'full-gate/receipt.json')},'recovery_receipt':{'path':str(C/'remaining-receipt.json'),'sha256':h(C/'remaining-receipt.json')},'remote_verification':{'path':str(C/'remote-verification.json'),'sha256':h(C/'remote-verification.json')},'changes':sorted(changed),'retained_consumer_coverage_migration_package_audit':'2c798d2d measurements retain original identities; source continuity through551 and the two harness/test files above. Final closure crosswalk joins those receipts.','remaining_acceptance':'Technical gates accepted; #352 publication and #358 closure still required. #364 closes after required documentation deliverable.'}
(C/'technical-qualification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
