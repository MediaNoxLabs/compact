# Coverage local acceptance — 2026-10-08

**R03007 / #351 locally accepted at `231559f12aa67a37065b4663778d69ab278678d2`.**

All five approved coverage criteria are locally accepted. Root accepts the requirement-to-assertion reconciliation in the current runtime boundary crosswalk together with the retained compiler/export inventories and subsequent audit-fix amendments.

| Criterion | Accepted evidence |
|---|---|
| Required source/import/export classification |198-root release cohort and232unique Compact inputs;1055generated functions retain explicit current versus historical-role classification. Fresh e680 rendering passed all198. Auxiliary chunked Set remains separately classified and gate-maintained. |
| Typed exports/constructors and sensitive cases | Reviewed assertion/constructor joins, accepted DID and75-export current passport scope; chunked Set external generated native consumer and refusal controls. No fabricated constructor/proof execution. |
| Enumerated changed obligations/effectful branches |74compiler rows/121assertion functions,25runtime obligations/79tests,52codec/native supplements, authorized#409consumer controls, and delivered PATH/WIRE/qualified-Set/wide-diagnostic amendments. Actual behavior/assertions, not line hits alone. |
| Instrumentation floors |Backend8733/9182=95.11%;runtime361/369=97.83%;testkit374/381=98.16%;macros55/55=100%. Baseline939b7aaa; no denominator/threshold reduction or added exclusions. |
| Stable provenance |Source-qualified LCOV/profiles/logs/toolchains and exact unchanged-owner continuity;20output/log identities and3archives rechecked. No branch/MC/DC claim. |

This accepts finite implemented-behavior coverage. It does not establish the unimplemented aggregate decoded heap/CPU guarantee. That supported-input assurance requirement stays open under#361; no input is silently reclassified trusted. If containment is added, its changed behavior must receive new coverage. Source-audit completion is separately recorded; final exact-candidate qualification remains#364.

## Review and provenance

[[Coverage and source-audit acceptance review at231559f1]] contains the criterion-level independent reconciliation; [[Coverage and source-audit acceptance identities at231559f1]] records actual checks. The diagnostic implementer explicitly relies on separately retained external retests for that implementation. Root inspected the report, approved backlog/issue wording, current amendments and source continuity before accepting. No new build, proof or test execution was needed for this decision.

[[Current coverage at e6807884]] · [[Current runtime coverage at ef352bcd]] · [[Audit and assurance readiness after remediation]] · [[ADR0358 — External D1 closure at231559f1]]
