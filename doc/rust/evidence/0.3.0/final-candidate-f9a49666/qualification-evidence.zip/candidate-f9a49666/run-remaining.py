from pathlib import Path
import os,sys,json,hashlib,subprocess,time
R=Path('/Users/ysh/.codex/worktrees/07ae/compact');C=Path(__file__).resolve().parent;P=Path('/tmp/rust030-candidate-551f065c');HEAD='f9a496660a4a69f4dd7c7927111767ad5c0c12b2';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(R/'tools/compact-rust-backend'));import local_parity_gate as gate
assert gate.git_head()==HEAD
changed=subprocess.check_output(['git','diff','--name-only','551f065c',HEAD],cwd=R,text=True).splitlines()
assert set(changed)=={'tools/compact-rust-backend/did_relation_gate.py','tools/compact-rust-backend/test_did_relation_gate.py'}
prior=json.loads((P/'full-gate/receipt.json').read_text());assert prior['status']=='failed' and prior['commands'][-1]['label']=='did-relation-proofs' and prior['build_input_drift']==[]
for command in prior['commands']:
 assert h(Path(command['log']))==command['log_sha256']
 if command!=prior['commands'][-1]:assert command['exit_code']==0
for name in ['compiler','scheme']:
 assert h(Path(prior[name]['snapshot']))==prior[name]['sha256']
source={}
for name in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0'):
 if not name or name.startswith('doc/'):continue
 p=R/name;data=p.readlink().as_posix().encode() if p.is_symlink() else p.read_bytes()
 assert data==subprocess.check_output(['git','show',HEAD+':'+name],cwd=R)
 source[name]=hashlib.sha256(data).hexdigest()
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4',CARGO_NET_OFFLINE='true',MIDNIGHT_PP='/Users/ysh/.cache/midnight/zk-params',MIDNIGHT_LEDGER_TEST_STATIC_DIR='/Users/ysh/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/midnight-ledger-8.0.3/static',CARGO_TARGET_DIR=str(R/'target/compact-rust-parity-gate'),RUSTUP_TOOLCHAIN='1.99.0',PYTHONDONTWRITEBYTECODE='1',CARGO_TERM_COLOR='never')
env['PATH']=str(P/'proof-tools')+os.pathsep+env['PATH'];env['COMPACTC_SCHEME']=prior['scheme']['snapshot'];env['COMPACT_RUST_RUNTIME_DIR']=str(R)
receipt={'format':'compact-rust-candidate-recovery/v1','status':'running','candidate':HEAD,'prior_candidate':prior['git_head'],'prior_failed_receipt':{'path':str(P/'full-gate/receipt.json'),'sha256':h(P/'full-gate/receipt.json')},'changed_paths':changed,'source_hashes':source,'commands':[],'completed_prefix_commands':len(prior['commands'])-1,'scope':'Retained successful prefix plus repaired fresh relation and remaining Jubjub gates. The original full run remains failed; this is an explicit composite qualification, not a relabeled full rerun.','build_inputs':gate.build_input_receipt(env),'started_at':time.time()}
for key in ['lock_sha256','cargo_config_sha256','tools']:
 assert receipt['build_inputs'][key]==prior['build_inputs_after'][key],key
(C/'remaining-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
try:
 gate.run([sys.executable,'-B','-m','unittest','discover','-s','tools/compact-rust-backend','-p','test_*.py'],'python-harness-tests',C,receipt,env=env)
 for label,script,output,fmt,runflag,targetflag in [('did-relation-proofs','did_relation_gate.py','did-relation-proofs','compact-did-relation-gate/v1','--run-dir','--cargo-target-dir'),('acc-jubjub-proofs','acc_jubjub_gate.py','acc-jubjub-proofs','compact-acc-jubjub-gate/v1','--output','--target')]:
  gate.run([sys.executable,'-B',str(R/'tools/compact-rust-backend'/script),'--compiler',prior['compiler']['snapshot'],'--scheme',prior['scheme']['snapshot'],targetflag,env['CARGO_TARGET_DIR'],runflag,str(C/output)],label,C,receipt,env=env)
  p=C/output/'receipt.json';d=json.loads(p.read_text());assert d['format']==fmt and d['status']=='passed'
  receipt[label]={'path':str(p),'sha256':h(p)}
 assert gate.git_head()==HEAD
 for name,digest in source.items():
  p=R/name;data=p.readlink().as_posix().encode() if p.is_symlink() else p.read_bytes();assert hashlib.sha256(data).hexdigest()==digest,name
 gate.finish_build_input_receipt(receipt,env)
 receipt['status']='passed'
except Exception as e:
 receipt['status']='failed';receipt['error']=str(e)
finally:
 receipt['finished_at']=time.time();(C/'remaining-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['status'],receipt.get('error',''),flush=True)
raise SystemExit(receipt['status']!='passed')
